# Lean Guard 0.2.0 local candidate

Base: restored 0.1.6 at b5b8d367653ef46819a8aae094931d86499f662c.

The shell mutation check previously searched for L: anywhere in command text. The new drive-root check requires that the drive letter is not immediately preceded by a Unicode letter, number or underscore. This admits External: and full: prose while retaining literal absolute and drive-relative L: targets, mixed case, variable assignments and protected commands within or after heredocs. Other root matching and consequence rules are unchanged.

This is a narrowly scoped lexical correction, not a complete shell parser. Literal standalone protected paths in inert data can still be conservatively denied; dynamically constructed paths and alternate shell path notation are not newly solved by this release. Do not describe this candidate as complete shell confinement.

The regression must fail first against 0.1.6. Complete package tests, independent review, strict manifest verification and a deterministic local bundle must pass before release preparation is complete.

Local preparation only. Do not install or publish this candidate until the owner authorizes that step. The installed endpoint remains 0.1.6. Existing immutable assets and the public 0.1.6 installer remain preserved. No 0.2.0 public URL is represented as available.