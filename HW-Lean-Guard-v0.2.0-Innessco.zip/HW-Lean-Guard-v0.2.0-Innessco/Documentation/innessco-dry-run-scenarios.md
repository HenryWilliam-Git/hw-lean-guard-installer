# 0.2.0 candidate acceptance

After authorized installation, verify ordinary Workbench heredoc creation and append containing External: and full:, then compare native Write. Require readback and the matching allow audit. Probe protected absolute, drive-relative and mixed-case targets without executing a denied command. Confirm external send remains denied and delete still asks. Capture installed hashes, version and fresh-session hook provenance. These live scenarios are pending.
