# HW Claude Lean Guard v0.2.0

This package moves the primary policy boundary to Claude Team organisation controls and keeps a small endpoint guard for consequences that still need deterministic, local enforcement.

## Control split

| Boundary | Primary control | Endpoint guard role |
| --- | --- | --- |
| Confidentiality, source fidelity, draft status and escalation | Organisation instructions | None; these are behavioural requirements and remain subject to human review. |
| Approved connectors and settings precedence | Server-managed settings is the single policy authority | HKLM contains only the cross-source remote-refresh bootstrap; it does not duplicate organisation policy. |
| Lawyer access to matter drives | Existing user identity and filesystem permissions | The package never changes ACLs on `L:\` or configured UNC matter roots. |
| Direct Claude access to `L:\` | Organisation instructions and managed Read/Edit permissions | Prohibit direct access while leaving ordinary lawyer Windows access unchanged. Computed subprocess paths remain a documented residual risk. |
| Claude Workbench destination | Organisation instructions and the endpoint guard's protected-source copy check | Resolve the signed-in user's Windows Desktop Known Folder and admit only its `Claude Workbench` descendant; never hardcode a drive, username, OneDrive tenant or FSLogix path. |
| Claude Workbench user policy | Claude Desktop `allowedWorkspaceFolders` | The one-command installer creates the resolved `Desktop\Claude Workbench` folder and writes one exact current-user `MultiString` policy value after machine installation passes. A conflicting machine policy fails closed. |
| Credential-bearing text files | Organisation instructions and endpoint guard | Deny bounded files containing non-placeholder password/passphrase/token assignments before model context. |
| Internal/staging email | Organisation instructions and the approved connector's own gate | Require exact approved domains, exact draft review, Boolean confirmation, and no delayed/background delivery. |
| Litigation prompts | Organisation baseline plus managed prompt hook | Inject conservative and jurisdiction-aware guidance before substantive work. |
| Filing, payment, transfer and submission tools | Connector design and organisation policy | Deny only the exact restricted capability identities listed in `policy/guard-policy.json`. Source text containing those words remains inert. |

## Explicit utility exceptions

- `disableSideloadFlags` is deliberately absent. Anthropic documents that it also rejects flags used by Cowork local sessions. Cowork's authorised local-session bootstrap is therefore retained.
- Claude-native tools are not blanket-disabled. Managed hooks evaluate the proposed operation, destination and structured recipient fields.
- `allowAllClaudeAiMcps` admits the claude.ai connectors enabled by the organisation without duplicating that connector catalogue in JSON.
- `strictPluginOnlyCustomization` locks the `mcp` surface so user and project MCP registrations do not load. Cowork's internally supplied session configuration remains the explicit `--mcp-config` exception because `disableSideloadFlags` would also disable Cowork local sessions.
- Source text is immutable evidence. The guard does not inspect document bodies, messages, prompts, summaries or extracted text for legal or risk vocabulary.
- Credential classification is the narrow exception: the guard inspects bounded readable text only for structured secret assignments before a file read enters model context. Oversized, unreadable and binary files remain outside that classifier.

These exceptions do not permit persistent user or project MCP registration. `allowManagedHooksOnly`, `allowManagedPermissionRulesOnly` and `strictPluginOnlyCustomization` keep those administrative surfaces managed.

## Delivery channels

- `policy/server-managed-settings.json` is the Claude Code managed-settings payload (hooks, permissions, managed flags). The organisation administrator deploys it manually through Claude.ai Admin Settings > Claude Code. It deliberately contains no `claudeMd`.
- `policy/endpoint-bootstrap-settings.json` contains only `forceRemoteSettingsRefresh: true`. This documented cross-source exception closes the first-launch fetch window without repeating instructions, permissions, connectors or hooks.
- `policy/org-instructions.md` is the canonical instruction text. It is delivered exactly once, through Claude Team Organization instructions (Admin Settings > Organization and access), which apply to every Claude surface. It is never duplicated as `claudeMd` in the managed-settings payload; see `docs/delivery-channel-split.md`.

The endpoint installer writes only the refresh bootstrap to `HKLM\SOFTWARE\Policies\ClaudeCode\Settings` and installs both Lean Guard and the litigation prompt guard under `C:\Program Files\ClaudeCode\HWOSLeanGuard`. State, rollback and metadata-only audit records live under `C:\ProgramData\HenryWilliam\LeanGuard`. Apply is refused unless the operator supplies `-ServerManagedPolicyConfirmed` after confirming remote managed settings on the endpoint.

The elevated machine installer does not set user or machine environment variables, write FSLogix `redirections.xml`, or configure AppData, TEMP or cache exclusions. After that machine installation passes, the one-command wrapper runs `deployment/Configure-HWOSClaudeWorkbench.ps1` in the original signed-in user context. It resolves the Desktop Known Folder, creates only its `Claude Workbench` child and writes exactly that path to the current-user `allowedWorkspaceFolders` policy. `%USERPROFILE%` in the narrow legacy MCPB replacement rule remains a runtime token and is never replaced with a staging profile path. FSLogix and storage exclusions remain a separate Innessco host-management input.

## Safe workflow

```powershell
# Preview only
.\deployment\Install-HWOSLeanGuard.ps1

# Elevated local install
.\deployment\Install-HWOSLeanGuard.ps1 -Apply -ServerManagedPolicyConfirmed

# Innessco bundle validation only
.\deployment\Install-HWOSLeanGuardOneCommand.ps1 -ValidateOnly

# One-command install; requests UAC when the current shell is not elevated
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\Install-HWOSLeanGuardOneCommand.ps1 -ServerManagedPolicyConfirmed

# Preview current-user Workbench resolution and policy conflict state
.\deployment\Configure-HWOSClaudeWorkbench.ps1

# Restore the captured pre-install current-user allowedWorkspaceFolders value; the Workbench folder is retained
.\deployment\Configure-HWOSClaudeWorkbench.ps1 -Restore -ExpectedPrestateSha256 '<apply-result prestateSha256>' -Confirm:$false

# Intune detection semantics: PASS writes one line and exits 0; failure is silent and exits 1
.\intune\Detect.ps1

# Safe uninstall restores the exact pre-install HKLM value
.\deployment\Uninstall-HWOSLeanGuard.ps1 -Apply
```

`intune/Build-HWOSLeanGuardIntuneWin.ps1` only stages and packages files locally. It does not upload, assign or deploy an Intune application.
