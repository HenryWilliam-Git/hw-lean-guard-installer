$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$guard = Join-Path $root 'runtime\Invoke-HWOSLeanGuard.ps1'
$policy = Join-Path $root 'policy\guard-policy.json'
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardTests-" + [Guid]::NewGuid().ToString('N'))
$audit = Join-Path $sandbox 'audit'
[IO.Directory]::CreateDirectory($audit) | Out-Null
$ordinaryReadPath = Join-Path $sandbox 'ordinary-source.txt'
$credentialReadPath = Join-Path $sandbox 'credential-bearing-source.txt'
$passwordOnlyPath = Join-Path $sandbox 'password-only-source.txt'
$tokenOnlyPath = Join-Path $sandbox 'token-only-source.txt'
$usernameOnlyPath = Join-Path $sandbox 'username-only-source.txt'
$redactedCredentialPath = Join-Path $sandbox 'redacted-credential-source.txt'
$protectedRoot = Join-Path $sandbox 'protected-source'
$protectedSourcePath = Join-Path $protectedRoot 'source.docx'
$protectedDraftPath = Join-Path $protectedRoot 'draft.docx'
$protectedLogPath = Join-Path $protectedRoot 'copy.log'
$approvedDeleteRoot = Join-Path $sandbox 'Workbench\_General\Desktop-Extensions\dist'
$approvedMcpbPath = Join-Path $approvedDeleteRoot 'hw-test-0.0.1.mcpb'
$nestedMcpbPath = Join-Path $approvedDeleteRoot 'nested\hw-test-0.0.1.mcpb'
$nonMcpbPath = Join-Path $approvedDeleteRoot 'notes.txt'
$mcpbDirectoryPath = Join-Path $approvedDeleteRoot 'directory.mcpb'
$reparseBackingRoot = Join-Path $sandbox 'reparse-backing'
$reparseDeleteRoot = Join-Path $sandbox 'reparse-dist'
$reparseMcpbPath = Join-Path $reparseDeleteRoot 'linked.mcpb'
$testPolicy = Join-Path $sandbox 'guard-policy.json'
$desktopRoot = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
if ([string]::IsNullOrWhiteSpace($desktopRoot)) { throw 'Desktop Known Folder is unavailable for guard tests.' }
$claudeWorkbenchRoot = Join-Path $desktopRoot 'Claude Workbench'
$claudeWorkbenchMatter = Join-Path $claudeWorkbenchRoot 'Matters\123'
$legacyWorkbenchMatter = Join-Path $desktopRoot 'Workbench\Matters\123'
[IO.Directory]::CreateDirectory($protectedRoot) | Out-Null
[IO.Directory]::CreateDirectory($approvedDeleteRoot) | Out-Null
[IO.Directory]::CreateDirectory($mcpbDirectoryPath) | Out-Null
[IO.Directory]::CreateDirectory($reparseBackingRoot) | Out-Null
New-Item -ItemType Junction -Path $reparseDeleteRoot -Target $reparseBackingRoot | Out-Null
[IO.File]::WriteAllText($protectedSourcePath, 'synthetic protected source', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($approvedMcpbPath, 'synthetic package', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($nonMcpbPath, 'synthetic text', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText((Join-Path $reparseBackingRoot 'linked.mcpb'), 'synthetic linked package', [Text.UTF8Encoding]::new($false))
$policyObject = [IO.File]::ReadAllText($policy, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
$policyObject.protectedRoots = @($policyObject.protectedRoots) + @($protectedRoot)
$policyObject.approvedMcpbDeleteRoots = @($approvedDeleteRoot, $reparseDeleteRoot)
[IO.File]::WriteAllText($testPolicy, ($policyObject | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($ordinaryReadPath, @"
This ordinary source discusses username, password and API token handling in prose.
Username: enter the approved account identifier after review.
Password: do not place passwords in matter documents.
API token: store tokens only in the approved secrets vault.
"@, [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($credentialReadPath, @"
Access handover
Username: synthetic-user
Password: synthetic-password
API token: synthetic-token
"@, [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($passwordOnlyPath, 'Password: synthetic-password', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($tokenOnlyPath, 'API token: synthetic-token', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($usernameOnlyPath, 'Username: synthetic-user', [Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($redactedCredentialPath, @"
Username: synthetic-user
Password: [REDACTED]
API token: [REDACTED - stored in approved vault]
"@, [Text.UTF8Encoding]::new($false))

function Invoke-GuardProbe {
  param([hashtable]$Payload, [string]$PolicyPath = $testPolicy)
  $start = [Diagnostics.ProcessStartInfo]::new()
  $start.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
  $start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$guard`" -PolicyPath `"$PolicyPath`" -AuditDirectory `"$audit`""
  $start.UseShellExecute = $false
  $start.RedirectStandardInput = $true
  $start.RedirectStandardOutput = $true
  $start.RedirectStandardError = $true
  $process = [Diagnostics.Process]::Start($start)
  $process.StandardInput.Write(($Payload | ConvertTo-Json -Depth 20 -Compress))
  $process.StandardInput.Close()
  $stdout = $process.StandardOutput.ReadToEnd()
  $stderr = $process.StandardError.ReadToEnd()
  $process.WaitForExit()
  $decision = $null
  if (-not [string]::IsNullOrWhiteSpace($stdout)) { $decision = $stdout | ConvertFrom-Json -ErrorAction Stop }
  return [pscustomobject]@{ ExitCode = $process.ExitCode; Output = $decision; Stdout = $stdout; Stderr = $stderr }
}

function Assert-Decision {
  param([string]$Name, [hashtable]$Payload, [string]$Decision, [string]$Rule)
  $result = Invoke-GuardProbe -Payload $Payload
  if ($result.ExitCode -ne 0) { throw "$Name exited $($result.ExitCode): $($result.Stderr)" }
  if ($result.Output.hookSpecificOutput.permissionDecision -cne $Decision -or -not $result.Output.hookSpecificOutput.permissionDecisionReason.StartsWith("[HW OS Lean Guard:$Rule]", [StringComparison]::Ordinal)) {
    throw "$Name returned the wrong decision: $($result.Stdout)"
  }
}

try {
  foreach ($text in @('External:', 'Sources read in full:', 'external:', 'INTERNAL:', 'label:')) {
    $command = "cat >> boundary.js <<'JSEOF'`nconst message = '$text';`nJSEOF"
    Assert-Decision "heredoc prose $text" @{ tool_name='Bash'; tool_input=@{ command=$command } } 'allow' 'lean-default-allow'
  }
  foreach ($command in @(
    'cat > "L:\draft.js"',
    'cat >> "l:/draft.js"',
    'cat > L:relative.js',
    'R="L:\draft.js"; cat > "$R"',
    'Set-Content -LiteralPath L:\draft.js -Value changed',
    "cat > local.js <<EOF`n`$(touch L:\draft.js)`nEOF",
    "cat > local.js <<'EOF'`nExternal:`nEOF`ncat > L:\draft.js"
  )) {
    Assert-Decision "protected drive retained $command" @{ tool_name='Bash'; tool_input=@{ command=$command } } 'deny' 'protected-path-write-deny'
  }
  Assert-Decision 'source text remains inert' @{ tool_name='Read'; tool_input=@{ file_path=$ordinaryReadPath; content='submit, pay, transfer and bypass are source words' } } 'allow' 'lean-default-allow'
  Assert-Decision 'ordinary local file read' @{ tool_name='Read'; tool_input=@{ file_path=$ordinaryReadPath } } 'allow' 'lean-default-allow'
  Assert-Decision 'credential-bearing local file read' @{ tool_name='Read'; tool_input=@{ file_path=$credentialReadPath } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'password-only local file read' @{ tool_name='Read'; tool_input=@{ file_path=$passwordOnlyPath } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'token-only local file read' @{ tool_name='Read'; tool_input=@{ file_path=$tokenOnlyPath } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'username-only local file read' @{ tool_name='Read'; tool_input=@{ file_path=$usernameOnlyPath } } 'allow' 'lean-default-allow'
  Assert-Decision 'redacted credential assignments read' @{ tool_name='Read'; tool_input=@{ file_path=$redactedCredentialPath } } 'allow' 'lean-default-allow'
  Assert-Decision 'ordinary Bash cat read' @{ tool_name='Bash'; tool_input=@{ command=('cat "{0}"' -f $ordinaryReadPath.Replace('\','/')) } } 'allow' 'lean-default-allow'
  Assert-Decision 'credential-bearing Bash cat read used by session' @{ tool_name='Bash'; tool_input=@{ command=('cat "{0}"' -f $credentialReadPath.Replace('\','/')) } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'credential-bearing Bash head read' @{ tool_name='Bash'; tool_input=@{ command=('head -20 "{0}"' -f $credentialReadPath.Replace('\','/')) } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'credential-bearing Bash tail read' @{ tool_name='Bash'; tool_input=@{ command=('tail -20 "{0}"' -f $credentialReadPath.Replace('\','/')) } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'credential-bearing PowerShell Get-Content read' @{ tool_name='PowerShell'; tool_input=@{ command=('Get-Content -LiteralPath ''{0}'' -Raw' -f $credentialReadPath) } } 'deny' 'credential-bearing-file-read-deny'
  Assert-Decision 'protected write' @{ tool_name='Write'; tool_input=@{ file_path=$protectedDraftPath; content='ordinary draft text' } } 'deny' 'protected-path-write-deny'
  Assert-Decision 'Claude Workbench write' @{ tool_name='Write'; tool_input=@{ file_path=(Join-Path $claudeWorkbenchMatter 'Draft - advice.docx'); content='share transfer forms' } } 'allow' 'lean-default-allow'
  Assert-Decision 'global delete asks once' @{ tool_name='Delete'; tool_input=@{ path=(Join-Path $claudeWorkbenchRoot '_dump\old.txt') } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'direct-child MCPB native delete asks once' @{ tool_name='Delete'; tool_input=@{ path=$approvedMcpbPath } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'direct-child MCPB PowerShell delete asks once' @{ tool_name='PowerShell'; tool_input=@{ command=('Remove-Item -LiteralPath ''{0}'' -Force -Confirm:$false' -f $approvedMcpbPath) } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'nested MCPB delete asks once' @{ tool_name='Delete'; tool_input=@{ path=$nestedMcpbPath } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'non-MCPB delete asks once' @{ tool_name='Delete'; tool_input=@{ path=$nonMcpbPath } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'MCPB directory delete asks once' @{ tool_name='Delete'; tool_input=@{ path=$mcpbDirectoryPath } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'reparse-root MCPB delete asks once' @{ tool_name='Delete'; tool_input=@{ path=$reparseMcpbPath } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'wildcard MCPB delete asks once' @{ tool_name='PowerShell'; tool_input=@{ command=('Remove-Item -LiteralPath ''{0}\*.mcpb'' -Force' -f $approvedDeleteRoot) } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'recursive MCPB root delete asks once' @{ tool_name='PowerShell'; tool_input=@{ command=('Remove-Item -LiteralPath ''{0}'' -Recurse -Force' -f $approvedDeleteRoot) } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'dynamic MCPB target delete asks once' @{ tool_name='PowerShell'; tool_input=@{ command='Remove-Item -LiteralPath $OutFile -Force' } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'Bash rm delete asks once' @{ tool_name='Bash'; tool_input=@{ command=('rm -f "{0}"' -f $nonMcpbPath.Replace('\','/')) } } 'ask' 'delete-confirmation-required'
  Assert-Decision 'exact submission' @{ tool_name='mcp__hw_legal__submit'; tool_input=@{ document='share transfer forms' } } 'deny' 'restricted-external-capability'
  Assert-Decision 'lookalike source tool' @{ tool_name='mcp__hw_legal__submit_preview'; tool_input=@{ text='submit share transfer forms' } } 'allow' 'lean-default-allow'
  Assert-Decision 'protected source copy to Claude Workbench' @{ tool_name='PowerShell'; tool_input=@{ command=('Copy-Item -LiteralPath ''{0}'' -Destination ''{1}''' -f $protectedSourcePath, (Join-Path $claudeWorkbenchMatter 'source.docx')) } } 'allow' 'protected-source-copy-to-claude-workbench'
  Assert-Decision 'protected source copy to legacy Workbench' @{ tool_name='PowerShell'; tool_input=@{ command=('Copy-Item -LiteralPath ''{0}'' -Destination ''{1}''' -f $protectedSourcePath, (Join-Path $legacyWorkbenchMatter 'source.docx')) } } 'deny' 'protected-source-copy-destination-deny'
  Assert-Decision 'protected source write' @{ tool_name='PowerShell'; tool_input=@{ command=('Set-Content -LiteralPath ''{0}'' -Value changed' -f $protectedSourcePath) } } 'deny' 'protected-path-write-deny'
  Assert-Decision 'protected source move' @{ tool_name='PowerShell'; tool_input=@{ command=('Move-Item -LiteralPath ''{0}'' -Destination ''{1}''' -f $protectedSourcePath, (Join-Path $claudeWorkbenchMatter 'source.docx')) } } 'deny' 'protected-path-write-deny'
  Assert-Decision 'protected destination copy' @{ tool_name='PowerShell'; tool_input=@{ command=('Copy-Item -LiteralPath ''{0}'' -Destination ''{1}''' -f (Join-Path $claudeWorkbenchMatter 'draft.docx'), $protectedDraftPath) } } 'deny' 'protected-path-write-deny'
  Assert-Decision 'protected copy with protected redirection' @{ tool_name='PowerShell'; tool_input=@{ command=('Copy-Item -LiteralPath ''{0}'' -Destination ''{1}'' > ''{2}''' -f $protectedSourcePath, (Join-Path $claudeWorkbenchMatter 'source.docx'), $protectedLogPath) } } 'deny' 'protected-path-write-deny'
  Assert-Decision 'protected source copy outside Claude Workbench' @{ tool_name='PowerShell'; tool_input=@{ command=('Copy-Item -LiteralPath ''{0}'' -Destination ''{1}''' -f $protectedSourcePath, (Join-Path $sandbox 'outside.docx')) } } 'deny' 'protected-source-copy-destination-deny'
  Assert-Decision 'primary-domain internal send' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@henrywilliam.com.au'); cc=@(); bcc=@(); confirm=$true; body='share transfer forms' } } 'allow' 'outlook-internal-send-confirmed'
  Assert-Decision 'staging-domain internal send' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@hwdev.com.au'); cc=@(); bcc=@(); confirm=$true } } 'allow' 'outlook-internal-send-confirmed'
  Assert-Decision 'domain suffix lookalike' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@hwdev.com.au.evil'); confirm=$true } } 'deny' 'outlook-internal-send-domain'
  Assert-Decision 'domain prefix lookalike' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@evilhwdev.com.au'); confirm=$true } } 'deny' 'outlook-internal-send-domain'
  Assert-Decision 'subdomain recipient' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@sub.hwdev.com.au'); confirm=$true } } 'deny' 'outlook-internal-send-domain'
  Assert-Decision 'mixed recipients' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@hwdev.com.au','other@example.com'); confirm=$true } } 'deny' 'outlook-internal-send-domain'
  Assert-Decision 'nonboolean confirm' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@henrywilliam.com.au'); confirm='true' } } 'deny' 'outlook-internal-send-confirmation'
  Assert-Decision 'scheduled send' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@henrywilliam.com.au'); confirm=$true; send_at='tomorrow' } } 'deny' 'delayed-or-background-action'
  Assert-Decision 'background internal send remains denied' @{ tool_name='mcp__outlook__send_internal'; tool_input=@{ to=@('lawyer@henrywilliam.com.au'); confirm=$true; run_in_background=$true } } 'deny' 'delayed-or-background-action'
  Assert-Decision 'ordinary shell' @{ tool_name='PowerShell'; tool_input=@{ command=('Get-ChildItem -LiteralPath ''{0}''' -f $sandbox) } } 'allow' 'lean-default-allow'
  Assert-Decision 'background PowerShell CLI is allowed' @{ tool_name='PowerShell'; tool_input=@{ command='npm test'; run_in_background=$true } } 'allow' 'lean-default-allow'
  Assert-Decision 'background Bash CLI is allowed' @{ tool_name='Bash'; tool_input=@{ command='npm test'; background=$true } } 'allow' 'lean-default-allow'
  Assert-Decision 'scheduled PowerShell action remains denied' @{ tool_name='PowerShell'; tool_input=@{ command='npm test'; scheduled=$true } } 'deny' 'delayed-or-background-action'

  $missing = Invoke-GuardProbe -Payload @{ tool_name='Read'; tool_input=@{ file_path=$ordinaryReadPath } } -PolicyPath (Join-Path $sandbox 'missing.json')
  if ($missing.ExitCode -ne 2 -or $missing.Stdout.Length -ne 0) { throw 'Missing policy did not fail closed with exit code 2.' }

  $auditPath = Join-Path $audit 'decisions.jsonl'
  $allowedAuditFields = @('schemaVersion','timestampUtc','packageVersion','decision','rule','toolName','policySha256')
  foreach ($line in [IO.File]::ReadAllLines($auditPath, [Text.Encoding]::UTF8)) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $event = $line | ConvertFrom-Json -ErrorAction Stop
    $extras = @($event.PSObject.Properties.Name | Where-Object { $allowedAuditFields -cnotcontains $_ })
    if ($extras.Count -gt 0) { throw "Audit event contains unapproved fields: $($extras -join ', ')" }
    if ($line.Contains('share transfer forms') -or $line.Contains('lawyer@')) { throw 'Audit event leaked document or recipient content.' }
  }
  Write-Output 'PASS: Lite guard operational decisions and source fidelity'
} finally {
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
