[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [switch]$ServerManagedPolicyConfirmed,
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $PSScriptRoot }
$PackageRoot = [IO.Path]::GetFullPath($PackageRoot)
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot
$settingsSource = Join-Path $PackageRoot 'policy\endpoint-bootstrap-settings.json'
$settingsText = [IO.File]::ReadAllText($settingsSource, [Text.Encoding]::UTF8).TrimEnd("`r", "`n")

$preview = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-install-preview/v1'
  applyRequested = [bool]$Apply
  serverManagedPolicyConfirmed = [bool]$ServerManagedPolicyConfirmed
  packageVersion = [string]$manifest.packageVersion
  installRoot = $InstallRoot
  stateRoot = $StateRoot
  policyRegistryPath = $PolicyRegistryPath
  sourceDriveAclsChanged = $false
  environmentVariablesChanged = $false
  workbenchExclusionsConfigured = $false
  fsLogixConfigured = $false
  settingsChannel = 'remote-refresh-bootstrap-only'
}
if (-not $Apply) { $preview | ConvertTo-Json -Depth 10; return }
if (-not $ServerManagedPolicyConfirmed) { throw 'Apply requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).' }
if (-not (Test-HWOSLeanGuardAdministrator)) { throw 'Apply requires an elevated Administrator PowerShell.' }
if (-not $PSCmdlet.ShouldProcess($InstallRoot, 'Install HW OS Lean Guard and write the HKLM remote-refresh bootstrap')) { return }

$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss-fff')
$rollbackPath = Join-Path $StateRoot "rollback\prestate-$stamp.json"
$statePath = Join-Path $StateRoot 'state\install-state.json'
$evidencePath = Join-Path $StateRoot "evidence\install-$stamp.json"
$preState = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-prestate/v1'
  capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
  policyRegistryPath = $PolicyRegistryPath
  registry = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
  previousInstallRootExists = Test-Path -LiteralPath $InstallRoot
}
Write-HWOSLeanGuardJson -Path $rollbackPath -Value $preState

try {
  [IO.Directory]::CreateDirectory((Join-Path $InstallRoot 'runtime')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $InstallRoot 'policy')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $InstallRoot 'deployment')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'state')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'evidence')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'logs')) | Out-Null

  Copy-Item -LiteralPath (Join-Path $PackageRoot 'runtime\Invoke-HWOSLeanGuard.ps1') -Destination (Join-Path $InstallRoot 'runtime\Invoke-HWOSLeanGuard.ps1') -Force
  Copy-Item -LiteralPath (Join-Path $PackageRoot 'runtime\Invoke-HWOSLitigationPromptGuard.ps1') -Destination (Join-Path $InstallRoot 'runtime\Invoke-HWOSLitigationPromptGuard.ps1') -Force
  foreach ($name in @('guard-policy.json','endpoint-bootstrap-settings.json','org-instructions.md')) {
    Copy-Item -LiteralPath (Join-Path $PackageRoot "policy\$name") -Destination (Join-Path $InstallRoot "policy\$name") -Force
  }
  foreach ($name in @('HWOSLeanGuard.Deployment.psm1','Detect-HWOSLeanGuard.ps1','Uninstall-HWOSLeanGuard.ps1')) {
    Copy-Item -LiteralPath (Join-Path $PackageRoot "deployment\$name") -Destination (Join-Path $InstallRoot "deployment\$name") -Force
  }

  New-Item -Path $PolicyRegistryPath -Force | Out-Null
  New-ItemProperty -LiteralPath $PolicyRegistryPath -Name 'Settings' -Value $settingsText -PropertyType String -Force | Out-Null

  $files = [ordered]@{}
  foreach ($relative in @(
    'runtime\Invoke-HWOSLeanGuard.ps1',
    'runtime\Invoke-HWOSLitigationPromptGuard.ps1',
    'policy\guard-policy.json',
    'policy\endpoint-bootstrap-settings.json',
    'policy\org-instructions.md',
    'deployment\HWOSLeanGuard.Deployment.psm1',
    'deployment\Detect-HWOSLeanGuard.ps1',
    'deployment\Uninstall-HWOSLeanGuard.ps1'
  )) {
    $files[$relative] = Get-HWOSLeanGuardSha256 -Path (Join-Path $InstallRoot $relative)
  }
  $state = [ordered]@{
    schemaVersion = 'hw-os-lean-guard-state/v1'
    packageVersion = [string]$manifest.packageVersion
    installedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
    installRoot = [IO.Path]::GetFullPath($InstallRoot)
    policyRegistryPath = $PolicyRegistryPath
    settingsSha256 = Get-HWOSLeanGuardTextSha256 -Text $settingsText
    files = $files
    preStatePath = [IO.Path]::GetFullPath($rollbackPath)
  }
  Write-HWOSLeanGuardJson -Path $statePath -Value $state
  Set-HWOSLeanGuardAcls -InstallRoot $InstallRoot -StateRoot $StateRoot

  $checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
  $passed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -eq 0
  $evidence = [ordered]@{
    schemaVersion = 'hw-os-lean-guard-evidence/v1'
    capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
    packageVersion = [string]$manifest.packageVersion
    checks = $checks
    environmentVariablesChanged = $false
    workbenchExclusionsConfigured = $false
    fsLogixConfigured = $false
    result = if ($passed) { 'PASS' } else { 'FAIL' }
  }
  Write-HWOSLeanGuardJson -Path $evidencePath -Value $evidence
  if (-not $passed) { throw 'Installed policy readback failed.' }
  $evidence | ConvertTo-Json -Depth 12
} catch {
  try { Restore-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath -State $preState.registry } catch { }
  throw
}
