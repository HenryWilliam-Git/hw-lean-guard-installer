# Lean Guard v0.1.5 Innessco deployment package

This is the operator handoff for the approved Lean Guard v0.1.5 direct PowerShell deployment.

1. Extract the complete ZIP to a local folder and read Documentation/production-handoff.md.
2. Review Documentation/cloud-only-production-architecture.jpg and implement the required FSLogix, OneDrive and host-local TEMP/cache split.
3. Verify every extracted file against HANDOFF-SHA256SUMS.
4. Confirm Claude /status shows Enterprise managed settings (remote).
5. From this extraction root, run exactly:

`powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-HWOSLeanGuard.ps1 -ServerManagedPolicyConfirmed
`

The command validates the complete package manifest, requests Administrator elevation when needed, runs the official installer, and refuses success unless installed-state readback passes. A cancelled UAC prompt does not install Lean Guard.

The installer does not set user or machine environment variables or configure Workbench, FSLogix, AppData, TEMP or cache exclusions. Do not carry staging profile paths, OneDrive tenant paths, environment-variable values or 
edirections.xml settings into a target host. Resolve and deploy those separate host-management settings for the actual target environment.

The IntuneWin artifact is not an Innessco deployment input in this bundle. Do not edit files under PowerShell/Package; the manifest rejects missing, changed or extra files. The files under Evidence and Integrity are records, not deployment instructions. Endpoints must not pull mutable source from GitHub.
