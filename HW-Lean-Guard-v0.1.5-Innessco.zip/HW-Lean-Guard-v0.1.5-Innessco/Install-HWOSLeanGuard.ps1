[CmdletBinding()]
param(
  [switch]$ServerManagedPolicyConfirmed,
  [switch]$ValidateOnly,
  [switch]$ElevatedChild,
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

if ([string]::IsNullOrWhiteSpace($PackageRoot)) {
  $sourcePackageRoot = Split-Path -Parent $PSScriptRoot
  $bundlePackageRoot = Join-Path $PSScriptRoot 'PowerShell\Package'
  if (Test-Path -LiteralPath (Join-Path $sourcePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $sourcePackageRoot
  } elseif (Test-Path -LiteralPath (Join-Path $bundlePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $bundlePackageRoot
  } else {
    throw 'Unable to locate the manifest-validated Lean Guard package beside the installer.'
  }
}

$PackageRoot = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$deploymentRoot = Join-Path $PackageRoot 'deployment'
$modulePath = Join-Path $deploymentRoot 'HWOSLeanGuard.Deployment.psm1'
$installerPath = Join-Path $deploymentRoot 'Install-HWOSLeanGuard.ps1'
foreach ($requiredPath in @($modulePath, $installerPath)) {
  if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) { throw "Required package file is missing: $requiredPath" }
}

Import-Module $modulePath -Force
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot

if ($ValidateOnly) {
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-preview/v1'
    applyRequested = $false
    uacRequested = $false
    serverManagedPolicyConfirmed = [bool]$ServerManagedPolicyConfirmed
    packageVersion = [string]$manifest.packageVersion
    packageRoot = $PackageRoot
  } | ConvertTo-Json -Depth 8
  return
}

if (-not $ServerManagedPolicyConfirmed) {
  throw 'One-command installation requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).'
}

if (-not (Test-HWOSLeanGuardAdministrator)) {
  if ($ElevatedChild) { throw 'Elevated installer child does not have Administrator rights.' }
  foreach ($value in @($PSCommandPath, $PackageRoot, $InstallRoot, $StateRoot, $PolicyRegistryPath)) {
    if ([string]::IsNullOrWhiteSpace($value) -or $value.Contains('"')) { throw 'Installer paths cannot be empty or contain double quotes.' }
  }
  $windowsPowerShell = Join-Path $PSHOME 'powershell.exe'
  if (-not (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf)) {
    $windowsPowerShell = (Get-Command powershell.exe -ErrorAction Stop).Source
  }
  $argumentLine = @(
    '-NoProfile',
    '-ExecutionPolicy Bypass',
    "-File `"$PSCommandPath`"",
    '-ServerManagedPolicyConfirmed',
    '-ElevatedChild',
    "-PackageRoot `"$PackageRoot`"",
    "-InstallRoot `"$InstallRoot`"",
    "-StateRoot `"$StateRoot`"",
    "-PolicyRegistryPath `"$PolicyRegistryPath`""
  ) -join ' '
  try {
    $process = Start-Process -FilePath $windowsPowerShell -ArgumentList $argumentLine -Verb RunAs -Wait -PassThru
  } catch {
    throw "Administrator elevation failed or was cancelled. Lean Guard was not installed by this command. $($_.Exception.Message)"
  }
  if ($process.ExitCode -ne 0) { throw "Elevated Lean Guard installation failed with exit code $($process.ExitCode)." }
  return
}

$installJson = (& $installerPath -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $PackageRoot -InstallRoot $InstallRoot -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath | Out-String)
$installEvidence = $installJson | ConvertFrom-Json -ErrorAction Stop
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
$passed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -eq 0
if (-not $passed) { throw 'One-command installation completed but installed-state detection failed.' }

[ordered]@{
  schemaVersion = 'hw-os-lean-guard-one-command-result/v1'
  packageVersion = [string]$manifest.packageVersion
  installEvidence = $installEvidence
  checks = $checks
  result = 'PASS'
} | ConvertTo-Json -Depth 16
