# Lean Guard v0.1.8 public online installation

The authoritative repository is private. Distribution uses the existing minimal public repository `HenryWilliam-Git/hw-lean-guard-installer`. The v0.1.8 bootstrap is generated from the exact versioned Innessco package record. Earlier releases and versioned scripts remain unchanged.

## Release assets and integrity

The public release contains `install.ps1`, byte-identical `install-v0.1.8.ps1`, `HW-Lean-Guard-v0.1.8-Innessco.zip`, and `SHA256SUMS`. The ZIP includes the reviewed machine package, Workbench configurator, Personal Context runtime, operator documentation and de-identified integrity evidence. It contains no user Personal Context stores, keys, prompts or transcripts.

SHA-256 establishes byte integrity, not a certificate signature. The Personal Context executable is not Authenticode-signed. The current source is a release candidate until PR, CI, tag and immutable Release readback have been recorded.

## Evergreen single PowerShell command

Run in the signed-in user's PowerShell for a separately authorized target installation after Claude `/status` confirms `Enterprise managed settings (remote)`. The exact x64 .NET runtime 8.0.30 must already be present; the installer fails before machine mutation when it is absent.

```powershell
& { $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $api='https:'+'//'+'api.github.com/repos/HenryWilliam-Git/hw-lean-guard-installer/releases/latest'; $release=Invoke-RestMethod -UseBasicParsing -Headers @{ Accept='application/vnd.github+json'; 'User-Agent'='HW-Lean-Guard-Installer' } -Uri $api; if ($release.draft -ne $false -or $release.prerelease -ne $false -or $release.immutable -ne $true -or [string]$release.tag_name -notmatch '^v\d+\.\d+\.\d+$') { throw 'Latest public Lean Guard Release is not an approved immutable version.' }; $assets=@($release.assets | Where-Object { $_.name -ceq 'install.ps1' }); if ($assets.Count -ne 1 -or [string]$assets[0].digest -notmatch '^sha256:[0-9a-f]{64}$') { throw 'Latest public Lean Guard bootstrap identity is invalid.' }; $uri=[Uri][string]$assets[0].browser_download_url; if ($uri.Scheme -cne 'https' -or $uri.Host -cne 'github.com') { throw 'Latest public Lean Guard bootstrap URL is invalid.' }; $path=Join-Path ([IO.Path]::GetTempPath()) ('HWLeanGuard-evergreen-'+[Guid]::NewGuid().ToString('N')+'.ps1'); try { $response=Invoke-WebRequest -UseBasicParsing -Uri $uri -OutFile $path -PassThru; $finalUri=if ($null -ne $response.BaseResponse.PSObject.Properties['ResponseUri']) { $response.BaseResponse.ResponseUri } else { $response.BaseResponse.RequestMessage.RequestUri }; if ($null -eq $finalUri -or $finalUri.Scheme -cne 'https') { throw 'Latest public Lean Guard bootstrap download did not finish over HTTPS.' }; $actual='sha256:'+((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()); if ($actual -cne [string]$assets[0].digest) { throw 'Latest public Lean Guard bootstrap SHA-256 mismatch.' }; & $path -ServerManagedPolicyConfirmed } finally { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } } }
```

The command resolves the latest immutable stable release, verifies GitHub's bootstrap digest, and executes it. The bootstrap verifies the pinned versioned ZIP and every package byte. The one-command wrapper preserves the v0.1.6 secure encoded elevation path and validates the staged package against the manifest captured before UAC. It installs both machine runtime roots and only then applies Workbench HKCU policy in the original user process.

Installation does not publish Claude organization settings or activate Personal Context hooks. Personal Context remains an explicit-save lexical preview pending separate activation, user-isolation and FSLogix validation. Machine uninstall retains all per-user packet stores. Intune and fleet assignments are outside this command.

## Non-mutating download and validation

This variant traverses the same public download and hash-verification path but performs no UAC, installation or HKCU mutation:

```powershell
& { $ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; $api='https:'+'//'+'api.github.com/repos/HenryWilliam-Git/hw-lean-guard-installer/releases/latest'; $release=Invoke-RestMethod -UseBasicParsing -Headers @{ Accept='application/vnd.github+json'; 'User-Agent'='HW-Lean-Guard-Installer' } -Uri $api; if ($release.draft -ne $false -or $release.prerelease -ne $false -or $release.immutable -ne $true -or [string]$release.tag_name -notmatch '^v\d+\.\d+\.\d+$') { throw 'Latest public Lean Guard Release is not an approved immutable version.' }; $assets=@($release.assets | Where-Object { $_.name -ceq 'install.ps1' }); if ($assets.Count -ne 1 -or [string]$assets[0].digest -notmatch '^sha256:[0-9a-f]{64}$') { throw 'Latest public Lean Guard bootstrap identity is invalid.' }; $uri=[Uri][string]$assets[0].browser_download_url; if ($uri.Scheme -cne 'https' -or $uri.Host -cne 'github.com') { throw 'Latest public Lean Guard bootstrap URL is invalid.' }; $path=Join-Path ([IO.Path]::GetTempPath()) ('HWLeanGuard-evergreen-'+[Guid]::NewGuid().ToString('N')+'.ps1'); try { $response=Invoke-WebRequest -UseBasicParsing -Uri $uri -OutFile $path -PassThru; $finalUri=if ($null -ne $response.BaseResponse.PSObject.Properties['ResponseUri']) { $response.BaseResponse.ResponseUri } else { $response.BaseResponse.RequestMessage.RequestUri }; if ($null -eq $finalUri -or $finalUri.Scheme -cne 'https') { throw 'Latest public Lean Guard bootstrap download did not finish over HTTPS.' }; $actual='sha256:'+((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()); if ($actual -cne [string]$assets[0].digest) { throw 'Latest public Lean Guard bootstrap SHA-256 mismatch.' }; & $path -ValidateOnly } finally { if (Test-Path -LiteralPath $path) { Remove-Item -LiteralPath $path -Force } } }
```

Before v0.1.8 becomes the latest published stable release, an evergreen command may resolve v0.1.7. Record the returned version rather than inferring it from this document's title.

## Release verification

Publish all four assets before making the release immutable. Verify annotated tag targets, PR/CI state, GitHub asset sizes/digests, anonymous downloads, and the returned v0.1.8 package version through the non-mutating command. This verification proves distribution and package validation, not endpoint or organization-hook activation.
