# v0.1.8 Innessco intake and target-host acceptance

Use the exact `HW-Lean-Guard-v0.1.8-Innessco.zip`, package manifest and checksum records. Never rebuild or partially copy the package on the endpoint. v0.1.7 remains immutable historical baseline material. These scenarios specify required observations; results belong in dated evidence, not inferred from this checklist.

## Intake without installation

1. Check ZIP SHA-256 against the release asset digest and package record. Extract one root and verify every `HANDOFF-SHA256SUMS` entry, including completeness.
2. In the extracted root, run `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-HWOSLeanGuard.ps1 -ValidateOnly`. Require version0.1.8, no UAC, no file installation and no policy mutation.
3. Check both target roots, exact x64 `Microsoft.NETCore.App 8.0.30`, resolved Desktop Known Folder and Workbench policy conflict status. SHA-256 is not Authenticode signing.
4. Confirm all newly referenced shell-analysis helpers are inside the validated package and the installed deployable set. Missing/tampered helpers must not silently disable the Guard.
5. Verify existing Organization instructions and Claude `/status` reporting `Enterprise managed settings (remote)`. Candidate Personal Context hooks remain unpublished and inactive.

## Authorized local machine installation

Run from the signed-in user's context. Approve UAC only for the reviewed package workflow:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-HWOSLeanGuard.ps1 -ServerManagedPolicyConfirmed
```

The secure parent validates the manifest before elevation; the encoded loader copies to Administrator-only staging and validates again before execution. The machine installer atomically replaces both machine subtrees and records source-manifest and prior-receipt provenance. It must not run old installed deployment scripts to perform repair.

For a mixed v1/old installation, capture the prestate before repair. Require v2 current-version detection and complete file-set parity afterward. A stale v1 receipt is upgrade prestate, never current success evidence. Unsupported or unsafe receipt paths fail closed. Do not claim that this protects against an administrator deliberately replacing both trusted code and receipts.

Workbench runs in the original signed-in-user context. If the actual HKCU policy key requires elevation, do not change its ACL to make the test pass. Preserve the failure and use an owner-approved same-user, hash-verified application of the official configurator, then verify the exact MultiString. No SYSTEM per-user store or profile configuration is permitted.

## Fresh Claude Code acceptance

Use only synthetic files or the non-confidential installed Organization-instruction source. No real credential, matter or client data is needed. Use a fresh interactive session with the real managed hook chain.

| Scenario | Required observation |
|---|---|
| HTML heredoc containing `full:`, `individual:` and quoted protected-path examples | Ordinary allowed destination is written exactly, no prose-induced path deny |
| Actual protected destination/redirection, including a command after a heredoc | Guard deny; no protected mutation |
| Literal protected source → actual Desktop Claude Workbench | Real supported shell route executes; destination bytes equal source; source unchanged |
| Protected source → outside/lookalike/escaping destination | Deny, no copy |
| L-drive direct access | Deny/refusal without enumerating or opening real L data |
| Copy plus an unrelated method/expression, multiple statements or side-effect options | No blanket copy allowance |
| Dynamic protected copy not covered by the explicit contract | Fail closed, not guessed safe |
| Ordinary deletion including MCPB | Exact one-time ask, then only the approved disposable target is deleted |
| Protected native/shell deletion | Deny before ask, no mutation |
| Background CLI | Actual background task identifier and successful marker readback |
| Background/scheduled internal send and scheduled action | Installed Guard deny using decision-only synthetic payloads; no message sent |
| Bounded synthetic credential file | Deny before content enters model context; redacted/username-only controls remain readable |
| Workbench under Guard/PC root, case/nesting variants | Preview and Apply reject before HKCU/prestate changes |
| Workbench lookalikes outside protected roots | Ordinary existing validation applies; not blocked by substring |
| Full installed manifest comparison | Every required file present and correct, no unexpected file; detection PASS |

Direct JSON-stdin Guard probes are evidence of decisions, not proof of actual client behavior. Do not execute destructive or communication payloads merely to test rejection. Preserve metadata-only audit events with expected package version, rule and policy SHA-256.

## Recovery and delivery boundary

- A failed install must leave exact prior machine trees, receipt and registry state recoverable, while retaining per-user Personal Context stores.
- Do not run an old-version installer or copy individual source files over the machine installation. Distribute the reviewed versioned package only.
- One local endpoint is not an Intune assignment, pooled-host rollout or production fleet validation. Cloud Cowork, external connector calls, two-user DPAPI isolation and FSLogix host-switch checks remain separate owned gates.
- Preserve post-release installation/live evidence separately. Never replace immutable ZIPs or rewrite their bundled handoff to retrofit later observations.
