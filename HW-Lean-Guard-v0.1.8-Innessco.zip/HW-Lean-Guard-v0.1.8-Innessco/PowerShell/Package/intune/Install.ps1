[CmdletBinding()]
param([switch]$ServerManagedPolicyConfirmed)
$ErrorActionPreference = 'Stop'
if (-not $ServerManagedPolicyConfirmed) { throw 'Intune installation requires confirmation that the server-managed policy is active.' }
$packageRoot = Split-Path -Parent $PSScriptRoot
& (Join-Path $packageRoot 'deployment\Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $packageRoot | Out-Null
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& (Join-Path $packageRoot 'deployment\Detect-HWOSLeanGuard.ps1') -Quiet
exit $LASTEXITCODE
