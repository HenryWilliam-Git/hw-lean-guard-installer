[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [Parameter(Mandatory = $true)][string]$IntuneWinAppUtilPath,
  [string]$OutputDirectory = (Join-Path ([IO.Path]::GetTempPath()) 'HWOSLeanGuardIntuneWin')
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.IntuneTrust.psm1') -Force
$packageRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$tool = [IO.Path]::GetFullPath($IntuneWinAppUtilPath)
$toolEvidence = Get-HWOSApprovedIntunePreparationToolEvidence -Path $tool
$toolHash = $toolEvidence.toolSha256
$preview = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-intunewin-preview/v1'
  applyRequested = [bool]$Apply
  packageRoot = $packageRoot
  outputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
  toolSha256 = $toolHash
  toolSignatureStatus = $toolEvidence.toolSignatureStatus
  toolSignerSubject = $toolEvidence.toolSignerSubject
  toolSignerThumbprint = $toolEvidence.toolSignerThumbprint
  toolTimestampSubject = $toolEvidence.toolTimestampSubject
  toolTimestampThumbprint = $toolEvidence.toolTimestampThumbprint
  networkOrTenantMutation = $false
}
if (-not $Apply) { $preview | ConvertTo-Json -Depth 8; return }
if (-not $PSCmdlet.ShouldProcess($OutputDirectory, 'Build local HW OS Lean Guard .intunewin artifact')) { return }

$stageRoot = Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuard-stage-" + [Guid]::NewGuid().ToString('N'))
try {
  [IO.Directory]::CreateDirectory($stageRoot) | Out-Null
  [IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($OutputDirectory)) | Out-Null
  Copy-Item -Path (Join-Path $packageRoot '*') -Destination $stageRoot -Recurse -Force
  & $tool -c $stageRoot -s 'intune\Install.ps1' -o ([IO.Path]::GetFullPath($OutputDirectory)) -q
  if ($LASTEXITCODE -ne 0) { throw "IntuneWinAppUtil failed with exit code $LASTEXITCODE." }
  $artifact = Get-ChildItem -LiteralPath $OutputDirectory -Filter '*.intunewin' -File | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
  if ($null -eq $artifact) { throw 'IntuneWinAppUtil returned success but no .intunewin artifact was found.' }
  [ordered]@{
    artifact = $artifact.FullName
    sha256 = (Get-FileHash -LiteralPath $artifact.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
    toolSha256 = $toolHash
    toolSignatureStatus = $toolEvidence.toolSignatureStatus
    toolSignerSubject = $toolEvidence.toolSignerSubject
    toolSignerThumbprint = $toolEvidence.toolSignerThumbprint
    uploaded = $false
    assigned = $false
  } | ConvertTo-Json -Depth 8
} finally {
  if (Test-Path -LiteralPath $stageRoot) {
    $resolvedStage = [IO.Path]::GetFullPath($stageRoot)
    $tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
    if ($resolvedStage.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $resolvedStage).StartsWith('HWOSLeanGuard-stage-', [StringComparison]::Ordinal)) {
      Remove-Item -LiteralPath $resolvedStage -Recurse -Force
    }
  }
}
