Set-StrictMode -Version 2.0

function Assert-HWOSApprovedIntunePreparationToolEvidence {
  [CmdletBinding()]
  param(
    [Parameter(Mandatory = $true)][string]$ToolSha256,
    [Parameter(Mandatory = $true)][string]$SignatureStatus,
    [Parameter(Mandatory = $true)][string]$SignerSubject,
    [Parameter(Mandatory = $true)][string]$SignerThumbprint,
    [string]$TimestampSubject,
    [string]$TimestampThumbprint
  )

  $approvedToolSha256 = 'c1ba45b5cb939e84af064bb7ff4b38fb3dfe33c8dc1078fd9b157672eae671f6'
  $approvedSignerSubject = 'CN=Microsoft Corporation, O=Microsoft Corporation, L=Redmond, S=Washington, C=US'
  $approvedSignerThumbprint = '3f56a45111684d454e231cfdc4da5c8d370f9816'

  if ($ToolSha256.ToLowerInvariant() -cne $approvedToolSha256) { throw 'IntuneWinAppUtil.exe hash does not match the package-approved value.' }
  if ($SignatureStatus -cne 'Valid') { throw 'IntuneWinAppUtil.exe does not have a valid Authenticode signature.' }
  if ($SignerSubject -cne $approvedSignerSubject) { throw 'IntuneWinAppUtil.exe does not match the package-approved Microsoft signer.' }
  if ($SignerThumbprint.ToLowerInvariant() -cne $approvedSignerThumbprint) { throw 'IntuneWinAppUtil.exe signer thumbprint does not match the package-approved certificate.' }

  [pscustomobject][ordered]@{
    toolSha256 = $approvedToolSha256
    toolSignatureStatus = $SignatureStatus
    toolSignerSubject = $SignerSubject
    toolSignerThumbprint = $approvedSignerThumbprint
    toolTimestampSubject = $TimestampSubject
    toolTimestampThumbprint = if ([string]::IsNullOrWhiteSpace($TimestampThumbprint)) { $null } else { $TimestampThumbprint.ToLowerInvariant() }
  }
}

function Get-HWOSApprovedIntunePreparationToolEvidence {
  [CmdletBinding()]
  param([Parameter(Mandatory = $true)][string]$Path)

  $tool = [IO.Path]::GetFullPath($Path)
  if (-not (Test-Path -LiteralPath $tool -PathType Leaf)) { throw 'IntuneWinAppUtil.exe was not found at the supplied path.' }
  $signature = Get-AuthenticodeSignature -LiteralPath $tool

  $evidence = @{
    ToolSha256 = (Get-FileHash -LiteralPath $tool -Algorithm SHA256).Hash
    SignatureStatus = $signature.Status.ToString()
    SignerSubject = if ($null -eq $signature.SignerCertificate) { '' } else { $signature.SignerCertificate.Subject }
    SignerThumbprint = if ($null -eq $signature.SignerCertificate) { '' } else { $signature.SignerCertificate.Thumbprint }
    TimestampSubject = if ($null -eq $signature.TimeStamperCertificate) { $null } else { $signature.TimeStamperCertificate.Subject }
    TimestampThumbprint = if ($null -eq $signature.TimeStamperCertificate) { $null } else { $signature.TimeStamperCertificate.Thumbprint }
  }
  Assert-HWOSApprovedIntunePreparationToolEvidence @evidence
}

Export-ModuleMember -Function Assert-HWOSApprovedIntunePreparationToolEvidence, Get-HWOSApprovedIntunePreparationToolEvidence
