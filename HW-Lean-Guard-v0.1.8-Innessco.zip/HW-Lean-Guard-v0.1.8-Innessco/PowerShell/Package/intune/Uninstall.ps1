[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$uninstaller = 'C:\Program Files\ClaudeCode\HWOSLeanGuard\deployment\Uninstall-HWOSLeanGuard.ps1'
if (-not (Test-Path -LiteralPath $uninstaller -PathType Leaf)) { exit 1 }
& $uninstaller -Apply -Confirm:$false | Out-Null
exit $LASTEXITCODE
