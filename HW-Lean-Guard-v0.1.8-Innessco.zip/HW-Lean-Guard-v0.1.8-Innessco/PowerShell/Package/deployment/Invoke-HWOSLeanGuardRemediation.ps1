[CmdletBinding()]
param(
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$PersonalContextInstallRoot = 'C:\Program Files\HenryWilliam\PersonalContext',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $PSScriptRoot }
& (Join-Path $PSScriptRoot 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $PackageRoot -InstallRoot $InstallRoot -PersonalContextInstallRoot $PersonalContextInstallRoot -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath | Out-Null
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& (Join-Path $PSScriptRoot 'Detect-HWOSLeanGuard.ps1') -Quiet -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
exit $LASTEXITCODE
