function Test-HWOSLeanGuardPathHasReparsePoint {
  param([Parameter(Mandatory = $true)][string]$Path)
  $candidate = [IO.Path]::GetFullPath($Path)
  while (-not [string]::IsNullOrWhiteSpace($candidate)) {
    if (Test-Path -LiteralPath $candidate) {
      if (((Get-Item -LiteralPath $candidate -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $true }
    }
    $parent = Split-Path -Parent $candidate
    if ($parent -eq $candidate) { break }
    $candidate = $parent
  }
  return $false
}

function Assert-HWOSLeanGuardSafeTree {
  param([Parameter(Mandatory = $true)][string]$Root)
  if (Test-HWOSLeanGuardPathHasReparsePoint -Path $Root) { throw "Destination ancestry contains a reparse point: $Root" }
  if (Test-Path -LiteralPath $Root) {
    foreach ($entry in Get-ChildItem -LiteralPath $Root -Force -Recurse) {
      if (($entry.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Tree contains a reparse point: $($entry.FullName)" }
    }
  }
}

function Assert-HWOSLeanGuardSafeDestination {
  param([Parameter(Mandatory = $true)][string[]]$Path)
  $roots = @()
  $protectedRoots = @('Windows', 'ProgramFiles', 'ProgramFilesX86', 'CommonApplicationData', 'UserProfile', 'CommonDocuments', 'DesktopDirectory', 'ApplicationData', 'LocalApplicationData') | ForEach-Object { [Environment]::GetFolderPath([Environment+SpecialFolder]::$_) } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
  foreach ($candidate in $Path) {
    if ($candidate -notmatch '^[A-Za-z]:\\') { throw 'Deployment destination must be an absolute local path.' }
    $root = [IO.Path]::GetFullPath($candidate).TrimEnd('\')
    if ($root -eq [IO.Path]::GetPathRoot($root).TrimEnd('\')) { throw 'Deployment destination cannot be a volume root.' }
    foreach ($protected in $protectedRoots) {
      if ($root.Equals([IO.Path]::GetFullPath($protected).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Deployment destination cannot be a shared or profile root.' }
    }
    Assert-HWOSLeanGuardSafeTree -Root $root
    foreach ($prior in $roots) {
      if ($root.Equals($prior, [StringComparison]::OrdinalIgnoreCase) -or $root.StartsWith($prior + '\', [StringComparison]::OrdinalIgnoreCase) -or $prior.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Deployment destination roots overlap.' }
    }
    $roots += $root
  }
}

function Resolve-HWOSLeanGuardContainedFile {
  param([Parameter(Mandatory = $true)][string]$Root, [Parameter(Mandatory = $true)][string]$Relative)
  if ([IO.Path]::IsPathRooted($Relative) -or $Relative -match '(^|[\\/])\.\.?([\\/]|$)|:') { throw "Invalid relative file path: $Relative" }
  $fullRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
  $candidate = [IO.Path]::GetFullPath((Join-Path $fullRoot $Relative))
  if (-not $candidate.StartsWith($fullRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "File path escapes root: $Relative" }
  if (Test-HWOSLeanGuardPathHasReparsePoint -Path $candidate) { throw "File path contains a reparse point: $Relative" }
  return $candidate
}

function Get-HWOSLeanGuardFileHashes {
  param([Parameter(Mandatory = $true)][string]$Root)
  $fullRoot = [IO.Path]::GetFullPath($Root).TrimEnd('\')
  Assert-HWOSLeanGuardSafeTree -Root $fullRoot
  $hashes = [ordered]@{}
  foreach ($file in Get-ChildItem -LiteralPath $fullRoot -Recurse -File -Force | Sort-Object FullName) {
    $hashes[$file.FullName.Substring($fullRoot.Length).TrimStart('\')] = Get-HWOSLeanGuardSha256 -Path $file.FullName
  }
  return $hashes
}

function Test-HWOSLeanGuardRecordedFiles {
  param([Parameter(Mandatory = $true)][string]$Root, [Parameter(Mandatory = $true)][object]$Files)
  try {
    Assert-HWOSLeanGuardSafeTree -Root $Root
    if (-not (Test-Path -LiteralPath $Root -PathType Container)) { return $false }
    $properties = @($Files.PSObject.Properties)
    if ($properties.Count -eq 0) { return $false }
    $actual = @(Get-ChildItem -LiteralPath $Root -Recurse -File -Force)
    if ($actual.Count -ne $properties.Count) { return $false }
    $seen = @{}
    foreach ($property in $properties) {
      $path = Resolve-HWOSLeanGuardContainedFile -Root $Root -Relative $property.Name
      if ($seen.ContainsKey($path)) { return $false }
      $seen[$path] = $true
      if ([string]$property.Value -cnotmatch '^[0-9a-f]{64}$' -or -not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-HWOSLeanGuardSha256 -Path $path) -cne [string]$property.Value) { return $false }
    }
    return $true
  } catch { return $false }
}
