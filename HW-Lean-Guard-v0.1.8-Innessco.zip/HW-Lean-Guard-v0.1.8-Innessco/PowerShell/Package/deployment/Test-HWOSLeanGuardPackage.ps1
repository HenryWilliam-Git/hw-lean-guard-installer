[CmdletBinding()]
param([string]$PackageRoot)
$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $PSScriptRoot }
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot
Write-Output "PASS: HW OS Lean Guard package $($manifest.packageVersion) manifest is complete."
