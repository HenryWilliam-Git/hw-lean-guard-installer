function Copy-HWOSLeanGuardTree {
  param([Parameter(Mandatory = $true)][object]$Tree, [Parameter(Mandatory = $true)][string]$StagingRoot)
  [IO.Directory]::CreateDirectory($StagingRoot) | Out-Null
  Set-HWOSLeanGuardTreeAcls -Root $StagingRoot -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F') -FailureLabel 'transaction staging'
  $relativeFiles = @($Tree.relativeFiles)
  if ($relativeFiles.Count -eq 0) { $relativeFiles = @((Get-HWOSLeanGuardFileHashes -Root $Tree.sourceRoot).Keys) }
  foreach ($relative in $relativeFiles) {
    $source = Resolve-HWOSLeanGuardContainedFile -Root $Tree.sourceRoot -Relative $relative
    $destination = Resolve-HWOSLeanGuardContainedFile -Root $StagingRoot -Relative $relative
    [IO.Directory]::CreateDirectory((Split-Path -Parent $destination)) | Out-Null
    Copy-Item -LiteralPath $source -Destination $destination -Force
    if ((Get-HWOSLeanGuardSha256 -Path $source) -cne (Get-HWOSLeanGuardSha256 -Path $destination)) { throw "Staged file hash mismatch: $relative" }
  }
}

function Remove-HWOSLeanGuardTransactionTree {
  param([Parameter(Mandatory = $true)][string]$Path, [Parameter(Mandatory = $true)][string]$Parent)
  $full = [IO.Path]::GetFullPath($Path).TrimEnd('\')
  if (-not (Split-Path -Parent $full).Equals([IO.Path]::GetFullPath($Parent).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Transaction cleanup target escaped its parent.' }
  Assert-HWOSLeanGuardSafeTree -Root $full
  if (Test-Path -LiteralPath $full) { Remove-Item -LiteralPath $full -Recurse -Force }
}

function Invoke-HWOSLeanGuardTwoRootSwap {
  param([Parameter(Mandatory = $true)][object[]]$Trees, [scriptblock]$AfterSwap)
  if ($Trees.Count -ne 2) { throw 'Exactly two deployment roots are required.' }
  Assert-HWOSLeanGuardSafeDestination -Path @($Trees | ForEach-Object { [string]$_.destinationRoot })
  $operationId = [Guid]::NewGuid().ToString('N')
  $records = @()
  $requiredByVolume = @{}
  foreach ($tree in $Trees) {
    Assert-HWOSLeanGuardSafeTree -Root $tree.sourceRoot
    $relativeFiles = @($tree.relativeFiles)
    if ($relativeFiles.Count -eq 0) { $relativeFiles = @((Get-HWOSLeanGuardFileHashes -Root $tree.sourceRoot).Keys) }
    if ($relativeFiles.Count -eq 0) { throw 'Deployment source tree is empty.' }
    $requiredBytes = 0L
    foreach ($relative in $relativeFiles) {
      $source = Resolve-HWOSLeanGuardContainedFile -Root $tree.sourceRoot -Relative $relative
      if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Missing deployment source: $relative" }
      $requiredBytes += (Get-Item -LiteralPath $source).Length
    }
    $volume = [IO.Path]::GetPathRoot([IO.Path]::GetFullPath($tree.destinationRoot))
    if (-not $requiredByVolume.ContainsKey($volume)) { $requiredByVolume[$volume] = 0L }
    $requiredByVolume[$volume] += $requiredBytes * 2
  }
  foreach ($volume in $requiredByVolume.Keys) {
    if ([IO.DriveInfo]::new($volume).AvailableFreeSpace -lt $requiredByVolume[$volume]) { throw "Insufficient staging space on $volume" }
  }
  try {
    foreach ($tree in $Trees) {
      $destination = [IO.Path]::GetFullPath($tree.destinationRoot).TrimEnd('\')
      $parent = Split-Path -Parent $destination
      [IO.Directory]::CreateDirectory($parent) | Out-Null
      $record = [pscustomobject]@{ destination=$destination; parent=$parent; stage=(Join-Path $parent ('.hwos-stage-' + $operationId + '-' + (Split-Path -Leaf $destination))); backup=(Join-Path $parent ('.hwos-backup-' + $operationId + '-' + (Split-Path -Leaf $destination))); backupMoved=$false; promoted=$false }
      $records += $record
      Copy-HWOSLeanGuardTree -Tree $tree -StagingRoot $record.stage
    }
    foreach ($record in $records) {
      Assert-HWOSLeanGuardSafeTree -Root $record.destination
      if (Test-Path -LiteralPath $record.destination) { Move-Item -LiteralPath $record.destination -Destination $record.backup; $record.backupMoved = $true }
      Move-Item -LiteralPath $record.stage -Destination $record.destination
      $record.promoted = $true
    }
    if ($null -ne $AfterSwap) { & $AfterSwap }
  } catch {
    $failure = $_
    $rollbackErrors = @()
    for ($index = $records.Count - 1; $index -ge 0; $index--) {
      $record = $records[$index]
      try {
        if ($record.promoted) { Remove-HWOSLeanGuardTransactionTree -Path $record.destination -Parent $record.parent }
        if ($record.backupMoved) { Move-Item -LiteralPath $record.backup -Destination $record.destination }
        Remove-HWOSLeanGuardTransactionTree -Path $record.stage -Parent $record.parent
      } catch { $rollbackErrors += $_.Exception.Message }
    }
    if ($rollbackErrors.Count -gt 0) { throw "Install failed: $($failure.Exception.Message). Rollback incomplete: $($rollbackErrors -join '; ')" }
    throw $failure
  }
  foreach ($record in $records) {
    try { Remove-HWOSLeanGuardTransactionTree -Path $record.backup -Parent $record.parent } catch { Write-Warning "Install committed; retained backup cleanup failed: $($_.Exception.Message)" }
  }
}

function Invoke-HWOSLeanGuardUninstallTransaction {
  param([Parameter(Mandatory = $true)][string[]]$Roots, [Parameter(Mandatory = $true)][string]$StatePath, [Parameter(Mandatory = $true)][string]$PolicyRegistryPath, [Parameter(Mandatory = $true)][object]$PriorRegistry, [Parameter(Mandatory = $true)][object]$ImmediateRegistry)
  if ($Roots.Count -ne 2) { throw 'Exactly two uninstall roots are required.' }
  $statePathFull = [IO.Path]::GetFullPath($StatePath)
  $stateRoot = Split-Path -Parent (Split-Path -Parent $statePathFull)
  Assert-HWOSLeanGuardSafeDestination -Path @($Roots + @($stateRoot))
  $operation = [Guid]::NewGuid().ToString('N')
  $records = @($Roots | ForEach-Object {
    $destination = [IO.Path]::GetFullPath($_).TrimEnd('\')
    $parent = Split-Path -Parent $destination
    [pscustomobject]@{ destination=$destination; parent=$parent; quarantine=(Join-Path $parent ('.hwos-uninstall-' + $operation + '-' + (Split-Path -Leaf $destination))); moved=$false }
  })
  $receiptQuarantine = Join-Path (Split-Path -Parent $statePathFull) ('install-state.removing-' + $operation + '.json')
  $journalPath = Join-Path $stateRoot ('rollback\uninstall-' + $operation + '.json')
  $journal = [ordered]@{ schemaVersion='hw-os-lean-guard-uninstall-transaction/v1'; status='prepared'; policyRegistryPath=$PolicyRegistryPath; immediateRegistry=$ImmediateRegistry; priorRegistry=$PriorRegistry; statePath=$statePathFull; receiptQuarantine=$receiptQuarantine; roots=$records; cleanupComplete=$false }
  Write-HWOSLeanGuardJson -Path $journalPath -Value $journal
  $receiptMoved = $false
  $policyAttempted = $false
  try {
    foreach ($record in $records) {
      Assert-HWOSLeanGuardSafeTree -Root $record.destination
      if (Test-Path -LiteralPath $record.quarantine) { throw 'Uninstall quarantine already exists.' }
      Move-Item -LiteralPath $record.destination -Destination $record.quarantine
      $record.moved = $true
    }
    $policyAttempted = $true
    Restore-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath -State $PriorRegistry
    $registryReadback = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
    foreach ($field in @('keyExists','valueExists','valueKind','value')) {
      if ($registryReadback.$field -cne $PriorRegistry.$field) { throw 'Uninstall prior registry readback failed.' }
    }
    Move-Item -LiteralPath $statePathFull -Destination $receiptQuarantine
    $receiptMoved = $true
    $journal.status = 'committed'
    Write-HWOSLeanGuardJson -Path $journalPath -Value $journal
  } catch {
    $failure = $_
    $rollbackErrors = @()
    if ($receiptMoved) {
      try { Move-Item -LiteralPath $receiptQuarantine -Destination $statePathFull } catch { $rollbackErrors += $_.Exception.Message }
    }
    if ($policyAttempted) {
      try { Restore-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath -State $ImmediateRegistry } catch { $rollbackErrors += $_.Exception.Message }
    }
    for ($index = $records.Count - 1; $index -ge 0; $index--) {
      $record = $records[$index]
      if ($record.moved) {
        try { Assert-HWOSLeanGuardSafeTree -Root $record.quarantine; Move-Item -LiteralPath $record.quarantine -Destination $record.destination } catch { $rollbackErrors += $_.Exception.Message }
      }
    }
    $journal.status = if ($rollbackErrors.Count -eq 0) { 'rolled-back' } else { 'rollback-incomplete' }
    try { Write-HWOSLeanGuardJson -Path $journalPath -Value $journal } catch { $rollbackErrors += $_.Exception.Message }
    if ($rollbackErrors.Count -gt 0) { throw "Uninstall failed: $($failure.Exception.Message). Rollback incomplete: $($rollbackErrors -join '; '). Recovery journal: $journalPath" }
    throw $failure
  }
  $cleanupErrors = @()
  foreach ($record in $records) {
    try { Remove-HWOSLeanGuardTransactionTree -Path $record.quarantine -Parent $record.parent } catch { $cleanupErrors += $_.Exception.Message }
  }
  try {
    Assert-HWOSLeanGuardSafeTree -Root $receiptQuarantine
    Remove-Item -LiteralPath $receiptQuarantine -Force
  } catch { $cleanupErrors += $_.Exception.Message }
  $journal.cleanupComplete = $cleanupErrors.Count -eq 0
  $journal.status = if ($journal.cleanupComplete) { 'removed' } else { 'cleanup-pending' }
  try { Write-HWOSLeanGuardJson -Path $journalPath -Value $journal } catch { $cleanupErrors += $_.Exception.Message }
  $retainedPaths = @(@($records | ForEach-Object { $_.quarantine }) + @($receiptQuarantine) | Where-Object { Test-Path -LiteralPath $_ })
  return [pscustomobject]@{ committed=$true; cleanupComplete=($cleanupErrors.Count -eq 0); cleanupPending=($cleanupErrors.Count -gt 0); removalStatus=$(if ($cleanupErrors.Count -eq 0) { 'removed' } else { 'removed-cleanup-pending' }); retainedPaths=$retainedPaths; recoveryJournalPath=$journalPath }
}
