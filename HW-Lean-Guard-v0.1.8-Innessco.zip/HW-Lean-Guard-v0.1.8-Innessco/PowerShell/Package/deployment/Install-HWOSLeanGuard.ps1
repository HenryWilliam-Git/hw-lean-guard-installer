[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [switch]$ServerManagedPolicyConfirmed,
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$PersonalContextInstallRoot = 'C:\Program Files\HenryWilliam\PersonalContext',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $PSScriptRoot }
$PackageRoot = [IO.Path]::GetFullPath($PackageRoot)
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot
$sourceManifestSha256 = Get-HWOSLeanGuardSha256 -Path (Join-Path $PackageRoot 'manifest.json')
$bootstrapSource = Join-Path $PackageRoot 'policy\endpoint-bootstrap-settings.json'
$candidateSource = Join-Path $PackageRoot 'policy\server-managed-settings.json'
$personalContextSource = Join-Path $PackageRoot 'personal-context'
$bootstrapText = [IO.File]::ReadAllText($bootstrapSource, [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
$preview = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-install-preview/v2'
  applyRequested = [bool]$Apply
  serverManagedPolicyConfirmed = [bool]$ServerManagedPolicyConfirmed
  packageVersion = [string]$manifest.packageVersion
  installRoots = [ordered]@{ leanGuard = $InstallRoot; personalContext = $PersonalContextInstallRoot }
  stateRoot = $StateRoot
  policyRegistryPath = $PolicyRegistryPath
  runtimePrerequisites = [ordered]@{ dotnetVersion = '8.0.30'; dotnetArchitecture = 'x64' }
  sourceDriveAclsChanged = $false
  userAppDataChanged = $false
  environmentVariablesChanged = $false
  workbenchExclusionsConfigured = $false
  fsLogixConfigured = $false
  settingsChannel = 'remote-refresh-bootstrap-only'
}
if (-not $Apply) { $preview | ConvertTo-Json -Depth 10; return }
if (-not $ServerManagedPolicyConfirmed) { throw 'Apply requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).' }
if (-not (Test-HWOSLeanGuardAdministrator)) { throw 'Apply requires an elevated Administrator PowerShell.' }
if (-not $PSCmdlet.ShouldProcess("$InstallRoot; $PersonalContextInstallRoot", 'Install HW OS Lean Guard and Personal Context, then write the HKLM remote-refresh bootstrap')) { return }

if (-not (Test-HWOSLeanGuardDotNetPrerequisite)) { throw 'The exact x64 .NET runtime prerequisite 8.0.30 is not installed.' }
Assert-HWOSLeanGuardSafeDestination -Path @($InstallRoot, $PersonalContextInstallRoot, $StateRoot)
Assert-HWOSLeanGuardSafeDestination -Path @($InstallRoot, $PersonalContextInstallRoot, $PackageRoot)
$fullStateRoot = [IO.Path]::GetFullPath($StateRoot).TrimEnd('\')
$fullPackageRoot = $PackageRoot.TrimEnd('\')
if ($fullStateRoot.Equals($fullPackageRoot, [StringComparison]::OrdinalIgnoreCase) -or $fullStateRoot.StartsWith($fullPackageRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Deployment destination roots overlap: state would modify the source package.' }
if (-not (Test-Path -LiteralPath $personalContextSource -PathType Container)) { throw 'Personal Context deployment subtree is missing.' }

$leanGuardFiles = @(
  'runtime\Invoke-HWOSLeanGuard.ps1',
  'runtime\HWOS.PowerShellAnalysis.ps1',
  'runtime\HWOS.BashAnalysis.ps1',
  'runtime\HWOS.ShellAnalysis.ps1',
  'runtime\Invoke-HWOSLitigationPromptGuard.ps1',
  'runtime\Invoke-HWOSContextBroker.ps1',
  'runtime\Invoke-HWOSPersonalContextSessionStart.ps1',
  'policy\guard-policy.json',
  'policy\endpoint-bootstrap-settings.json',
  'policy\server-managed-settings.json',
  'policy\org-instructions.md',
  'deployment\HWOSLeanGuard.Deployment.psm1',
  'deployment\HWOSLeanGuard.Paths.ps1',
  'deployment\HWOSLeanGuard.Transaction.ps1',
  'deployment\HWOSLeanGuard.State.ps1',
  'deployment\Configure-HWOSClaudeWorkbench.ps1',
  'deployment\Detect-HWOSLeanGuard.ps1',
  'deployment\Uninstall-HWOSLeanGuard.ps1',
  'deployment\Invoke-HWOSLeanGuardRemediation.ps1'
)
foreach ($relative in $leanGuardFiles) { if (-not (Test-Path -LiteralPath (Join-Path $PackageRoot $relative) -PathType Leaf)) { throw "Required Lean Guard deployable is missing: $relative" } }

$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss-fff') + '-' + [Guid]::NewGuid().ToString('N')
$rollbackPath = Join-Path $StateRoot "rollback\prestate-$stamp.json"
$statePath = Join-Path $StateRoot 'state\install-state.json'
$evidencePath = Join-Path $StateRoot "evidence\install-$stamp.json"
$previousStateExists = Test-Path -LiteralPath $statePath -PathType Leaf
if (-not $previousStateExists) {
  foreach ($target in @($InstallRoot, $PersonalContextInstallRoot)) {
    if ((Test-Path -LiteralPath $target) -and (-not (Test-Path -LiteralPath $target -PathType Container) -or @(Get-ChildItem -LiteralPath $target -Force).Count -gt 0)) { throw 'Existing machine install requires its install receipt; refusing to overwrite unknown prestate.' }
  }
}
$previousStateBytes = if ($previousStateExists) { [IO.File]::ReadAllBytes([IO.Path]::GetFullPath($statePath)) } else { $null }
$previousReceipt = if ($previousStateExists) { Read-HWOSLeanGuardJson -Path $statePath } else { $null }
if ($previousStateExists -and -not (Test-HWOSLeanGuardReceiptUpgradePrestate -State $previousReceipt)) { throw 'Existing install receipt is not an accepted v1 upgrade prestate or v2 reinstall prestate.' }
$uninstallRegistry = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
if ($previousStateExists) {
  $previousRoots = @(if ([string]$previousReceipt.schemaVersion -ceq 'hw-os-lean-guard-state/v1') { [string]$previousReceipt.installRoot } else { [string]$previousReceipt.installRoots.leanGuard; [string]$previousReceipt.installRoots.personalContext })
  $expectedRoots = @($InstallRoot, $PersonalContextInstallRoot)
  for ($index = 0; $index -lt $previousRoots.Count; $index++) {
    if (-not ([IO.Path]::GetFullPath($previousRoots[$index])).Equals([IO.Path]::GetFullPath($expectedRoots[$index]), [StringComparison]::OrdinalIgnoreCase)) { throw 'Prior receipt install root differs from this upgrade target.' }
  }
  if ([string]$previousReceipt.policyRegistryPath -cne $PolicyRegistryPath) { throw 'Prior receipt registry target differs from this upgrade target.' }
  $priorRollbackPath = if ([string]$previousReceipt.schemaVersion -ceq 'hw-os-lean-guard-state/v1') { [string]$previousReceipt.preStatePath } else { [string]$previousReceipt.rollbackReceiptPath }
  $rollbackRoot = [IO.Path]::GetFullPath((Join-Path $StateRoot 'rollback')).TrimEnd('\')
  if (-not (Split-Path -Parent ([IO.Path]::GetFullPath($priorRollbackPath))).Equals($rollbackRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Prior rollback receipt is outside the state rollback root.' }
  $priorPrestate = Read-HWOSLeanGuardJson -Path $priorRollbackPath
  if ([string]$priorPrestate.policyRegistryPath -cne $PolicyRegistryPath) { throw 'Prior rollback registry target differs from this upgrade target.' }
  $uninstallRegistry = $priorPrestate.registry
}
$priorInstallation = if ($previousStateExists) {
  [ordered]@{
    receiptSha256 = Get-HWOSLeanGuardSha256 -Path $statePath
    packageVersion = [string]$previousReceipt.packageVersion
    checkStatus = if ([string]$previousReceipt.schemaVersion -ceq 'hw-os-lean-guard-state/v2') { 'evaluated' } else { 'unsupported-receipt' }
    checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
  }
} else { $null }
$preState = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-prestate/v2'
  capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
  policyRegistryPath = $PolicyRegistryPath
  registry = $uninstallRegistry
  immediateRegistry = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
  priorReceipt = $previousReceipt
  installRoots = [ordered]@{
    leanGuard = [ordered]@{ path = [IO.Path]::GetFullPath($InstallRoot); existed = (Test-Path -LiteralPath $InstallRoot) }
    personalContext = [ordered]@{ path = [IO.Path]::GetFullPath($PersonalContextInstallRoot); existed = (Test-Path -LiteralPath $PersonalContextInstallRoot) }
  }
}
Write-HWOSLeanGuardJson -Path $rollbackPath -Value $preState

try {
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'state')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'evidence')) | Out-Null
  [IO.Directory]::CreateDirectory((Join-Path $StateRoot 'logs')) | Out-Null
  $trees = @(
    [pscustomobject]@{ sourceRoot = $PackageRoot; destinationRoot = $InstallRoot; relativeFiles = $leanGuardFiles },
    [pscustomobject]@{ sourceRoot = $personalContextSource; destinationRoot = $PersonalContextInstallRoot; relativeFiles = @() }
  )
  $completeInstall = {
    if (-not (Test-Path -LiteralPath $PolicyRegistryPath)) { New-Item -Path $PolicyRegistryPath | Out-Null }
    New-ItemProperty -LiteralPath $PolicyRegistryPath -Name 'Settings' -Value $bootstrapText -PropertyType String -Force | Out-Null
    $state = [ordered]@{
      schemaVersion = 'hw-os-lean-guard-state/v2'
      packageVersion = [string]$manifest.packageVersion
      sourceManifestSha256 = $sourceManifestSha256
      priorInstallation = $priorInstallation
      installedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
      installRoots = [ordered]@{ leanGuard = [IO.Path]::GetFullPath($InstallRoot); personalContext = [IO.Path]::GetFullPath($PersonalContextInstallRoot) }
      policyRegistryPath = $PolicyRegistryPath
      managedSettingsCandidateSha256 = Get-HWOSLeanGuardSha256 -Path $candidateSource
      bootstrapSha256 = Get-HWOSLeanGuardTextSha256 -Text $bootstrapText
      runtimePrerequisites = [ordered]@{ dotnetVersion = '8.0.30'; dotnetArchitecture = 'x64' }
      files = [ordered]@{ leanGuard = Get-HWOSLeanGuardFileHashes -Root $InstallRoot; personalContext = Get-HWOSLeanGuardFileHashes -Root $PersonalContextInstallRoot }
      rollbackReceiptPath = [IO.Path]::GetFullPath($rollbackPath)
    }
    Write-HWOSLeanGuardJson -Path $statePath -Value $state
    Set-HWOSLeanGuardAcls -InstallRoot $InstallRoot -PersonalContextRoot $PersonalContextInstallRoot -StateRoot $StateRoot
    $checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
    if (@($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'Installed policy and Personal Context readback failed.' }
    $evidence = [ordered]@{
      schemaVersion = 'hw-os-lean-guard-evidence/v2'
      capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
      packageVersion = [string]$manifest.packageVersion
      sourceManifestSha256 = $sourceManifestSha256
      priorInstallation = $priorInstallation
      checks = $checks
      userAppDataChanged = $false
      environmentVariablesChanged = $false
      workbenchExclusionsConfigured = $false
      fsLogixConfigured = $false
      result = 'PASS'
    }
    Write-HWOSLeanGuardJson -Path $evidencePath -Value $evidence
  }.GetNewClosure()
  Invoke-HWOSLeanGuardTwoRootSwap -Trees $trees -AfterSwap $completeInstall
  Read-HWOSLeanGuardJson -Path $evidencePath | ConvertTo-Json -Depth 12
} catch {
  $failure = $_
  $rollbackFailures = @()
  try { Restore-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath -State $preState.immediateRegistry } catch { $rollbackFailures += $_.Exception.Message }
  try {
    if ($previousStateExists) {
      [IO.Directory]::CreateDirectory((Split-Path -Parent ([IO.Path]::GetFullPath($statePath)))) | Out-Null
      [IO.File]::WriteAllBytes([IO.Path]::GetFullPath($statePath), $previousStateBytes)
    } elseif (Test-Path -LiteralPath $statePath) { Remove-Item -LiteralPath $statePath -Force }
  } catch { $rollbackFailures += $_.Exception.Message }
  if ($rollbackFailures.Count -gt 0) { throw "Install failed: $($failure.Exception.Message). State rollback incomplete: $($rollbackFailures -join '; ')" }
  throw $failure
}
