<# Emits advisory Personal Context briefing data for a new Claude Code session. #>
[CmdletBinding()]
param(
  [string]$PersonalContextPath = 'C:\Program Files\HenryWilliam\PersonalContext\HWPersonalContext.exe',
  [string]$PersonalContextHostPath = '',
  [string]$PersonalContextHostArgumentsPrefix = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File',
  [ValidateRange(1, 900)][int]$PersonalContextTimeoutMilliseconds = 900
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Stop-HWOSSessionStartProcessTree {
  param([Parameter(Mandatory = $true)][System.Diagnostics.Process]$Process)
  if (-not $Process.HasExited) {
    $previousErrorAction = $ErrorActionPreference
    try {
      $ErrorActionPreference = 'SilentlyContinue'
      & "$env:SystemRoot\System32\taskkill.exe" /PID $Process.Id /T /F 2>$null | Out-Null
    } finally {
      $ErrorActionPreference = $previousErrorAction
    }
  }
}

function Get-HWOSPersonalContextBriefing {
  param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Output)

  if ([string]::IsNullOrWhiteSpace($Output)) { return $null }
  $response = $output | ConvertFrom-Json -ErrorAction Stop
  if ($null -eq $response -or
      $response.schemaVersion -cne 'hw-personal-context-cli/v1' -or
      $response.command -cne 'briefing' -or
      $response.ok -ne $true -or
      $null -eq $response.data -or
      $response.data.context -isnot [string] -or
      [string]::IsNullOrWhiteSpace([string]$response.data.context)) { return $null }
  return [string]$response.data.context
}

function New-HWOSSessionStartOutput {
  param([Parameter(Mandatory = $true)][string]$Context)

  return ([ordered]@{
    hookSpecificOutput = [ordered]@{
      hookEventName = 'SessionStart'
      additionalContext = $Context
    }
  } | ConvertTo-Json -Depth 4 -Compress)
}

function Invoke-HWOSPersonalContextSessionStartMain {
  $process = $null
  try {
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    if ([string]::IsNullOrWhiteSpace($PersonalContextHostPath)) {
      $startInfo.FileName = $PersonalContextPath
      $startInfo.Arguments = 'briefing'
    } else {
      $escapedPersonalPath = $PersonalContextPath.Replace('"', '\"')
      $startInfo.FileName = $PersonalContextHostPath
      $startInfo.Arguments = "$PersonalContextHostArgumentsPrefix `"$escapedPersonalPath`" briefing"
    }
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    if ($null -ne $startInfo.PSObject.Properties['StandardOutputEncoding']) { $startInfo.StandardOutputEncoding = [Text.UTF8Encoding]::new($false) }
    if ($null -ne $startInfo.PSObject.Properties['StandardErrorEncoding']) { $startInfo.StandardErrorEncoding = [Text.UTF8Encoding]::new($false) }
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    if (-not $process.Start()) { return }
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $null = $process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit($PersonalContextTimeoutMilliseconds)) {
      Stop-HWOSSessionStartProcessTree -Process $process
      [void]$process.WaitForExit(1000)
      return
    }
    if ($process.ExitCode -ne 0) { return }
    $context = Get-HWOSPersonalContextBriefing -Output $outputTask.GetAwaiter().GetResult()
    if (-not [string]::IsNullOrWhiteSpace($context)) { Write-Output (New-HWOSSessionStartOutput -Context $context) }
  } catch {
    # Personal Context is advisory. Do not expose child failures or input in hook output.
    return
  } finally {
    if ($null -ne $process) { $process.Dispose() }
  }
}

if ($MyInvocation.InvocationName -cne '.') { Invoke-HWOSPersonalContextSessionStartMain }
