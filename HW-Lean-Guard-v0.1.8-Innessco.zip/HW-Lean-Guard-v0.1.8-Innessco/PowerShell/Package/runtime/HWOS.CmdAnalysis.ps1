function New-HWOSCmdWord {
  param([string]$Value, [hashtable]$Bindings)
  $candidates = New-Object 'System.Collections.Generic.List[string]'
  $candidates.Add($Value)
  $variables = @([regex]::Matches($Value, '%(?<name>[^%]+)%|!(?<name>[^!]+)!'))
  $unresolved = $false
  foreach ($variable in $variables) {
    $name = $variable.Groups['name'].Value
    if ($Bindings.ContainsKey($name)) {
      foreach ($candidate in @($Bindings[$name])) { $candidates.Add($candidate) }
    } elseif ($null -ne [Environment]::GetEnvironmentVariable($name)) {
      $candidates.Add([Environment]::GetEnvironmentVariable($name))
    } else {
      $unresolved = $true
    }
  }
  foreach ($part in @($Value -split '\+')) {
    if ($part -ne $Value -and [IO.Path]::IsPathRooted($part)) { $candidates.Add($part) }
  }
  return [pscustomobject]@{
    Value = $Value
    Literal = ($variables.Count -eq 0)
    Candidates = $candidates.ToArray()
    Parameter = ($Value -match '^/[A-Za-z?]+(?::.*)?$')
    Unresolved = $unresolved
  }
}

function Get-HWOSCmdCommands {
  param([string]$Text)
  $commands = New-Object 'System.Collections.Generic.List[object]'
  $words = New-Object 'System.Collections.Generic.List[object]'
  $buffer = New-Object Text.StringBuilder
  $bindings = @{}
  $quoted = $false
  $active = $false
  $pending = ''
  for ($i = 0; $i -le $Text.Length; $i++) {
    $character = if ($i -lt $Text.Length) { $Text[$i] } else { [char]0 }
    if ($character -eq '^' -and -not $quoted -and $i + 1 -lt $Text.Length) {
      $i++
      if ($Text[$i] -eq "`r" -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -eq "`n") { $i++ }
      if ($Text[$i] -notin @("`r", "`n")) {
        [void]$buffer.Append($Text[$i])
        $active = $true
      }
      continue
    }
    if ($character -eq '"') {
      $quoted = -not $quoted
      $active = $true
      continue
    }
    $boundary = $character -eq [char]0 -or (-not $quoted -and ([char]::IsWhiteSpace($character) -or $character -in @('&', '|', '>', '<', '(', ')')))
    if (-not $boundary) {
      [void]$buffer.Append($character)
      $active = $true
      continue
    }
    if ($active) {
      $value = $buffer.ToString()
      $descriptor = $character -in @('>', '<') -and $value -match '^\d+$'
      if (-not $descriptor) {
        $word = New-HWOSCmdWord $value $bindings
        if ($pending) {
          if ($pending -notmatch '&$') {
            $commands.Add([pscustomobject]@{
              Name = $(if ($pending.StartsWith('>')) { '__write' } else { '__read' })
              Words = @($word)
              Single = $false
              Dialect = 'Cmd'
              Redirect = $true
              DynamicName = $false
            })
          }
          $pending = ''
        } else {
          $words.Add($word)
        }
      }
      [void]$buffer.Clear()
      $active = $false
    }
    if ($character -in @('>', '<')) {
      $pending = [string]$character
      if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq $character) { $pending += $Text[++$i] }
      if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '&') { $pending += '&'; $i++ }
      continue
    }
    if ($character -eq [char]0 -or $character -in @("`r", "`n", '&', '|', '(', ')')) {
      if ($words.Count -gt 0) {
        $name = $words[0].Value.TrimStart('@')
        if ($name -eq 'set' -and $words.Count -gt 1) {
          $assignment = ($words.ToArray() | Select-Object -Skip 1 | ForEach-Object { $_.Value }) -join ' '
          if ($assignment -match '^(?<name>[A-Za-z_][A-Za-z0-9_]*)=(?<value>.*)$') {
            $key = $Matches['name']
            $values = @($Matches['value'])
            if ($bindings.ContainsKey($key)) { $values = @($bindings[$key]) + $values }
            $bindings[$key] = $values
          }
        }
        $commands.Add([pscustomobject]@{
          Name = $name
          Words = @($words.ToArray() | Select-Object -Skip 1)
          Single = $false
          Dialect = 'Cmd'
          Redirect = $false
          DynamicName = (-not $words[0].Literal)
        })
        $words.Clear()
      }
    }
  }
  if ($pending) { throw 'Incomplete CMD redirection.' }
  return $commands.ToArray()
}
