function New-HWOSCmdWord {
  param([string]$Value, [hashtable]$Bindings)
  $variables = @([regex]::Matches($Value, '%(?<name>[^%]+)%|!(?<name>[^!]+)!'))
  $expansions = @($variables | ForEach-Object { [pscustomobject]@{ Index=$_.Index; Length=$_.Length; Name=$_.Groups['name'].Value } })
  $resolution = Resolve-HWOSBoundText $Value $Bindings $expansions
  $candidates = New-Object 'System.Collections.Generic.List[string]'
  foreach ($candidate in @($resolution.Values)) {
    $candidates.Add($candidate)
    foreach ($part in @($candidate -split '\+')) {
      if ($part -ne $candidate -and [IO.Path]::IsPathRooted($part)) { $candidates.Add($part) }
    }
  }
  return [pscustomobject]@{
    Value = $Value
    Literal = ($variables.Count -eq 0)
    Candidates = $candidates.ToArray()
    Parameter = ($Value -match '^/[A-Za-z?]+(?::.*)?$')
    Unresolved = (-not $resolution.Complete)
    BareUnboundVariable = $false
  }
}

function Add-HWOSCmdHead {
  param($Words, [string]$Value, [hashtable]$Bindings)
  $head = [regex]::Match($Value, '^(?i)(?<name>@?(?:copy|move|del|erase|rd|rmdir|ren|rename|md|mkdir|cd|chdir|type))(?<options>/.*)$')
  if ($Words.Count -eq 0 -and $head.Success) {
    $Words.Add((New-HWOSCmdWord $head.Groups['name'].Value $Bindings))
    foreach ($option in [regex]::Matches($head.Groups['options'].Value, '/[^/]+')) {
      $Words.Add((New-HWOSCmdWord $option.Value $Bindings))
    }
  } else {
    $Words.Add((New-HWOSCmdWord $Value $Bindings))
  }
}

function Get-HWOSCmdCommands {
  param([string]$Text)
  $commands = New-Object 'System.Collections.Generic.List[object]'
  $words = New-Object 'System.Collections.Generic.List[object]'
  $buffer = New-Object Text.StringBuilder
  $bindings = @{}
  $quoted = $false
  $active = $false
  $pending = ''
  for ($i = 0; $i -le $Text.Length; $i++) {
    $character = if ($i -lt $Text.Length) { $Text[$i] } else { [char]0 }
    if ($character -eq '^' -and -not $quoted -and $i + 1 -lt $Text.Length) {
      $i++
      if ($Text[$i] -eq "`r" -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -eq "`n") { $i++ }
      if ($Text[$i] -notin @("`r", "`n")) {
        [void]$buffer.Append($Text[$i])
        $active = $true
      }
      continue
    }
    if ($character -eq '"') {
      if (-not $quoted -and $words.Count -eq 0 -and $active -and $buffer.ToString() -match '^(?i)@?(?:copy|move|del|erase|rd|rmdir|ren|rename|md|mkdir|cd|chdir|type)(?:/.*)?$') {
        Add-HWOSCmdHead $words $buffer.ToString() $bindings
        [void]$buffer.Clear()
        $active = $false
      }
      $quoted = -not $quoted
      $active = $true
      continue
    }
    $boundary = $character -eq [char]0 -or (-not $quoted -and ([char]::IsWhiteSpace($character) -or $character -in @('&', '|', '>', '<', '(', ')')))
    if (-not $boundary) {
      [void]$buffer.Append($character)
      $active = $true
      continue
    }
    if ($active) {
      $value = $buffer.ToString()
      $descriptor = $character -in @('>', '<') -and $value -match '^\d+$'
      if (-not $descriptor) {
        $word = New-HWOSCmdWord $value $bindings
        if ($pending) {
          if ($pending -notmatch '&$') {
            $commands.Add([pscustomobject]@{
              Name = $(if ($pending.StartsWith('>')) { '__write' } else { '__read' })
              Words = @($word)
              Single = $false
              Dialect = 'Cmd'
              Redirect = $true
              DynamicName = $false
            })
          }
          $pending = ''
        } else {
          Add-HWOSCmdHead $words $value $bindings
        }
      }
      [void]$buffer.Clear()
      $active = $false
    }
    if ($character -in @('>', '<')) {
      $pending = [string]$character
      if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq $character) { $pending += $Text[++$i] }
      if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '&') { $pending += '&'; $i++ }
      continue
    }
    if ($character -eq [char]0 -or $character -in @("`r", "`n", '&', '|', '(', ')')) {
      if ($words.Count -gt 0) {
        $name = $words[0].Value.TrimStart('@')
        if ($name -eq 'set' -and $words.Count -gt 1) {
          $assignment = ($words.ToArray() | Select-Object -Skip 1 | ForEach-Object { $_.Value }) -join ' '
          if ($assignment -match '^(?<name>[A-Za-z_][A-Za-z0-9_]*)=(?<value>.*)$') {
            $key = $Matches['name']
            $assignmentWord = New-HWOSCmdWord $assignment $bindings
            $values = @($assignmentWord.Candidates | ForEach-Object { $_.Substring($key.Length + 1) })
            Set-HWOSBoundText $bindings $key ([pscustomobject]@{ Values=$values; Complete=(-not $assignmentWord.Unresolved) })
          }
        }
        $commands.Add([pscustomobject]@{
          Name = $name
          Words = @($words.ToArray() | Select-Object -Skip 1)
          Single = $false
          Dialect = 'Cmd'
          Redirect = $false
          DynamicName = (-not $words[0].Literal)
        })
        $words.Clear()
      }
    }
  }
  if ($pending) { throw 'Incomplete CMD redirection.' }
  return $commands.ToArray()
}
