function Get-HWOSPowerShellWord {
  param($Node, [hashtable]$Bindings)
  $literal = $Node -is [Management.Automation.Language.StringConstantExpressionAst] -or $Node -is [Management.Automation.Language.ConstantExpressionAst]
  $value = if ($literal) {
    [string]$Node.Value
  } else {
    ''
  }
  $candidates = New-Object 'System.Collections.Generic.List[string]'
  if ($literal) {
    $candidates.Add($value)
  } else {
    if ($Node -is [Management.Automation.Language.ExpandableStringExpressionAst]) {
      $candidates.Add([string]$Node.Value)
    }
    foreach ($child in @($Node.FindAll({
      param($n)
      $n -is [Management.Automation.Language.StringConstantExpressionAst] -or $n -is [Management.Automation.Language.VariableExpressionAst]
    }, $true))) {
      if ($child -is [Management.Automation.Language.VariableExpressionAst]) {
        $key = $child.VariablePath.UserPath
        if ($Bindings.ContainsKey($key)) {
          foreach ($item in @($Bindings[$key])) {
            $candidates.Add($item)
          }
        }
      } else {
        $candidates.Add([string]$child.Value)
      }
    }
  }
  return [pscustomobject]@{
    Value = $value
    Literal = $literal
    Candidates = @($candidates)
    Parameter = $false
  }
}

function Get-HWOSPowerShellCommands {
  param([string]$Text)
  $tokens = $null
  $errors = $null
  $ast = [Management.Automation.Language.Parser]::ParseInput($Text, [ref]$tokens, [ref]$errors)
  $bindings = @{}
  foreach ($assignment in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.AssignmentStatementAst]
  }, $true))) {
    if ($assignment.Left -is [Management.Automation.Language.VariableExpressionAst]) {
      $key = $assignment.Left.VariablePath.UserPath
      $values = @($assignment.Right.FindAll({
        param($n)
        $n -is [Management.Automation.Language.StringConstantExpressionAst]
      }, $true) | ForEach-Object {
        [string]$_.Value
      })
      if ($bindings.ContainsKey($key)) {
        $bindings[$key] = @($bindings[$key]) + $values
      } else {
        $bindings[$key] = $values
      }
    }
  }
  $commands = @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.CommandAst]
  }, $true))
  $single = @($errors).Count -eq 0 -and $null -eq $ast.BeginBlock -and $null -eq $ast.ProcessBlock -and $null -eq $ast.DynamicParamBlock -and $null -eq $ast.ParamBlock -and $null -ne $ast.EndBlock
  if ($single) {
    $statements = @($ast.EndBlock.Statements)
    $single = $statements.Count -eq 1 -and $statements[0] -is [Management.Automation.Language.PipelineAst]
    if ($single) {
      $single = @($statements[0].PipelineElements).Count -eq 1 -and $commands.Count -eq 1 -and [object]::ReferenceEquals($statements[0].PipelineElements[0], $commands[0])
    }
  }
  foreach ($command in $commands) {
    $words = New-Object 'System.Collections.Generic.List[object]'
    foreach ($element in @($command.CommandElements | Select-Object -Skip 1)) {
      if ($element -is [Management.Automation.Language.CommandParameterAst]) {
        $words.Add([pscustomobject]@{
          Value = '-' + $element.ParameterName
          Literal = $true
          Candidates = @()
          Parameter = $true
        })
        if ($null -ne $element.Argument) {
          $words.Add((Get-HWOSPowerShellWord $element.Argument $bindings))
        }
      } else {
        $words.Add((Get-HWOSPowerShellWord $element $bindings))
      }
    }
    [pscustomobject]@{
      Name = [string]$command.GetCommandName()
      Words = $words.ToArray()
      Single = $single
      Dialect = 'PowerShell'
      Redirect = $false
      DynamicName = ($null -eq $command.GetCommandName())
    }
  }
  foreach ($redirect in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.FileRedirectionAst]
  }, $true))) {
    [pscustomobject]@{
      Name = '__write'
      Words = @((Get-HWOSPowerShellWord $redirect.Location $bindings))
      Single = $false
      Dialect = 'PowerShell'
      Redirect = $true
      DynamicName = $false
    }
  }
  foreach ($member in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.InvokeMemberExpressionAst]
  }, $true))) {
    $name = [string]$member.Member.Value
    if ($name -match '^(?i)(WriteAllText|WriteAllBytes|WriteAllLines|AppendAllText|AppendAllLines|Delete|Move|Copy|Create|CreateDirectory|OpenWrite)$') {
      $words = @($member.Arguments | ForEach-Object {
        Get-HWOSPowerShellWord $_ $bindings
      })
      if ($words.Count -gt 0) {
        if ($name -eq 'Copy' -and $words.Count -gt 1) {
          [pscustomobject]@{
            Name = 'copy-item'
            Words = @($words[0], $words[1])
            Single = $false
            Dialect = 'PowerShell'
            Redirect = $false
            DynamicName = $false
          }
          continue
        }
        $mutationWords = if ($name -eq 'Move' -and $words.Count -gt 1) {
          @($words[0], $words[1])
        } else {
          @($words[0])
        }
        [pscustomobject]@{
          Name = if ($name -eq 'Delete') { 'remove-item' } else { '__write' }
          Words = $mutationWords
          Single = $false
          Dialect = 'PowerShell'
          Redirect = $false
          DynamicName = $false
        }
      }
    }
  }
}
