function Resolve-HWOSPowerShellExpansion {
  param($Node, [hashtable]$Bindings, [int]$Depth, [string[]]$Seen)
  $unknown = [pscustomobject]@{ Values = @(); Complete = $false }
  $expressions = @($Node.NestedExpressions)
  if ($expressions.Count -gt 64) { return $unknown }
  $text = $Node.Extent.Text
  $markerRoot = '__HWOS_OPERAND_'
  while ($text.Contains($markerRoot) -or $Node.Value.Contains($markerRoot)) { $markerRoot += '_' }
  for ($i = $expressions.Count - 1; $i -ge 0; $i--) {
    $offset = $expressions[$i].Extent.StartOffset - $Node.Extent.StartOffset
    $length = $expressions[$i].Extent.EndOffset - $expressions[$i].Extent.StartOffset
    $text = $text.Remove($offset, $length).Insert($offset, ($markerRoot + $i + '_'))
  }
  $tokens = $null
  $errors = $null
  $marked = [Management.Automation.Language.Parser]::ParseInput($text, [ref]$tokens, [ref]$errors)
  $literals = @($marked.FindAll({
    param($n)
    $n -is [Management.Automation.Language.StringConstantExpressionAst]
  }, $true))
  $dynamic = @($marked.FindAll({
    param($n)
    $n -is [Management.Automation.Language.ExpressionAst] -and $n -isnot [Management.Automation.Language.StringConstantExpressionAst]
  }, $true))
  if (@($errors).Count -ne 0 -or $literals.Count -ne 1 -or $dynamic.Count -ne 0) { return $unknown }
  $template = [string]$literals[0].Value
  $resolution = [pscustomobject]@{ Values = @(''); Complete = $true }
  $cursor = 0
  for ($i = 0; $i -lt $expressions.Count; $i++) {
    $marker = $markerRoot + $i + '_'
    $offset = $template.IndexOf($marker, $cursor, [StringComparison]::Ordinal)
    if ($offset -lt 0) { return $unknown }
    $segment = [pscustomobject]@{ Values = @($template.Substring($cursor, $offset - $cursor)); Complete = $true }
    $resolution = Join-HWOSPathResolutions $resolution $segment
    $nested = Resolve-HWOSPowerShellString $expressions[$i] $Bindings ($Depth + 1) $Seen
    $resolution = Join-HWOSPathResolutions $resolution $nested
    $cursor = $offset + $marker.Length
  }
  $suffix = [pscustomobject]@{ Values = @($template.Substring($cursor)); Complete = $true }
  return Join-HWOSPathResolutions $resolution $suffix
}

function Resolve-HWOSPowerShellString {
  param($Node, [hashtable]$Bindings, [int]$Depth = 0, [string[]]$Seen = @())
  $unknown = [pscustomobject]@{ Values = @(); Complete = $false }
  if ($null -eq $Node -or $Depth -gt 16) { return $unknown }
  if ($Node -is [string] -or $Node -is [Management.Automation.Language.StringConstantExpressionAst]) {
    $value = if ($Node -is [string]) { $Node } else { [string]$Node.Value }
    return [pscustomobject]@{ Values = @($value); Complete = $true }
  }
  if ($Node -is [Management.Automation.Language.VariableExpressionAst]) {
    $key = $Node.VariablePath.UserPath
    if ($Node.Splatted -or -not $Bindings.ContainsKey($key) -or $Seen -contains $key) { return $unknown }
    $values = New-Object 'System.Collections.Generic.List[string]'
    $complete = @($Bindings[$key]).Count -gt 0
    foreach ($binding in @($Bindings[$key])) {
      $resolved = Resolve-HWOSPowerShellString $binding $Bindings ($Depth + 1) (@($Seen) + $key)
      $complete = $complete -and $resolved.Complete
      foreach ($value in @($resolved.Values)) {
        if ($values.Contains($value)) { continue }
        if ($values.Count -ge 64) { return [pscustomobject]@{ Values = $values.ToArray(); Complete = $false } }
        $values.Add($value)
      }
    }
    return [pscustomobject]@{ Values = $values.ToArray(); Complete = $complete }
  }
  if ($Node -is [Management.Automation.Language.BinaryExpressionAst] -and $Node.Operator -eq [Management.Automation.Language.TokenKind]::Plus) {
    $left = Resolve-HWOSPowerShellString $Node.Left $Bindings ($Depth + 1) $Seen
    $right = Resolve-HWOSPowerShellString $Node.Right $Bindings ($Depth + 1) $Seen
    return Join-HWOSPathResolutions $left $right
  }
  if ($Node -is [Management.Automation.Language.ExpandableStringExpressionAst]) {
    return Resolve-HWOSPowerShellExpansion $Node $Bindings $Depth $Seen
  }
  $child = $null
  if ($Node -is [Management.Automation.Language.ParenExpressionAst]) {
    $child = $Node.Pipeline
  } elseif ($Node -is [Management.Automation.Language.SubExpressionAst]) {
    $child = $Node.SubExpression
  } elseif ($Node -is [Management.Automation.Language.StatementBlockAst] -and @($Node.Statements).Count -eq 1 -and ($null -eq $Node.Traps -or @($Node.Traps).Count -eq 0)) {
    $child = $Node.Statements[0]
  } elseif ($Node -is [Management.Automation.Language.PipelineAst] -and @($Node.PipelineElements).Count -eq 1 -and ($null -eq $Node.PSObject.Properties['Background'] -or -not $Node.Background)) {
    $child = $Node.PipelineElements[0]
  } elseif ($Node -is [Management.Automation.Language.CommandExpressionAst] -and @($Node.Redirections).Count -eq 0) {
    $child = $Node.Expression
  }
  if ($null -ne $child) { return Resolve-HWOSPowerShellString $child $Bindings ($Depth + 1) $Seen }
  return $unknown
}

function Get-HWOSPowerShellWord {
  param($Node, [hashtable]$Bindings)
  $literal = $Node -is [Management.Automation.Language.StringConstantExpressionAst] -or $Node -is [Management.Automation.Language.ConstantExpressionAst]
  $resolved = if ($literal) {
    [pscustomobject]@{ Values = @([string]$Node.Value); Complete = $true }
  } else {
    Resolve-HWOSPowerShellString $Node $Bindings
  }
  $value = if ($literal) { [string]$Node.Value } elseif ($resolved.Complete -and @($resolved.Values).Count -eq 1) { [string]$resolved.Values[0] } else { '' }
  return [pscustomobject]@{
    Value = $value
    Literal = $literal
    Candidates = @($resolved.Values)
    Parameter = $false
    Unresolved = -not $resolved.Complete
    BareUnboundVariable = ($Node -is [Management.Automation.Language.VariableExpressionAst] -and -not $Bindings.ContainsKey($Node.VariablePath.UserPath))
  }
}

function Get-HWOSPowerShellCommands {
  param([string]$Text)
  $tokens = $null
  $errors = $null
  $ast = [Management.Automation.Language.Parser]::ParseInput($Text, [ref]$tokens, [ref]$errors)
  $bindings = @{}
  foreach ($assignment in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.AssignmentStatementAst]
  }, $true))) {
    if ($assignment.Left -is [Management.Automation.Language.VariableExpressionAst]) {
      $key = $assignment.Left.VariablePath.UserPath
      $binding = if ($assignment.Operator -eq [Management.Automation.Language.TokenKind]::Equals) { $assignment.Right } else { $assignment }
      if ($bindings.ContainsKey($key)) {
        $bindings[$key] = @($bindings[$key]) + @($binding)
      } else {
        $bindings[$key] = @($binding)
      }
    }
  }
  $commands = @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.CommandAst]
  }, $true))
  $single = @($errors).Count -eq 0 -and $null -eq $ast.BeginBlock -and $null -eq $ast.ProcessBlock -and $null -eq $ast.DynamicParamBlock -and $null -eq $ast.ParamBlock -and $null -ne $ast.EndBlock
  if ($single) {
    $statements = @($ast.EndBlock.Statements)
    $single = $statements.Count -eq 1 -and $statements[0] -is [Management.Automation.Language.PipelineAst]
    if ($single) {
      $single = @($statements[0].PipelineElements).Count -eq 1 -and $commands.Count -eq 1 -and [object]::ReferenceEquals($statements[0].PipelineElements[0], $commands[0])
    }
  }
  foreach ($command in $commands) {
    $words = New-Object 'System.Collections.Generic.List[object]'
    foreach ($element in @($command.CommandElements | Select-Object -Skip 1)) {
      if ($element -is [Management.Automation.Language.CommandParameterAst]) {
        $words.Add([pscustomobject]@{
          Value = '-' + $element.ParameterName
          Literal = $true
          Candidates = @()
          Parameter = $true
          Unresolved = $false
          BareUnboundVariable = $false
        })
        if ($null -ne $element.Argument) {
          $words.Add((Get-HWOSPowerShellWord $element.Argument $bindings))
        }
      } else {
        $words.Add((Get-HWOSPowerShellWord $element $bindings))
      }
    }
    [pscustomobject]@{
      Name = [string]$command.GetCommandName()
      Words = $words.ToArray()
      Single = $single
      Dialect = 'PowerShell'
      Redirect = $false
      DynamicName = ($null -eq $command.GetCommandName())
    }
  }
  foreach ($redirect in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.FileRedirectionAst]
  }, $true))) {
    [pscustomobject]@{
      Name = '__write'
      Words = @((Get-HWOSPowerShellWord $redirect.Location $bindings))
      Single = $false
      Dialect = 'PowerShell'
      Redirect = $true
      DynamicName = $false
    }
  }
  foreach ($member in @($ast.FindAll({
    param($n)
    $n -is [Management.Automation.Language.InvokeMemberExpressionAst]
  }, $true))) {
    $name = [string]$member.Member.Value
    if ($name -match '^(?i)(WriteAllText|WriteAllBytes|WriteAllLines|AppendAllText|AppendAllLines|Delete|Move|Copy|Create|CreateDirectory|OpenWrite)$') {
      $words = @($member.Arguments | ForEach-Object {
        Get-HWOSPowerShellWord $_ $bindings
      })
      if ($words.Count -gt 0) {
        if ($name -eq 'Copy' -and $words.Count -gt 1) {
          [pscustomobject]@{
            Name = 'copy-item'
            Words = @($words[0], $words[1])
            Single = $false
            Dialect = 'PowerShell'
            Redirect = $false
            DynamicName = $false
          }
          continue
        }
        $mutationWords = if ($name -eq 'Move' -and $words.Count -gt 1) {
          @($words[0], $words[1])
        } else {
          @($words[0])
        }
        [pscustomobject]@{
          Name = if ($name -eq 'Delete') { 'remove-item' } else { '__write' }
          Words = $mutationWords
          Single = $false
          Dialect = 'PowerShell'
          Redirect = $false
          DynamicName = $false
        }
      }
    }
  }
}
