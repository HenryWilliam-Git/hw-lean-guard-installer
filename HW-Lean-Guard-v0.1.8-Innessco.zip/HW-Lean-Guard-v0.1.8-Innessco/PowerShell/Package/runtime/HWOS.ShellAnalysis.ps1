. (Join-Path $PSScriptRoot 'HWOS.PowerShellAnalysis.ps1')
. (Join-Path $PSScriptRoot 'HWOS.BashAnalysis.ps1')
. (Join-Path $PSScriptRoot 'HWOS.CmdAnalysis.ps1')

function Join-HWOSPathResolutions {
  param([object]$Left, [object]$Right)
  $values = New-Object 'System.Collections.Generic.List[string]'
  foreach ($prefix in @($Left.Values)) {
    foreach ($suffix in @($Right.Values)) {
      $value = [string]$prefix + [string]$suffix
      if ($value.Length -gt 32768) { return [pscustomobject]@{ Values=@(); Complete=$false } }
      if (-not $values.Contains($value)) { $values.Add($value) }
      if ($values.Count -gt 64) { return [pscustomobject]@{ Values=@(); Complete=$false } }
    }
  }
  return [pscustomobject]@{ Values=$values.ToArray(); Complete=([bool]$Left.Complete -and [bool]$Right.Complete) }
}

function Resolve-HWOSBoundText {
  param([string]$Value, [hashtable]$Bindings, [object[]]$Expansions)
  $resolved = [pscustomobject]@{ Values=@(''); Complete=$true }
  $cursor = 0
  foreach ($expansion in @($Expansions)) {
    $prefix = $Value.Substring($cursor, $expansion.Index - $cursor)
    $resolved = Join-HWOSPathResolutions $resolved ([pscustomobject]@{ Values=@($prefix); Complete=$true })
    $replacement = if ($Bindings.ContainsKey($expansion.Name)) {
      $Bindings[$expansion.Name]
    } else {
      [pscustomobject]@{ Values=@(); Complete=$false }
    }
    $resolved = Join-HWOSPathResolutions $resolved $replacement
    $cursor = $expansion.Index + $expansion.Length
  }
  return Join-HWOSPathResolutions $resolved ([pscustomobject]@{ Values=@($Value.Substring($cursor)); Complete=$true })
}

function Set-HWOSBoundText {
  param([hashtable]$Bindings, [string]$Name, [object]$Resolution)
  if ($Bindings.ContainsKey($Name)) {
    $values = @(@($Bindings[$Name].Values) + @($Resolution.Values) | Select-Object -Unique)
    if ($values.Count -gt 64) {
      $Bindings[$Name] = [pscustomobject]@{ Values=@(); Complete=$false }
      return
    }
    $Bindings[$Name] = [pscustomobject]@{ Values=$values; Complete=($Bindings[$Name].Complete -and $Resolution.Complete) }
  } else {
    $Bindings[$Name] = $Resolution
  }
}

function Assert-HWOSResolvedPathWords {
  param([object[]]$Words, [bool]$AllowBareUnboundDelete = $false)
  foreach ($word in @($Words)) {
    $unresolved = $word.PSObject.Properties['Unresolved']
    if ($null -eq $unresolved -or -not $unresolved.Value) { continue }
    $bare = $word.PSObject.Properties['BareUnboundVariable']
    if ($AllowBareUnboundDelete -and $null -ne $bare -and $bare.Value) { continue }
    throw 'Unsupported or unresolved operational path.'
  }
}

function Get-HWOSResolvedScriptWord {
  param([object]$Word)
  Assert-HWOSResolvedPathWords @($Word)
  if (@($Word.Candidates).Count -ne 1) { throw 'Executable script operand is not a single resolved value.' }
  return [string]$Word.Candidates[0]
}

function Add-HWOSOperandPaths {
  param($List, [object[]]$Words, [string[]]$DirectoryContexts = @())
  foreach ($word in @($Words)) {
    foreach ($candidate in @($word.Candidates)) {
      if (-not [string]::IsNullOrWhiteSpace($candidate)) {
        $List.Add([string]$candidate)
        if (-not [IO.Path]::IsPathRooted($candidate)) {
          foreach ($directory in $DirectoryContexts) {
            try { $List.Add([IO.Path]::GetFullPath((Join-Path $directory $candidate))) }
            catch { $List.Add($directory) }
          }
        }
      }
    }
  }
}

function Get-HWOSShellAnalysis {
  param([string]$Text, [string]$Dialect, [int]$Depth = 0, [string[]]$DirectoryContexts = @())
  if ($Depth -gt 8) {
    throw 'Shell wrapper nesting exceeds the supported analysis depth.'
  }
  $result = [pscustomobject]@{
    Writes = (New-Object 'System.Collections.Generic.List[string]')
    Reads = (New-Object 'System.Collections.Generic.List[string]')
    Copies = (New-Object 'System.Collections.Generic.List[object]')
    Delete = $false
    Single = $true
  }
  $commands = if ($Dialect -eq 'PowerShell') {
    @(Get-HWOSPowerShellCommands $Text)
  } elseif ($Dialect -eq 'Cmd') {
    @(Get-HWOSCmdCommands $Text)
  } else {
    @(Get-HWOSBashCommands $Text)
  }
  $workingDirectories = New-Object 'System.Collections.Generic.List[string]'
  foreach ($directory in $DirectoryContexts) { $workingDirectories.Add($directory) }
  foreach ($command in $commands) {
    if (-not $command.Single) {
      $result.Single = $false
    }
    $name = ($command.Name -replace '^.*[\\/]', '').ToLowerInvariant() -replace '\.exe$', ''
    $words = @($command.Words)
    if ($command.Dialect -eq 'Cmd' -and $command.DynamicName) {
      throw 'Dynamic CMD command identity cannot be safely analyzed.'
    }
    while ($command.Dialect -eq 'Bash' -and $name -in @('if', 'then', 'else', 'elif', 'do', 'while', 'until', 'time', '!') -and $words.Count -gt 0) {
      $command.Single = $false
      $result.Single = $false
      $name = ($words[0].Value -replace '^.*[\\/]', '').ToLowerInvariant() -replace '\.exe$', ''
      $words = @($words | Select-Object -Skip 1)
    }
    while ($name -in @('command', 'env', 'builtin') -and $words.Count -gt 0) {
      if ($name -eq 'env' -and $words[0].Value -match '^[A-Za-z_][A-Za-z0-9_]*=') {
        $command.Single = $false
        $words = @($words | Select-Object -Skip 1)
        continue
      }
      if ($words[0].Value.StartsWith('-')) {
        $command.Single = $false
        $words = @($words | Select-Object -Skip 1)
        continue
      }
      $name = ($words[0].Value -replace '^.*[\\/]', '').ToLowerInvariant() -replace '\.exe$', ''
      $words = @($words | Select-Object -Skip 1)
    }
    if ($name -in @('cd', 'chdir', 'set-location', 'sl', 'pushd', 'push-location')) {
      $directoryPaths = New-Object 'System.Collections.Generic.List[string]'
      $directoryWords = @($words | Where-Object { -not $_.Parameter -and -not $_.Value.StartsWith('-') })
      Assert-HWOSResolvedPathWords $directoryWords
      Add-HWOSOperandPaths $directoryPaths $directoryWords $workingDirectories.ToArray()
      foreach ($directoryPath in $directoryPaths) {
        $resolvedDirectory = ConvertTo-HWOSCandidatePath $directoryPath
        if ($resolvedDirectory) { $workingDirectories.Add($resolvedDirectory) }
      }
      continue
    }
    if ($name -in @('invoke-expression', 'iex', 'eval')) {
      if ($words.Count -eq 0) { throw 'Executable script operand is unavailable.' }
      Assert-HWOSResolvedPathWords $words
      $scripts = if ($command.Dialect -eq 'PowerShell') {
        @($words | ForEach-Object {
          $_.Candidates
        })
      } else {
        @(($words.Value -join ' '))
      }
      foreach ($scriptText in $scripts) {
        $nested = Get-HWOSShellAnalysis -Text $scriptText -Dialect $command.Dialect -Depth ($Depth + 1) -DirectoryContexts $workingDirectories.ToArray()
        foreach ($path in $nested.Writes) {
          $result.Writes.Add($path)
        }
        foreach ($path in $nested.Reads) {
          $result.Reads.Add($path)
        }
        foreach ($copy in $nested.Copies) {
          $copy.Safe = $false
          $result.Copies.Add($copy)
        }
        $result.Delete = $result.Delete -or $nested.Delete
      }
      $result.Single = $false
      continue
    }
    if ($name -in @('powershell', 'pwsh', 'bash', 'sh', 'cmd')) {
      $switch = if ($name -in @('powershell', 'pwsh')) {
        '^-(command|c|encodedcommand|enc)$'
      } elseif ($name -eq 'cmd') {
        '^/[ck]$'
      } else {
        '^-[A-Za-z]*c[A-Za-z]*$'
      }
      $index = -1
      $valid = $true
      for ($i = 0; $i -lt $words.Count; $i++) {
        if ($words[$i].Value -match $switch) {
          $index = $i
          break
        }
        if ($words[$i].Value -notmatch '^(?i)(-NoProfile|-NonInteractive|-NoLogo)$') {
          $valid = $false
        }
      }
      if ($index -ge 0 -and $index + 1 -lt $words.Count) {
        $nestedDialect = if ($name -in @('powershell', 'pwsh')) {
          'PowerShell'
        } elseif ($name -eq 'cmd') {
          'Cmd'
        } else {
          'Bash'
        }
        $nestedText = Get-HWOSResolvedScriptWord $words[$index + 1]
        $valid = $valid -and $words[$index + 1].Literal -and $index + 2 -eq $words.Count
        if ($nestedDialect -eq 'Cmd') {
          $valid = $false
          if ($index + 2 -lt $words.Count) {
            $nestedText = (@($words | Select-Object -Skip ($index + 1) | ForEach-Object {
              $resolvedValue = Get-HWOSResolvedScriptWord $_
              if ($resolvedValue -match '\s' -and -not $resolvedValue.Contains('"')) { '"' + $resolvedValue + '"' } else { $resolvedValue }
            })) -join ' '
          }
        }
        if ($nestedDialect -eq 'Bash' -and $words[$index].Value -cne '-c') { $valid = $false }
        if ($words[$index].Value -match '^-(EncodedCommand|enc)$') {
          $valid = $false
          try {
            $nestedText = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($nestedText))
          } catch {
            throw 'Unrecognized encoded shell wrapper.'
          }
        }
        $nested = Get-HWOSShellAnalysis -Text $nestedText -Dialect $nestedDialect -Depth ($Depth + 1) -DirectoryContexts $workingDirectories.ToArray()
        foreach ($path in $nested.Writes) {
          $result.Writes.Add($path)
        }
        foreach ($path in $nested.Reads) {
          $result.Reads.Add($path)
        }
        foreach ($copy in $nested.Copies) {
          $copy.Safe = $copy.Safe -and $valid -and $command.Single
          $result.Copies.Add($copy)
        }
        $result.Delete = $result.Delete -or $nested.Delete
        $result.Single = $result.Single -and $nested.Single
      }
      continue
    }
    $ps = $command.Dialect -eq 'PowerShell'
    $copy = $name -in @('copy-item', 'cp', 'cpi', 'copy', 'xcopy', 'robocopy')
    $move = $name -in @('move-item', 'mv', 'mi', 'move', 'rename-item', 'rni', 'ren')
    $delete = $name -in @('remove-item', 'ri', 'rm', 'del', 'erase', 'rmdir', 'rd', 'unlink')
    $read = $name -in @('get-content', 'gc', 'cat', 'head', 'tail', 'type', '__read')
    $write = $name -in @('set-content', 'sc', 'add-content', 'ac', 'out-file', 'new-item', 'ni', 'mkdir', 'md', 'touch', 'tee', 'tee-object', '__write')
    if (-not ($copy -or $move -or $delete -or $read -or $write)) {
      continue
    }
    if ($delete) {
      $result.Delete = $true
    }
    $sources = New-Object 'System.Collections.Generic.List[object]'
    $destinations = New-Object 'System.Collections.Generic.List[object]'
    $positional = New-Object 'System.Collections.Generic.List[object]'
    $safe = $true
    $endOptions = $false
    for ($i = 0; $i -lt $words.Count; $i++) {
      $word = $words[$i]
      $value = $word.Value
      if ($command.Dialect -eq 'Cmd' -and $word.Parameter) {
        $safe = $false
        continue
      }
      if ($ps -and $word.Parameter) {
        if ($value -match '^(?i)-(LiteralPath|Path|Destination|FilePath|Target|OutputFile)$') {
          if ($i + 1 -ge $words.Count -or $words[$i + 1].Parameter) {
            $safe = $false
            continue
          }
          $i++
          if ($value -match '^(?i)-(Destination|Target)$') {
            $destinations.Add($words[$i])
          } else {
            $sources.Add($words[$i])
          }
        } elseif ($value -match '^(?i)-(Force|Recurse)$') {
        } elseif ($value -match '^(?i)-(Value|InputObject|Encoding|Filter|Include|Exclude|Stream|ItemType|ErrorAction|Confirm)$') {
          $safe = $false
          if ($i + 1 -lt $words.Count -and -not $words[$i + 1].Parameter) {
            $i++
          }
        } else {
          $safe = $false
        }
        continue
      }
      if (-not $ps -and -not $endOptions -and $value -eq '--') {
        $endOptions = $true
        continue
      }
      if (-not $ps -and -not $endOptions -and $value.StartsWith('-')) {
        if ($copy -and $value -notmatch '^-[rRfpv]+$') {
          $safe = $false
        }
        continue
      }
      $positional.Add($word)
    }
    if ($copy -or $move) {
      if ($sources.Count -eq 0 -and $positional.Count -gt 0) {
        $sources.Add($positional[0])
        $positional.RemoveAt(0)
      }
      if ($destinations.Count -eq 0 -and $positional.Count -gt 0) {
        $destinations.Add($positional[$positional.Count - 1])
        $positional.RemoveAt($positional.Count - 1)
      }
      if ($positional.Count -gt 0) {
        foreach ($word in $positional) {
          $sources.Add($word)
        }
        $safe = $false
      }
      if ($sources.Count -ne 1 -or $destinations.Count -ne 1) {
        $safe = $false
      }
      foreach ($word in $sources.ToArray() + $destinations.ToArray()) {
        if (-not $word.Literal -or [Management.Automation.WildcardPattern]::ContainsWildcardCharacters($word.Value)) {
          $safe = $false
        }
      }
      if ($name -in @('robocopy', 'xcopy', 'copy')) {
        $safe = $false
      }
      Assert-HWOSResolvedPathWords ($sources.ToArray() + $destinations.ToArray())
      Add-HWOSOperandPaths $result.Writes $destinations.ToArray() $workingDirectories.ToArray()
      if ($move -or ($name -eq 'robocopy' -and @($words | Where-Object {
        $_.Value -match '^(?i)/(MOVE|MOV|MIR|PURGE)$'
      }).Count -gt 0)) {
        Add-HWOSOperandPaths $result.Writes $sources.ToArray() $workingDirectories.ToArray()
      } else {
        $sourcePaths = New-Object 'System.Collections.Generic.List[string]'
        Add-HWOSOperandPaths $sourcePaths $sources.ToArray() $workingDirectories.ToArray()
        $destinationPaths = New-Object 'System.Collections.Generic.List[string]'
        Add-HWOSOperandPaths $destinationPaths $destinations.ToArray() $workingDirectories.ToArray()
        $result.Copies.Add([pscustomobject]@{
          Sources = @($sourcePaths)
          Destinations = @($destinationPaths)
          Safe = ($safe -and $command.Single)
        })
      }
    } else {
      if ($sources.Count -eq 0) {
        if ($ps -and $write -and $name -notin @('__write', 'tee-object') -and $positional.Count -gt 0) {
          $sources.Add($positional[0])
        } else {
          foreach ($word in $positional) {
            $sources.Add($word)
          }
        }
      }
      if ($read) {
        Add-HWOSOperandPaths $result.Reads $sources.ToArray() $workingDirectories.ToArray()
      } else {
        Assert-HWOSResolvedPathWords $sources.ToArray() ($delete -and $ps)
        Add-HWOSOperandPaths $result.Writes $sources.ToArray() $workingDirectories.ToArray()
      }
    }
  }
  foreach ($copy in $result.Copies) {
    $copy.Safe = $copy.Safe -and $result.Single
  }
  return $result
}
