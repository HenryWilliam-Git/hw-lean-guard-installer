function Get-HWOSBashCommands {
  param([string]$Text, [int]$Depth = 0, [bool]$ExpansionOnly = $false)
  if ($Depth -gt 12) {
    throw 'Shell nesting exceeds the supported analysis depth.'
  }
  $segments = New-Object 'System.Collections.Generic.List[object]'
  $words = New-Object 'System.Collections.Generic.List[object]'
  $nested = New-Object 'System.Collections.Generic.List[string]'
  $heredocs = New-Object 'System.Collections.Generic.List[object]'
  $buffer = New-Object Text.StringBuilder
  $quote = [char]0
  $quoted = $false
  $active = $false
  $dynamic = $false
  $pending = ''
  $bindings = [Collections.Hashtable]::new([StringComparer]::Ordinal)
  $expansions = New-Object 'System.Collections.Generic.List[object]'
  $unresolvedExpansion = $false
  for ($i = 0; $i -le $Text.Length; $i++) {
    $c = if ($i -lt $Text.Length) {
      $Text[$i]
    } else {
      [char]0
    }
    if ($ExpansionOnly -and $c -eq '\' -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -in @([char]92, [char]36, [char]96, [char]10)) {
      $i++
      continue
    }
    if ($quote -ne [char]39 -and ($c -eq '$' -or (-not $ExpansionOnly -and $quote -eq [char]0 -and $c -in @('<', '>'))) -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '(') {
      $start = $i + 2
      $level = 1
      $innerQuote = [char]0
      $j = $start
      for (; $j -lt $Text.Length; $j++) {
        $n = $Text[$j]
        if ($n -eq '\' -and $innerQuote -ne [char]39) {
          $j++
          continue
        }
        if ($innerQuote -ne [char]0) {
          if ($n -eq $innerQuote) {
            $innerQuote = [char]0
          }
          continue
        }
        if ($n -eq [char]39 -or $n -eq [char]34) {
          $innerQuote = $n
          continue
        }
        if ($n -eq '(') {
          $level++
        }
        if ($n -eq ')') {
          $level--
          if ($level -eq 0) {
            break
          }
        }
      }
      if ($level -ne 0) {
        throw 'Unterminated executable shell substitution.'
      }
      $nested.Add($Text.Substring($start, $j - $start))
      $i = $j
      $dynamic = $true
      $unresolvedExpansion = $true
      $active = $true
      continue
    }
    if ($quote -ne [char]39 -and $c -eq [char]96) {
      $j = $i + 1
      while ($j -lt $Text.Length -and $Text[$j] -ne [char]96) {
        if ($Text[$j] -eq '\') {
          $j++
        }
        $j++
      }
      if ($j -ge $Text.Length) {
        throw 'Unterminated executable shell substitution.'
      }
      $nested.Add($Text.Substring($i + 1, $j - $i - 1))
      $i = $j
      $dynamic = $true
      $unresolvedExpansion = $true
      $active = $true
      continue
    }
    if ($ExpansionOnly) { continue }
    if ($quote -ne [char]39 -and $c -eq '$') {
      $variable = [regex]::Match($Text.Substring($i), '^\$(?:\{(?<name>[A-Za-z_][A-Za-z0-9_]*)\}|(?<name>[A-Za-z_][A-Za-z0-9_]*))')
      $dynamic = $true
      if ($variable.Success) {
        $expansions.Add([pscustomobject]@{ Index=$buffer.Length; Length=$variable.Length; Name=$variable.Groups['name'].Value })
        [void]$buffer.Append($variable.Value)
        $i += $variable.Length - 1
        $active = $true
        continue
      }
      $unresolvedExpansion = $true
    }
    if ($quote -ne [char]0) {
      if ($c -eq $quote) {
        $quote = [char]0
        continue
      }
      if ($c -eq [char]0) {
        throw 'Unterminated shell quote.'
      }
      if ($quote -eq [char]34 -and $c -eq '\' -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -in @([char]34, [char]36, [char]96, [char]92)) {
        $i++
        [void]$buffer.Append($Text[$i])
        continue
      }
      if ($quote -eq [char]34 -and $c -eq '$') {
        $dynamic = $true
      }
      [void]$buffer.Append($c)
      continue
    }
    if ($c -eq [char]39 -or $c -eq [char]34) {
      $quote = $c
      $quoted = $true
      $active = $true
      continue
    }
    if ($c -eq '\' -and $i + 1 -lt $Text.Length) {
      $i++
      if ($Text[$i] -ne "`n") {
        [void]$buffer.Append($Text[$i])
        $active = $true
      }
      continue
    }
    if ($c -eq '$') {
      $dynamic = $true
    }
    $separator = $c -eq [char]0 -or [char]::IsWhiteSpace($c) -or $c -in @(';', '|', '&', '>', '<', '(', ')', '{', '}')
    if (-not $separator) {
      if ($c -eq '#' -and -not $active) {
        while ($i -lt $Text.Length -and $Text[$i] -ne "`n") {
          $i++
        }
        $i--
        continue
      }
      [void]$buffer.Append($c)
      $active = $true
      continue
    }
    if ($active) {
      $value = $buffer.ToString()
      $resolution = Resolve-HWOSBoundText $value $bindings $expansions.ToArray()
      if ($unresolvedExpansion) { $resolution = [pscustomobject]@{ Values=@(); Complete=$false } }
      $word = [pscustomobject]@{
        Value = $value
        Literal = (-not $dynamic)
        Candidates = @($resolution.Values)
        Parameter = $false
        Unresolved = (-not $resolution.Complete)
        BareUnboundVariable = $false
      }
      if ($pending -like '<<*' -and $pending -ne '<<<') {
        $heredocs.Add([pscustomobject]@{
          Delimiter = $value
          Expand = (-not $quoted)
          StripTabs = ($pending -eq '<<-')
        })
        $pending = ''
      } elseif ($pending) {
        if ($pending -match '>') {
          $segments.Add([pscustomobject]@{
            Name = '__write'
            Words = @($word)
            Single = $false
            Dialect = 'Bash'
            Redirect = $true
            DynamicName = $false
          })
        } elseif ($pending -eq '<') {
          $segments.Add([pscustomobject]@{
            Name = '__read'
            Words = @($word)
            Single = $false
            Dialect = 'Bash'
            Redirect = $true
            DynamicName = $false
          })
        }
        $pending = ''
      } else {
        $words.Add($word)
      }
      [void]$buffer.Clear()
      $active = $false
      $dynamic = $false
      $quoted = $false
      $expansions.Clear()
      $unresolvedExpansion = $false
    }
    if ($c -in @('>', '<')) {
      $pending = [string]$c
      while ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq $c) {
        $pending += $Text[++$i]
      }
      if ($pending -eq '<<' -and $i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '-') {
        $pending += '-'
        $i++
      }
      if ($i + 1 -lt $Text.Length -and $Text[$i + 1] -eq '&') {
        $pending += '&'
        $i++
      }
      continue
    }
    if ($c -eq [char]0 -or $c -in @("`n", ';', '|', '&', '(', ')', '{', '}')) {
      while ($words.Count -gt 0 -and $words[0].Value -match '^(?<name>[A-Za-z_][A-Za-z0-9_]*)=(?<value>.*)$') {
        $key = $Matches['name']
        $assignmentWord = $words[0]
        $values = @($assignmentWord.Candidates | ForEach-Object { $_.Substring($key.Length + 1) })
        Set-HWOSBoundText $bindings $key ([pscustomobject]@{ Values=$values; Complete=(-not $assignmentWord.Unresolved) })
        $words.RemoveAt(0)
        $segments.Add([pscustomobject]@{
          Name = '__assignment'
          Words = @()
          Single = $false
          Dialect = 'Bash'
          Redirect = $false
          DynamicName = $false
        })
      }
      if ($words.Count -gt 0) {
        $segments.Add([pscustomobject]@{
          Name = $words[0].Value
          Words = @($words | Select-Object -Skip 1)
          Single = $false
          Dialect = 'Bash'
          Redirect = $false
          DynamicName = (-not $words[0].Literal)
        })
        $words.Clear()
      }
      if ($c -eq "`n" -and $heredocs.Count -gt 0) {
        foreach ($doc in $heredocs) {
          $body = New-Object Text.StringBuilder
          $found = $false
          while ($i + 1 -lt $Text.Length) {
            $start = $i + 1
            $end = $Text.IndexOf("`n", $start)
            if ($end -lt 0) {
              $end = $Text.Length
            }
            $line = $Text.Substring($start, $end - $start).TrimEnd("`r")
            $i = $end
            $delimiterLine = if ($doc.StripTabs) {
              $line.TrimStart("`t")
            } else {
              $line
            }
            if ($delimiterLine -ceq $doc.Delimiter) {
              $found = $true
              break
            }
            [void]$body.AppendLine($line)
          }
          if (-not $found) {
            throw 'Unterminated shell heredoc.'
          }
          if ($doc.Expand) {
            # Heredoc quotes are data; only substitutions contribute executable commands.
            foreach ($expansion in @(Get-HWOSBashCommands -Text $body.ToString() -Depth ($Depth + 1) -ExpansionOnly $true)) {
              $segments.Add($expansion)
            }
          }
        }
        $heredocs.Clear()
      }
    }
  }
  if ($pending -or $heredocs.Count -gt 0) {
    throw 'Incomplete shell redirection.'
  }
  $single = $segments.Count -eq 1 -and $nested.Count -eq 0
  foreach ($segment in $segments) {
    $segment.Single = $single
    $segment
  }
  foreach ($scriptText in $nested) {
    Get-HWOSBashCommands -Text $scriptText -Depth ($Depth + 1) | ForEach-Object {
      $_.Single = $false
      $_
    }
  }
}
