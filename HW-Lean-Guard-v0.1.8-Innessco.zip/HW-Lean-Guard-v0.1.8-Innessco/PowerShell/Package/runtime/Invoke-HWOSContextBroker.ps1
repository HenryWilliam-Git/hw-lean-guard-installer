<#
Combines the existing litigation advisory context with bounded Personal Context output.
Prompt content is carried only over child-process stdin and is never logged.
#>
[CmdletBinding()]
param(
  [string]$LitigationProviderPath = '',
  [string]$PersonalContextPath = 'C:\Program Files\HenryWilliam\PersonalContext\HWPersonalContext.exe',
  [string]$PowerShellPath = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe',
  [string]$PersonalContextHostPath = '',
  [string]$PersonalContextHostArgumentsPrefix = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File',
  [ValidateRange(1, 900)][int]$PersonalContextTimeoutMilliseconds = 900
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($LitigationProviderPath)) {
  $LitigationProviderPath = Join-Path $PSScriptRoot 'Invoke-HWOSLitigationPromptGuard.ps1'
}

function Stop-HWOSBrokerProcessTree {
  param([Parameter(Mandatory = $true)][System.Diagnostics.Process]$Process)

  if (-not $Process.HasExited) {
    $previousErrorAction = $ErrorActionPreference
    try {
      $ErrorActionPreference = 'SilentlyContinue'
      & "$env:SystemRoot\System32\taskkill.exe" /PID $Process.Id /T /F 2>$null | Out-Null
    } finally {
      $ErrorActionPreference = $previousErrorAction
    }
  }
}

function Invoke-HWOSChildProcess {
  param(
    [Parameter(Mandatory = $true)][string]$FilePath,
    [Parameter(Mandatory = $true)][string]$Arguments,
    [Parameter(Mandatory = $true)][string]$StandardInput,
    [Parameter(Mandatory = $true)][int]$TimeoutMilliseconds,
    [bool]$CreateNoWindow = $true
  )

  $startInfo = New-Object System.Diagnostics.ProcessStartInfo
  $startInfo.FileName = $FilePath
  $startInfo.Arguments = $Arguments
  $startInfo.UseShellExecute = $false
  $startInfo.CreateNoWindow = $CreateNoWindow
  $startInfo.RedirectStandardInput = $true
  $startInfo.RedirectStandardOutput = $true
  $startInfo.RedirectStandardError = $true
  if ($null -ne $startInfo.PSObject.Properties['StandardOutputEncoding']) { $startInfo.StandardOutputEncoding = [Text.UTF8Encoding]::new($false) }
  if ($null -ne $startInfo.PSObject.Properties['StandardErrorEncoding']) { $startInfo.StandardErrorEncoding = [Text.UTF8Encoding]::new($false) }

  $process = New-Object System.Diagnostics.Process
  $process.StartInfo = $startInfo
  $clock = [Diagnostics.Stopwatch]::StartNew()
  $inputStream = $null
  $writeResult = $null
  try {
    if (-not $process.Start()) { throw 'child-spawn-failed' }
    $outputTask = $process.StandardOutput.ReadToEndAsync()
    $errorTask = $process.StandardError.ReadToEndAsync()
    $inputStream = $process.StandardInput.BaseStream
    $inputBytes = [Text.UTF8Encoding]::new($false).GetBytes($StandardInput)
    $writeResult = $inputStream.BeginWrite($inputBytes, 0, $inputBytes.Length, $null, $null)
    $remaining = [Math]::Max(0, $TimeoutMilliseconds - [int]$clock.ElapsedMilliseconds)
    if (-not $writeResult.AsyncWaitHandle.WaitOne($remaining)) {
      Stop-HWOSBrokerProcessTree -Process $process
      [void]$process.WaitForExit(1000)
      return [pscustomobject]@{ TimedOut = $true; ExitCode = $null; StandardOutput = ''; StandardError = '' }
    }
    $inputStream.EndWrite($writeResult)
    $writeResult.AsyncWaitHandle.Close()
    $writeResult = $null
    $inputStream.Dispose()
    $inputStream = $null
    $remaining = [Math]::Max(0, $TimeoutMilliseconds - [int]$clock.ElapsedMilliseconds)
    if (-not $process.WaitForExit($remaining)) {
      Stop-HWOSBrokerProcessTree -Process $process
      [void]$process.WaitForExit(1000)
      return [pscustomobject]@{ TimedOut = $true; ExitCode = $null; StandardOutput = ''; StandardError = '' }
    }
    return [pscustomobject]@{
      TimedOut = $false
      ExitCode = $process.ExitCode
      StandardOutput = $outputTask.GetAwaiter().GetResult()
      StandardError = $errorTask.GetAwaiter().GetResult()
    }
  } finally {
    if ($null -ne $writeResult) { $writeResult.AsyncWaitHandle.Close() }
    if ($null -ne $inputStream) { $inputStream.Dispose() }
    $clock.Stop()
    $process.Dispose()
  }
}

function Get-HWOSPrompt {
  param([Parameter(Mandatory = $true)]$Payload)

  foreach ($name in @('prompt', 'user_prompt', 'message', 'text')) {
    $property = $Payload.PSObject.Properties[$name]
    if ($null -ne $property -and $null -ne $property.Value) { return [string]$property.Value }
  }
  return ''
}

function Get-HWOSLitigationContext {
  param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Output)

  if ([string]::IsNullOrWhiteSpace($Output)) { return '' }
  try { $response = $Output | ConvertFrom-Json -ErrorAction Stop } catch { throw 'litigation-provider-malformed-output' }
  $responseNames = @($response.PSObject.Properties.Name)
  if ($null -eq $response -or $responseNames.Count -ne 1 -or $responseNames[0] -cne 'hookSpecificOutput') {
    throw 'litigation-provider-malformed-output'
  }
  $hookOutput = $response.hookSpecificOutput
  $hookOutputNames = @($hookOutput.PSObject.Properties.Name | Sort-Object)
  if ($null -eq $hookOutput -or $hookOutputNames.Count -ne 2 -or (($hookOutputNames -join "`0") -cne ('additionalContext', 'hookEventName' -join "`0"))) {
    throw 'litigation-provider-malformed-output'
  }
  if ($hookOutput.hookEventName -cne 'UserPromptSubmit' -or $hookOutput.additionalContext -isnot [string]) {
    throw 'litigation-provider-malformed-output'
  }
  return [string]$hookOutput.additionalContext
}

function Get-HWOSPersonalContext {
  param([Parameter(Mandatory = $true)][AllowEmptyString()][string]$Output)

  if ([string]::IsNullOrWhiteSpace($Output)) { return $null }
  try { $response = $Output | ConvertFrom-Json -ErrorAction Stop } catch { return $null }
  if ($null -eq $response -or
      $response.schemaVersion -cne 'hw-personal-context-cli/v1' -or
      $response.command -cne 'retrieve' -or
      $response.ok -ne $true -or
      $null -eq $response.data -or
      $response.data.context -isnot [string]) { return $null }
  $context = [string]$response.data.context
  if ([string]::IsNullOrWhiteSpace($context)) { return $null }
  return $context
}

function New-HWOSContextBrokerOutput {
  param(
    [Parameter(Mandatory = $true)][AllowEmptyString()][string]$LitigationContext,
    [AllowNull()][AllowEmptyString()][string]$PersonalContext
  )

  $sections = [System.Collections.Generic.List[string]]::new()
  if (-not [string]::IsNullOrWhiteSpace($LitigationContext)) { $sections.Add("[Litigation advisory context]`n$LitigationContext") }
  if (-not [string]::IsNullOrWhiteSpace($PersonalContext)) { $sections.Add("[Personal Context advisory context]`n$PersonalContext") }
  if ($sections.Count -eq 0) { return '' }
  return ([ordered]@{
    hookSpecificOutput = [ordered]@{
      hookEventName = 'UserPromptSubmit'
      additionalContext = ($sections -join "`n`n")
    }
  } | ConvertTo-Json -Depth 4 -Compress)
}

function Invoke-HWOSContextBrokerMain {
  $standardInput = [Console]::OpenStandardInput()
  $inputReader = [IO.StreamReader]::new($standardInput, [Text.UTF8Encoding]::new($false), $true, 1024, $true)
  try { $hookInput = $inputReader.ReadToEnd() } finally { $inputReader.Dispose() }
  try { $payload = $hookInput | ConvertFrom-Json -ErrorAction Stop } catch { throw 'context-broker-malformed-hook-input' }
  if ($null -eq $payload) { throw 'context-broker-malformed-hook-input' }

  $escapedProviderPath = $LitigationProviderPath.Replace('"', '\"')
  $litigation = Invoke-HWOSChildProcess -FilePath $PowerShellPath -Arguments "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$escapedProviderPath`"" -StandardInput $hookInput -TimeoutMilliseconds 10000 -CreateNoWindow $false
  if ($litigation.TimedOut -or $litigation.ExitCode -ne 0) { throw 'litigation-provider-failed' }
  $litigationContext = Get-HWOSLitigationContext -Output $litigation.StandardOutput

  $personalContext = $null
  try {
    if ([string]::IsNullOrWhiteSpace($PersonalContextHostPath)) {
      $personalFilePath = $PersonalContextPath
      $personalArguments = 'retrieve --prompt-stdin'
    } else {
      $escapedPersonalPath = $PersonalContextPath.Replace('"', '\"')
      $personalFilePath = $PersonalContextHostPath
      $personalArguments = "$PersonalContextHostArgumentsPrefix `"$escapedPersonalPath`" retrieve --prompt-stdin"
    }
    $personal = Invoke-HWOSChildProcess -FilePath $personalFilePath -Arguments $personalArguments -StandardInput (Get-HWOSPrompt -Payload $payload) -TimeoutMilliseconds $PersonalContextTimeoutMilliseconds
    if (-not $personal.TimedOut -and $personal.ExitCode -eq 0) {
      $personalContext = Get-HWOSPersonalContext -Output $personal.StandardOutput
    }
  } catch {
    # Personal Context is advisory. Its content-free failure is intentionally omitted.
    $personalContext = $null
  }

  $output = New-HWOSContextBrokerOutput -LitigationContext $litigationContext -PersonalContext $personalContext
  if (-not [string]::IsNullOrWhiteSpace($output)) { Write-Output $output }
}

if ($MyInvocation.InvocationName -cne '.') { Invoke-HWOSContextBrokerMain }
