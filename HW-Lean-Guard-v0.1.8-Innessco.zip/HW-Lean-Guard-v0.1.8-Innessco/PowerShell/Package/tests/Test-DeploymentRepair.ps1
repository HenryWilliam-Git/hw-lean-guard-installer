param(
  [Parameter(Mandatory = $true)][string]$PackageRoot,
  [Parameter(Mandatory = $true)][string]$LeanRoot,
  [Parameter(Mandatory = $true)][string]$PersonalRoot,
  [Parameter(Mandatory = $true)][string]$StateRoot,
  [Parameter(Mandatory = $true)][string]$RegistryPath,
  [Parameter(Mandatory = $true)][string]$UserStore,
  [Parameter(Mandatory = $true)][scriptblock]$Install
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$receiptPath = Join-Path $StateRoot 'state\install-state.json'
$receipt = Read-HWOSLeanGuardJson -Path $receiptPath
$receiptBytes = [IO.File]::ReadAllBytes($receiptPath)
$receiptHash = Get-HWOSLeanGuardSha256 -Path $receiptPath
$originalRollbackHash = Get-HWOSLeanGuardSha256 -Path $receipt.rollbackReceiptPath
$userHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $UserStore)
$priorRegistry = Get-HWOSLeanGuardRegistryState -Path $RegistryPath
$originalStateHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $StateRoot)

function Assert-RepairFailure {
  param([scriptblock]$Action, [string]$Pattern)
  $failure = $null
  try { & $Action | Out-Null } catch { $failure = $_.Exception.Message }
  if ($null -eq $failure -or $failure -notlike $Pattern) { throw "Expected '$Pattern', received '$failure'." }
}
function Assert-DetectorFailure {
  $checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $RegistryPath
  if (@($checks.GetEnumerator() | Where-Object Value -NE $true).Count -eq 0) { throw 'New package detector accepted invalid installed state.' }
}

foreach ($relative in @('runtime\Invoke-HWOSLeanGuard.ps1', 'policy\guard-policy.json', 'deployment\Detect-HWOSLeanGuard.ps1')) {
  $path = Join-Path $LeanRoot $relative
  $bytes = [IO.File]::ReadAllBytes($path)
  try {
    [IO.File]::WriteAllText($path, 'synthetic-old-component')
    Assert-DetectorFailure
  } finally { [IO.File]::WriteAllBytes($path, $bytes) }
}
foreach ($mutation in @('missing', 'invalid-json', 'wrong-version', 'unsafe-root', 'invalid-hash', 'missing-provenance', 'invalid-provenance')) {
  try {
    $bad = Read-HWOSLeanGuardJson -Path $receiptPath
    switch ($mutation) {
      'missing' { Remove-Item -LiteralPath $receiptPath -Force }
      'invalid-json' { [IO.File]::WriteAllText($receiptPath, '{') }
      'wrong-version' { $bad.packageVersion = '0.0.0'; Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad }
      'unsafe-root' { $bad.installRoots.personalContext = $StateRoot; Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad }
      'invalid-hash' { $bad.files.leanGuard.'runtime\Invoke-HWOSLeanGuard.ps1' = 'invalid'; Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad }
      'missing-provenance' { $bad.PSObject.Properties.Remove('sourceManifestSha256'); Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad }
      'invalid-provenance' { $bad.sourceManifestSha256 = 'invalid'; Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad }
    }
    Assert-DetectorFailure
    if ($mutation -ceq 'missing') { Assert-RepairFailure $Install '*Existing machine install requires its install receipt*' }
    if ($mutation -ceq 'invalid-json') { Assert-RepairFailure $Install '*' }
    if ($mutation -ceq 'unsafe-root') { Assert-RepairFailure $Install '*Prior receipt install root differs*' }
  } finally { [IO.File]::WriteAllBytes($receiptPath, $receiptBytes) }
}
try {
  $bad = Read-HWOSLeanGuardJson -Path $receiptPath
  $bad.rollbackReceiptPath = Join-Path (Split-Path -Parent $StateRoot) 'outside-rollback.json'
  Write-HWOSLeanGuardJson -Path $receiptPath -Value $bad
  Assert-RepairFailure $Install '*outside the state rollback root*'
} finally { [IO.File]::WriteAllBytes($receiptPath, $receiptBytes) }
$rollbackBytes = [IO.File]::ReadAllBytes($receipt.rollbackReceiptPath)
try {
  Remove-Item -LiteralPath $receipt.rollbackReceiptPath -Force
  Assert-RepairFailure $Install '*Could not find file*'
} finally { [IO.File]::WriteAllBytes($receipt.rollbackReceiptPath, $rollbackBytes) }
if (-not (Test-HWOSLeanGuardRecordedFiles -Root $StateRoot -Files $originalStateHashes) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $LeanRoot -Files $receipt.files.leanGuard) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $PersonalRoot -Files $receipt.files.personalContext) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $UserStore -Files $userHashes)) { throw 'Rejected receipt or rollback targets changed machine, state, or user files.' }

foreach ($relative in @('runtime\Invoke-HWOSLeanGuard.ps1', 'policy\guard-policy.json', 'deployment\HWOSLeanGuard.State.ps1', 'deployment\Detect-HWOSLeanGuard.ps1')) {
  [IO.File]::WriteAllText((Join-Path $LeanRoot $relative), 'synthetic-old-component')
}
Remove-Item -LiteralPath (Join-Path $LeanRoot 'runtime\Invoke-HWOSContextBroker.ps1') -Force
[IO.File]::WriteAllText((Join-Path $LeanRoot 'obsolete-file.ps1'), 'synthetic-extra-component')
$mixedHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $LeanRoot)
$personalHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $PersonalRoot)
$drift = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $RegistryPath
if ($drift.installedFilesMatch -ne $false -or $drift.packageVersionMatch -ne $true) { throw 'Mixed runtime was not detected independently of the installed detector.' }
$global:HWOSDeploymentLifecycleInjectFailure = $true
try {
  Assert-RepairFailure $Install '*injected-install-finalization*'
} finally { $global:HWOSDeploymentLifecycleInjectFailure = $false }
if ((Get-HWOSLeanGuardSha256 -Path $receiptPath) -cne $receiptHash -or -not (Test-HWOSLeanGuardRecordedFiles -Root $LeanRoot -Files $mixedHashes) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $PersonalRoot -Files $personalHashes)) { throw 'Failed repair did not restore exact mixed-tree and receipt bytes.' }
$registry = Get-HWOSLeanGuardRegistryState -Path $RegistryPath
foreach ($field in @('keyExists', 'valueExists', 'valueKind', 'value')) {
  if ($registry.$field -cne $priorRegistry.$field) { throw 'Failed repair changed immediate registry state.' }
}
if (-not (Test-HWOSLeanGuardRecordedFiles -Root $UserStore -Files $userHashes)) { throw 'Failed repair changed a per-user store.' }
$repaired = & $Install
& (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $repaired
$newReceipt = Read-HWOSLeanGuardJson -Path $receiptPath
foreach ($mutation in @('missing-source', 'invalid-source', 'invalid-prior-hash', 'nonboolean-drift', 'unexpected-prior-field')) {
  $badEvidence = $repaired | ConvertTo-Json -Depth 20 | ConvertFrom-Json
  switch ($mutation) {
    'missing-source' { $badEvidence.PSObject.Properties.Remove('sourceManifestSha256') }
    'invalid-source' { $badEvidence.sourceManifestSha256 = 'invalid' }
    'invalid-prior-hash' { $badEvidence.priorInstallation.receiptSha256 = 'invalid' }
    'nonboolean-drift' { $badEvidence.priorInstallation.checks.installedFilesMatch = 'false' }
    'unexpected-prior-field' { $badEvidence.priorInstallation | Add-Member NoteProperty rawBody 'synthetic-forbidden-extra' }
  }
  Assert-RepairFailure { & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $badEvidence } '*'
}
foreach ($record in @($repaired, $newReceipt)) {
  if ($record.sourceManifestSha256 -cne (Get-HWOSLeanGuardSha256 -Path (Join-Path $PackageRoot 'manifest.json')) -or $record.priorInstallation.receiptSha256 -cne $receiptHash -or $record.priorInstallation.packageVersion -cne $receipt.packageVersion -or $record.priorInstallation.checkStatus -cne 'evaluated') { throw 'Repair did not record exact source and previous receipt provenance.' }
  foreach ($check in $drift.Keys) {
    if ($record.priorInstallation.checks.$check -ne $drift[$check]) { throw "Pre-repair drift check was not preserved: $check" }
  }
}
foreach ($file in $newReceipt.files.leanGuard.PSObject.Properties) {
  if ((Get-HWOSLeanGuardSha256 -Path (Join-Path $PackageRoot $file.Name)) -cne (Get-HWOSLeanGuardSha256 -Path (Join-Path $LeanRoot $file.Name))) { throw 'Repaired machine file differs from authoritative package.' }
}
if ((Test-Path -LiteralPath (Join-Path $LeanRoot 'obsolete-file.ps1')) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $PersonalRoot -Files $personalHashes)) { throw 'Whole-package repair did not restore both complete trees.' }
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $RegistryPath
if (@($checks.GetEnumerator() | Where-Object Value -NE $true).Count -gt 0) { throw 'Repaired install did not pass new-package detection.' }
if ((Get-HWOSLeanGuardSha256 -Path $receipt.rollbackReceiptPath) -cne $originalRollbackHash -or -not (Test-HWOSLeanGuardRecordedFiles -Root $UserStore -Files $userHashes)) { throw 'Repair changed the original rollback receipt or per-user stores.' }
$repairPrestate = Read-HWOSLeanGuardJson -Path $newReceipt.rollbackReceiptPath
if ($repairPrestate.registry.value -cne 'original-policy' -or $repairPrestate.registry.valueKind -cne 'ExpandString') { throw 'Repair lost original uninstall registry prestate.' }
if (@(Get-ChildItem -LiteralPath (Split-Path -Parent $LeanRoot) -Force | Where-Object Name -Like '.hwos-*').Count -ne 0) { throw 'Repair left staging or backup trees.' }
Write-Output 'PASS: mixed runtime/policy/deployment repair, independent new-package detection, exact rollback and user-store preservation, source and prior-receipt provenance'
