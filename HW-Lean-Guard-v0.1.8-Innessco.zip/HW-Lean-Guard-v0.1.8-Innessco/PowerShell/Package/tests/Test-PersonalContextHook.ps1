$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$packageRoot = Split-Path -Parent $PSScriptRoot
$runtimeRoot = Join-Path $packageRoot 'runtime'
$fixtureRoot = Join-Path $PSScriptRoot 'fixtures\personal-context-hooks'
$broker = Join-Path $runtimeRoot 'Invoke-HWOSContextBroker.ps1'
$sessionStart = Join-Path $runtimeRoot 'Invoke-HWOSPersonalContextSessionStart.ps1'
$personalFixture = Join-Path $fixtureRoot 'PersonalContextFixture.cmd'
$litigationProvider = Join-Path $runtimeRoot 'Invoke-HWOSLitigationPromptGuard.ps1'

. $broker
. $sessionStart

$litigationJson = '{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"LITIGATION"}}'
$personalJson = '{"schemaVersion":"hw-personal-context-cli/v1","command":"retrieve","ok":true,"data":{"context":"PERSONAL"}}'
$litigationContext = Get-HWOSLitigationContext -Output $litigationJson
$personalContext = Get-HWOSPersonalContext -Output $personalJson
$combined = New-HWOSContextBrokerOutput -LitigationContext $litigationContext -PersonalContext $personalContext
$combinedResponse = $combined | ConvertFrom-Json -ErrorAction Stop
if ($combinedResponse.hookSpecificOutput.hookEventName -cne 'UserPromptSubmit' -or
    -not $combinedResponse.hookSpecificOutput.additionalContext.Contains('[Litigation advisory context]') -or
    -not $combinedResponse.hookSpecificOutput.additionalContext.Contains('LITIGATION') -or
    -not $combinedResponse.hookSpecificOutput.additionalContext.Contains('[Personal Context advisory context]') -or
    -not $combinedResponse.hookSpecificOutput.additionalContext.Contains('PERSONAL')) {
  throw 'Completed provider results did not compose into the exact combined hook response.'
}

$personalOnly = New-HWOSContextBrokerOutput -LitigationContext '' -PersonalContext $personalContext
if (-not ($personalOnly | ConvertFrom-Json -ErrorAction Stop).hookSpecificOutput.additionalContext.Contains('PERSONAL')) { throw 'Personal-only context did not compose.' }
if (-not [string]::IsNullOrWhiteSpace((New-HWOSContextBrokerOutput -LitigationContext '' -PersonalContext $null))) { throw 'No-result composition must be silent.' }

$malformedLitigation = $null
try { Get-HWOSLitigationContext -Output 'not-json' | Out-Null } catch { $malformedLitigation = $_.Exception.Message }
if ($malformedLitigation -cne 'litigation-provider-malformed-output') { throw 'Malformed litigation output did not fail the broker contract.' }
foreach ($invalidPersonal in @('', 'not-json', '{"schemaVersion":"wrong","command":"retrieve","ok":true,"data":{"context":"PERSONAL"}}', '{"schemaVersion":"hw-personal-context-cli/v1","command":"retrieve","ok":false,"data":{"context":"PERSONAL"}}')) {
  if ($null -ne (Get-HWOSPersonalContext -Output $invalidPersonal)) { throw 'Invalid Personal Context output was not omitted.' }
}

$briefingJson = '{"schemaVersion":"hw-personal-context-cli/v1","command":"briefing","ok":true,"data":{"context":"PERSONAL"}}'
$briefingContext = Get-HWOSPersonalContextBriefing -Output $briefingJson
$sessionResponse = (New-HWOSSessionStartOutput -Context $briefingContext) | ConvertFrom-Json -ErrorAction Stop
if ($sessionResponse.hookSpecificOutput.hookEventName -cne 'SessionStart' -or $sessionResponse.hookSpecificOutput.additionalContext -cne 'PERSONAL') { throw 'Completed briefing result did not compose into the exact SessionStart response.' }
if ($null -ne (Get-HWOSPersonalContextBriefing -Output '')) { throw 'Empty briefing output was not omitted.' }

$litigationPayload = '{"hook_event_name":"UserPromptSubmit","prompt":"draft an affidavit for an NSW court proceeding"}'
$litigationProcess = Invoke-HWOSChildProcess -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Arguments "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$litigationProvider`"" -StandardInput $litigationPayload -TimeoutMilliseconds 10000 -CreateNoWindow $false
if ($litigationProcess.TimedOut -or $litigationProcess.ExitCode -ne 0 -or [string]::IsNullOrWhiteSpace((Get-HWOSLitigationContext -Output $litigationProcess.StandardOutput))) {
  throw 'Windows PowerShell 5.1 child stdin did not reach the real litigation provider.'
}

$previousPersonal = $env:HWOS_PERSONAL_CONTEXT_TEST_MODE
$beforeTimeoutPids = @(Get-Process -Name timeout -ErrorAction SilentlyContinue | ForEach-Object { $_.Id })
try {
  $env:HWOS_PERSONAL_CONTEXT_TEST_MODE = 'timeout'
  $arguments = "/d /c `"$personalFixture`" retrieve --prompt-stdin"
  $timeoutResult = Invoke-HWOSChildProcess -FilePath $env:ComSpec -Arguments $arguments -StandardInput 'disposable hook test' -TimeoutMilliseconds 900
  if (-not $timeoutResult.TimedOut -or $null -ne $timeoutResult.ExitCode -or $timeoutResult.StandardOutput.Length -ne 0) { throw 'Personal Context deadline did not return the exact fail-open timeout result.' }
  Start-Sleep -Milliseconds 100
  $survivors = @(Get-Process -Name timeout -ErrorAction SilentlyContinue | Where-Object { $beforeTimeoutPids -notcontains $_.Id })
  if ($survivors.Count -gt 0) { throw 'Personal Context timeout left a fixture descendant running.' }
} finally {
  $env:HWOS_PERSONAL_CONTEXT_TEST_MODE = $previousPersonal
}

$powerShell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$missingPersonalPath = Join-Path $fixtureRoot 'missing-personal-context.exe'
$defaultProviderResult = Invoke-HWOSChildProcess -FilePath $powerShell -Arguments "-NoLogo -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$broker`" -PersonalContextPath `"$missingPersonalPath`"" -StandardInput $litigationPayload -TimeoutMilliseconds 20000 -CreateNoWindow $false
if ($defaultProviderResult.TimedOut -or $defaultProviderResult.ExitCode -ne 0 -or
    -not [string]::IsNullOrEmpty($defaultProviderResult.StandardError)) {
  throw "Default-provider broker launch failed: $($defaultProviderResult.StandardError)"
}
$defaultProviderResponse = $defaultProviderResult.StandardOutput | ConvertFrom-Json -ErrorAction Stop
if (-not $defaultProviderResponse.hookSpecificOutput.additionalContext.Contains('[Litigation advisory context]') -or
    $defaultProviderResponse.hookSpecificOutput.additionalContext.Contains('[Personal Context advisory context]')) {
  throw 'Default litigation provider did not preserve litigation context when Personal Context was absent.'
}
$start = [Diagnostics.ProcessStartInfo]::new()
$start.FileName = $powerShell
$start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$broker`" -LitigationProviderPath `"$litigationProvider`" -PersonalContextPath `"$missingPersonalPath`" -PowerShellPath `"$powerShell`""
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardInput = $true
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$brokerProcess = [Diagnostics.Process]::Start($start)
$brokerProcess.StandardInput.Write($litigationPayload)
$brokerProcess.StandardInput.Close()
$brokerStdoutTask = $brokerProcess.StandardOutput.ReadToEndAsync()
$brokerStderrTask = $brokerProcess.StandardError.ReadToEndAsync()
if (-not $brokerProcess.WaitForExit(20000)) {
  Stop-HWOSBrokerProcessTree -Process $brokerProcess
  [void]$brokerProcess.WaitForExit(1000)
  throw 'Personal fail-open broker invocation exceeded 20 seconds.'
}
$brokerStdout = $brokerStdoutTask.GetAwaiter().GetResult()
$brokerStderr = $brokerStderrTask.GetAwaiter().GetResult()
if ($brokerProcess.ExitCode -ne 0 -or -not [string]::IsNullOrEmpty($brokerStderr)) { throw "Personal fail-open broker invocation failed: $brokerStderr" }
$brokerResponse = $brokerStdout | ConvertFrom-Json -ErrorAction Stop
if (-not $brokerResponse.hookSpecificOutput.additionalContext.Contains('[Litigation advisory context]') -or
    $brokerResponse.hookSpecificOutput.additionalContext.Contains('[Personal Context advisory context]')) {
  throw 'Personal Context spawn failure did not preserve only the real litigation context.'
}

foreach ($stopCommand in @('Stop-HWOSBrokerProcessTree', 'Stop-HWOSSessionStartProcessTree')) {
  $raceStart = [Diagnostics.ProcessStartInfo]::new()
  $raceStart.FileName = $env:ComSpec
  $raceStart.Arguments = '/d /c %SystemRoot%\System32\ping.exe -n 3 127.0.0.1 >nul'
  $raceStart.UseShellExecute = $false
  $raceStart.CreateNoWindow = $true
  $raceProcess = [Diagnostics.Process]::Start($raceStart)
  try {
    & $stopCommand -Process $raceProcess
    [void]$raceProcess.WaitForExit(1000)
    & $stopCommand -Process $raceProcess
    if (-not $raceProcess.HasExited) { throw "$stopCommand left its process running." }
  } finally {
    if (-not $raceProcess.HasExited) { $raceProcess.Kill() }
    $raceProcess.Dispose()
  }
}

Write-Output 'PASS: Personal Context composition, invalid-output omission, real/default litigation preservation, SessionStart, deadline, and race-safe process-tree contracts'
