$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$deployment = Join-Path (Split-Path -Parent $PSScriptRoot) 'deployment'
Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
$module = Get-Module 'HWOSLeanGuard.Deployment'
$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ('HWOSUninstallTransaction-' + [Guid]::NewGuid().ToString('N'))))
$registry = 'HKCU:\SOFTWARE\HWOSLeanGuardTests\' + [Guid]::NewGuid().ToString('N')
$lean = Join-Path $sandbox 'machine\lean'
$personal = Join-Path $sandbox 'machine\personal'
$statePath = Join-Path $sandbox 'state-root\state\install-state.json'
try {
  [IO.Directory]::CreateDirectory($lean) | Out-Null
  [IO.Directory]::CreateDirectory($personal) | Out-Null
  [IO.File]::WriteAllText((Join-Path $lean 'guard.txt'), 'lean-runtime')
  [IO.File]::WriteAllText((Join-Path $personal 'context.txt'), 'personal-runtime')
  New-Item -Path $registry -Force | Out-Null
  New-ItemProperty -LiteralPath $registry -Name Settings -PropertyType String -Value 'installed-bootstrap' -Force | Out-Null
  $prestatePath = Join-Path $sandbox 'state-root\rollback\prestate-original.json'
  Write-HWOSLeanGuardJson -Path $prestatePath -Value @{policyRegistryPath=$registry;registry=@{keyExists=$true;valueExists=$true;valueKind='ExpandString';value='before-install'}}
  $state = [pscustomobject]@{schemaVersion='hw-os-lean-guard-state/v2';packageVersion='0.1.8';policyRegistryPath=$registry;installRoots=[pscustomobject]@{leanGuard=$lean;personalContext=$personal};files=[pscustomobject]@{leanGuard=[pscustomobject](Get-HWOSLeanGuardFileHashes $lean);personalContext=[pscustomobject](Get-HWOSLeanGuardFileHashes $personal)};bootstrapSha256=(Get-HWOSLeanGuardTextSha256 'installed-bootstrap');rollbackReceiptPath=$prestatePath}
  Write-HWOSLeanGuardJson -Path $statePath -Value $state
  $receiptHash = Get-HWOSLeanGuardSha256 $statePath
  $userStore = Join-Path $sandbox 'user-store'
  [IO.Directory]::CreateDirectory($userStore) | Out-Null
  [IO.File]::WriteAllText((Join-Path $userStore 'personal-context.db'), 'retained-user-data')
  foreach ($scenario in @('second-rename','registry-restore','receipt-rename','commit-journal')) {
    Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
    $module = Get-Module 'HWOSLeanGuard.Deployment'
    & $module {
      param($Scenario,$Personal,$Receipt)
      $script:UninstallScenario=$Scenario; $script:UninstallPersonal=$Personal; $script:UninstallReceipt=$Receipt
      $script:OriginalRestore=${function:Restore-HWOSLeanGuardRegistryState}
      $script:OriginalWrite=${function:Write-HWOSLeanGuardJson}
      function script:Move-Item {
        param($LiteralPath,$Destination)
        if (($script:UninstallScenario -eq 'second-rename' -and $LiteralPath -eq $script:UninstallPersonal) -or ($script:UninstallScenario -eq 'receipt-rename' -and $LiteralPath -eq $script:UninstallReceipt)) { throw ('injected-' + $script:UninstallScenario) }
        Microsoft.PowerShell.Management\Move-Item -LiteralPath $LiteralPath -Destination $Destination
      }
      function script:Restore-HWOSLeanGuardRegistryState {
        param($Path,$State)
        & $script:OriginalRestore -Path $Path -State $State
        if ($script:UninstallScenario -eq 'registry-restore' -and $State.value -ceq 'before-install') { throw 'injected-registry-restore' }
      }
      function script:Write-HWOSLeanGuardJson {
        param($Path,$Value)
        if ($script:UninstallScenario -eq 'commit-journal' -and @($Value.Keys) -contains 'status' -and $Value.status -ceq 'committed') { throw 'injected-commit-journal' }
        & $script:OriginalWrite -Path $Path -Value $Value
      }
    } $scenario $personal $statePath
    $failure = $null
    try { Remove-HWOSLeanGuardMachineInstall -State $state -StatePath $statePath -PolicyRegistryPath $registry -ExpectedLeanGuardRoot $lean -ExpectedPersonalContextRoot $personal | Out-Null } catch { $failure = $_.Exception.Message }
    if ($failure -cne ('injected-' + $scenario)) { throw "Expected injected-$scenario, got '$failure'." }
    if (-not (Test-HWOSLeanGuardRecordedFiles -Root $lean -Files $state.files.leanGuard) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $personal -Files $state.files.personalContext) -or (Get-HWOSLeanGuardSha256 $statePath) -cne $receiptHash -or (Get-HWOSLeanGuardRegistryState $registry).value -cne 'installed-bootstrap') { throw "Uninstall $scenario failure left partial roots, registry, or receipt state." }
  }
  Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
  $retry = Remove-HWOSLeanGuardMachineInstall -State $state -StatePath $statePath -PolicyRegistryPath $registry -ExpectedLeanGuardRoot $lean -ExpectedPersonalContextRoot $personal
  if (-not $retry.committed -or -not $retry.cleanupComplete -or (Test-Path -LiteralPath $statePath)) { throw 'Retry after rolled-back uninstall did not complete.' }
  [IO.Directory]::CreateDirectory($lean) | Out-Null; [IO.Directory]::CreateDirectory($personal) | Out-Null
  [IO.File]::WriteAllText((Join-Path $lean 'guard.txt'), 'lean-runtime'); [IO.File]::WriteAllText((Join-Path $personal 'context.txt'), 'personal-runtime')
  New-ItemProperty -LiteralPath $registry -Name Settings -PropertyType String -Value 'installed-bootstrap' -Force | Out-Null
  Write-HWOSLeanGuardJson -Path $statePath -Value $state
  $module = Get-Module 'HWOSLeanGuard.Deployment'
  & $module {
    function script:Remove-Item {
      param($LiteralPath,[switch]$Recurse,[switch]$Force)
      if ($Recurse -and (Split-Path -Leaf $LiteralPath) -like '*personal') { throw 'injected-second-removal' }
      Microsoft.PowerShell.Management\Remove-Item -LiteralPath $LiteralPath -Recurse:$Recurse -Force:$Force
    }
  }
  $result = Remove-HWOSLeanGuardMachineInstall -State $state -StatePath $statePath -PolicyRegistryPath $registry -ExpectedLeanGuardRoot $lean -ExpectedPersonalContextRoot $personal
  if (-not $result.committed -or $result.cleanupComplete -or (Test-Path -LiteralPath $lean) -or (Test-Path -LiteralPath $personal) -or (Test-Path -LiteralPath $statePath)) { throw 'Second cleanup failure did not leave coherent removed state with pending cleanup.' }
  $journal = Read-HWOSLeanGuardJson $result.recoveryJournalPath
  if ($journal.status -cne 'cleanup-pending' -or $journal.cleanupComplete -or -not (Test-Path -LiteralPath $journal.roots[1].quarantine)) { throw 'Pending cleanup was not durably recorded.' }
  if (-not $result.cleanupPending -or $result.removalStatus -cne 'removed-cleanup-pending' -or @($result.retainedPaths).Count -ne 1 -or $result.retainedPaths[0] -cne $journal.roots[1].quarantine) { throw 'Pending cleanup structured output omits retained physical bytes.' }
  Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
  $module = Get-Module 'HWOSLeanGuard.Deployment'
  & $module { function script:Set-HWOSLeanGuardTreeAcls { param($Root,$Grants,$FailureLabel) } }
  $sourceLean = Join-Path $sandbox 'reinstall-source\lean'; $sourcePersonal = Join-Path $sandbox 'reinstall-source\personal'
  [IO.Directory]::CreateDirectory($sourceLean) | Out-Null; [IO.Directory]::CreateDirectory($sourcePersonal) | Out-Null
  [IO.File]::WriteAllText((Join-Path $sourceLean 'new.txt'), 'new-lean'); [IO.File]::WriteAllText((Join-Path $sourcePersonal 'new.txt'), 'new-personal')
  Invoke-HWOSLeanGuardTwoRootSwap -Trees @([pscustomobject]@{sourceRoot=$sourceLean;destinationRoot=$lean;relativeFiles=@()},[pscustomobject]@{sourceRoot=$sourcePersonal;destinationRoot=$personal;relativeFiles=@()})
  if ([IO.File]::ReadAllText((Join-Path $lean 'new.txt')) -cne 'new-lean' -or [IO.File]::ReadAllText((Join-Path $personal 'new.txt')) -cne 'new-personal') { throw 'Reinstallation could not recover after pending cleanup.' }
  if ([IO.File]::ReadAllText((Join-Path $userStore 'personal-context.db')) -cne 'retained-user-data') { throw 'Uninstall changed per-user data.' }
  Write-Output 'PASS: uninstall precommit rename/registry/receipt/journal rollback, exact retry, pending cleanup state and reinstall recovery, user data retained'
} finally {
  Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
  if (Test-Path -LiteralPath $registry) { Remove-Item -LiteralPath $registry -Recurse -Force }
  $prefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $sandbox.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $sandbox) -notlike 'HWOSUninstallTransaction-*') { throw 'Unsafe uninstall test cleanup.' }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
