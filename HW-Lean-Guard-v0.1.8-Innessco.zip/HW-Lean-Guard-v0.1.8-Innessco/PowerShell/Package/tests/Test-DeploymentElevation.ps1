$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$source = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $PSScriptRoot) 'deployment\Install-HWOSLeanGuardOneCommand.ps1'))
$loader = [regex]::Match($source, '(?s)\$elevatedLoader = @''\r?\n(?<loader>.*?)\r?\n''@').Groups['loader'].Value
$tokens = $null; $errors = $null
$ast = [Management.Automation.Language.Parser]::ParseInput($loader, [ref]$tokens, [ref]$errors)
$loop = @($ast.FindAll({param($node) $node -is [Management.Automation.Language.ForEachStatementAst] -and $node.Condition.Extent.Text -ceq '$expectedFiles.Keys'}, $true))
if ($loop.Count -ne 1) { throw 'Exact staged hash verification loop was not found.' }
$verification = [scriptblock]::Create($loop[0].Extent.Text)
$stagedPackageRoot = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardElevation-' + [Guid]::NewGuid().ToString('N'))))
try {
  [IO.Directory]::CreateDirectory($stagedPackageRoot) | Out-Null
  [IO.File]::WriteAllText((Join-Path $stagedPackageRoot 'valid.txt'), 'valid')
  $expectedFiles = @{'valid.txt'=(Get-FileHash -LiteralPath (Join-Path $stagedPackageRoot 'valid.txt') -Algorithm SHA256).Hash.ToLowerInvariant()}
  & $verification
  foreach ($relative in @('..\escape.txt','../escape.txt','C:\escape.txt','valid.txt:stream')) {
    $expectedFiles = @{}; $expectedFiles[$relative] = '0' * 64
    $failure = $null
    try { & $verification } catch { $failure = $_.Exception.Message }
    if ($failure -cne 'Elevated staged manifest contains an invalid relative path.') { throw "Elevated loader accepted or incorrectly rejected '$relative': $failure" }
  }
  foreach ($required in @('personalContextInstallRoot = $PersonalContextInstallRoot', '-PersonalContextInstallRoot ([string]$payload.personalContextInstallRoot)', '-PersonalContextInstallRoot $PersonalContextInstallRoot')) {
    if (-not $source.Contains($required)) { throw 'Personal Context root was not forwarded through the authenticated elevation payload.' }
  }
  $childReturn = $source.IndexOf('if ($ElevatedChild) {', $source.IndexOf('$installJson ='))
  $userWorkbench = $source.IndexOf('$workbenchJson =', $childReturn)
  if ($childReturn -lt 0 -or $userWorkbench -le $childReturn -or -not $source.Substring($childReturn, $userWorkbench - $childReturn).Contains('return')) { throw 'Elevated child can reach current-user Workbench application.' }
  Write-Output 'PASS: actual staged verifier accepts exact bytes and rejects traversal/rooted/ADS paths; authenticated Personal Context forwarding and caller-user Workbench phase retained'
} finally {
  $prefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $stagedPackageRoot.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $stagedPackageRoot) -notlike 'HWOSLeanGuardElevation-*') { throw 'Unsafe elevation sandbox cleanup.' }
  if (Test-Path -LiteralPath $stagedPackageRoot) { Remove-Item -LiteralPath $stagedPackageRoot -Recurse -Force }
}
