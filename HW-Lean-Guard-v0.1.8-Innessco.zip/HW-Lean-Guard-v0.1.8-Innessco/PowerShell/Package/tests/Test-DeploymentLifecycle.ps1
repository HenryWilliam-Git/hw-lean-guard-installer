param([switch]$BoundaryOnly)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $PSScriptRoot
$deployment = Join-Path $package 'deployment'
$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardLifecycle-' + [Guid]::NewGuid().ToString('N'))))
$registryPath = 'HKCU:\SOFTWARE\HWOSLeanGuardTests\' + [Guid]::NewGuid().ToString('N')
$stateRoot = Join-Path $sandbox 'state-root'
$leanRoot = Join-Path $sandbox 'machine\lean'
$personalRoot = Join-Path $sandbox 'machine\personal'
$statePath = Join-Path $stateRoot 'state\install-state.json'
$global:HWOSDeploymentLifecycleInjectFailure = $false
$global:HWOSDeploymentLifecycleCleanupFailure = $false
$policySentinelSnapshot = $null
function Get-LifecyclePolicySentinels {
  $childPath = Join-Path $registryPath 'UnrelatedPolicy'
  if (-not (Test-Path -LiteralPath $registryPath) -or -not (Test-Path -LiteralPath $childPath)) { throw 'Unrelated policy registry key or subkey was removed.' }
  $key = Get-Item -LiteralPath $registryPath
  $child = Get-Item -LiteralPath $childPath
  return [ordered]@{
    value = $key.GetValue('UnrelatedValue', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    valueKind = $key.GetValueKind('UnrelatedValue').ToString()
    childValue = $child.GetValue('ChildValue', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    childValueKind = $child.GetValueKind('ChildValue').ToString()
    keyAcl = (Get-Acl -Path $registryPath).Sddl
    childAcl = (Get-Acl -Path $childPath).Sddl
  }
}
function Assert-LifecyclePolicySentinels {
  if ($null -eq $policySentinelSnapshot) { return }
  $actual = Get-LifecyclePolicySentinels
  foreach ($field in $policySentinelSnapshot.Keys) { if ($actual[$field] -cne $policySentinelSnapshot[$field]) { throw "Unrelated policy registry state changed: $field" } }
}
function Import-Module {
  param([Parameter(Position=0)][object]$Name, [switch]$Force)
  Microsoft.PowerShell.Core\Import-Module -Name $Name -Force:$Force -Global
  $module = Get-Module 'HWOSLeanGuard.Deployment'
  & $module {
    param($InjectFailure,$CleanupFailure)
    $script:LifecycleInjectFailure = $InjectFailure
    $script:LifecycleCleanupFailure = $CleanupFailure
    function script:Test-HWOSLeanGuardAdministrator { return $true }
    function script:Test-HWOSLeanGuardDotNetPrerequisite { return $true }
    function script:Set-HWOSLeanGuardTreeAcls { param($Root,$Grants,$FailureLabel) }
    function script:Set-HWOSLeanGuardAcls { param($InstallRoot,$PersonalContextRoot,$StateRoot) if ($script:LifecycleInjectFailure) { throw 'injected-install-finalization' } }
    function script:Remove-Item {
      param($LiteralPath,[switch]$Recurse,[switch]$Force)
      if ($script:LifecycleCleanupFailure -and $Recurse -and (Split-Path -Leaf $LiteralPath) -like '.hwos-uninstall-*-personal') { throw 'injected-quarantine-cleanup' }
      Microsoft.PowerShell.Management\Remove-Item -LiteralPath $LiteralPath -Recurse:$Recurse -Force:$Force
    }
    Export-ModuleMember -Function Test-HWOSLeanGuardAdministrator,Test-HWOSLeanGuardDotNetPrerequisite,Set-HWOSLeanGuardAcls
  } $global:HWOSDeploymentLifecycleInjectFailure $global:HWOSDeploymentLifecycleCleanupFailure
  function global:Test-HWOSLeanGuardAdministrator { return $true }
  function global:Test-HWOSLeanGuardDotNetPrerequisite { return $true }
  function global:Set-HWOSLeanGuardAcls { param($InstallRoot,$PersonalContextRoot,$StateRoot) if ($global:HWOSDeploymentLifecycleInjectFailure) { throw 'injected-install-finalization' } }
}
function Invoke-FixtureInstall {
  try {
    & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $package -InstallRoot $leanRoot -PersonalContextInstallRoot $personalRoot -StateRoot $stateRoot -PolicyRegistryPath $registryPath | ConvertFrom-Json -ErrorAction Stop
  } finally { Assert-LifecyclePolicySentinels }
}
function Assert-LifecycleFailure {
  param([scriptblock]$Action, [string]$Pattern)
  $failure = $null
  try { & $Action | Out-Null } catch { $failure = $_.Exception.Message }
  if ($null -eq $failure -or $failure -notlike $Pattern) { throw "Expected '$Pattern', got '$failure'." }
}
try {
  $unsafePackage = Join-Path $sandbox 'unsafe-source-overlap'
  [IO.Directory]::CreateDirectory($sandbox) | Out-Null
  Copy-Item -LiteralPath $package -Destination $unsafePackage -Recurse
  Assert-LifecycleFailure { & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $unsafePackage -InstallRoot $leanRoot -PersonalContextInstallRoot $personalRoot -StateRoot $unsafePackage -PolicyRegistryPath $registryPath } '*roots overlap*'
  Assert-HWOSLeanGuardPackage -PackageRoot $unsafePackage | Out-Null
  if ((Test-Path -LiteralPath $leanRoot) -or (Test-Path -LiteralPath $personalRoot) -or (Test-Path -LiteralPath $registryPath)) { throw 'Rejected source/state overlap mutated machine targets.' }
  Assert-LifecycleFailure { & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $unsafePackage -InstallRoot $leanRoot -PersonalContextInstallRoot $personalRoot -StateRoot (Join-Path $unsafePackage 'nested-state') -PolicyRegistryPath $registryPath } '*roots overlap*'
  if (Test-Path -LiteralPath (Join-Path $unsafePackage 'nested-state')) { throw 'Rejected nested source/state overlap wrote state.' }
  $stageState = Join-Path $sandbox 'staged-state'
  $stagePackage = Join-Path $stageState 'staging\authenticated-fixture\package'
  [IO.Directory]::CreateDirectory((Split-Path -Parent $stagePackage)) | Out-Null
  Copy-Item -LiteralPath $package -Destination $stagePackage -Recurse
  $staged = & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $stagePackage -InstallRoot $leanRoot -PersonalContextInstallRoot $personalRoot -StateRoot $stageState -PolicyRegistryPath $registryPath | ConvertFrom-Json
  if ($staged.result -cne 'PASS' -or $staged.sourceManifestSha256 -cne (Get-HWOSLeanGuardSha256 -Path (Join-Path $stagePackage 'manifest.json'))) { throw 'Authenticated package-under-state staging topology was rejected.' }
  & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stageState -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | Out-Null
  Assert-HWOSLeanGuardPackage -PackageRoot $stagePackage | Out-Null
  Write-Output 'PASS: source/state equal and nested rejection, supported package-under-state staging installation and source preservation'
  if ($BoundaryOnly) { return }
  [IO.Directory]::CreateDirectory($leanRoot) | Out-Null
  [IO.Directory]::CreateDirectory($personalRoot) | Out-Null
  New-Item -Path $registryPath -Force | Out-Null
  New-ItemProperty -LiteralPath $registryPath -Name Settings -Value 'original-policy' -PropertyType ExpandString -Force | Out-Null
  New-ItemProperty -LiteralPath $registryPath -Name UnrelatedValue -Value '%SystemRoot%\synthetic-sentinel' -PropertyType ExpandString -Force | Out-Null
  $sentinelChild = Join-Path $registryPath 'UnrelatedPolicy'
  New-Item -Path $sentinelChild | Out-Null
  New-ItemProperty -LiteralPath $sentinelChild -Name ChildValue -Value 'retain-child-policy' -PropertyType String -Force | Out-Null
  foreach ($target in @($registryPath, $sentinelChild)) {
    $acl = Get-Acl -Path $target
    $acl.SetAccessRuleProtection($true, $true)
    Set-Acl -Path $target -AclObject $acl
  }
  $policySentinelSnapshot = Get-LifecyclePolicySentinels
  $installed = Invoke-FixtureInstall
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $installed
  $invalidEvidence = $installed.PSObject.Copy()
  $invalidEvidence | Add-Member -MemberType NoteProperty -Name unexpected -Value $false
  Assert-LifecycleFailure { & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $invalidEvidence } '*uncontracted field*'
  if ($installed.result -cne 'PASS') { throw 'Fresh sandbox install failed.' }
  $receipt = Read-HWOSLeanGuardJson -Path $statePath
  $packageVersion = [IO.File]::ReadAllText((Join-Path $package 'VERSION')).Trim()
  if ($receipt.schemaVersion -cne 'hw-os-lean-guard-state/v2' -or $receipt.packageVersion -cne $packageVersion -or $receipt.runtimePrerequisites.dotnetArchitecture -cne 'x64') { throw 'Fresh install receipt is incomplete.' }
  foreach ($record in @($receipt, $installed)) {
    if (@($record.PSObject.Properties.Name) -cnotcontains 'sourceManifestSha256' -or @($record.PSObject.Properties.Name) -cnotcontains 'priorInstallation') { throw 'Install receipt and evidence must record validated source manifest and prior installation provenance.' }
    if ($record.sourceManifestSha256 -cne (Get-HWOSLeanGuardSha256 -Path (Join-Path $package 'manifest.json')) -or $null -ne $record.priorInstallation) { throw 'Fresh install provenance is incorrect.' }
  }
  if (-not (Test-Path -LiteralPath (Join-Path $leanRoot 'deployment\Configure-HWOSClaudeWorkbench.ps1'))) { throw 'Workbench restore configurator was omitted from the machine install.' }
  $nativeFiles = @($receipt.files.personalContext.PSObject.Properties | Where-Object Name -Match 'e_sqlite3\.dll$')
  if ($nativeFiles.Count -eq 0) { throw 'Personal Context native SQLite DLL is missing from the receipt.' }
  $nativePath = Join-Path $personalRoot $nativeFiles[0].Name
  $nativeBytes = [IO.File]::ReadAllBytes($nativePath)
  try {
    Remove-Item -LiteralPath $nativePath -Force
    if ((Get-HWOSLeanGuardInstalledChecks -StateRoot $stateRoot -PolicyRegistryPath $registryPath).installedFilesMatch) { throw 'Detector accepted a missing native DLL.' }
  } finally { [IO.File]::WriteAllBytes($nativePath, $nativeBytes) }
  $extraPath = Join-Path $personalRoot 'unexpected.dll'
  try {
    [IO.File]::WriteAllText($extraPath, 'unexpected')
    if ((Get-HWOSLeanGuardInstalledChecks -StateRoot $stateRoot -PolicyRegistryPath $registryPath).installedFilesMatch) { throw 'Detector accepted an additional installed DLL.' }
  } finally { Remove-Item -LiteralPath $extraPath -Force }
  $priorReceiptHash = Get-HWOSLeanGuardSha256 -Path $statePath
  $global:HWOSDeploymentLifecycleInjectFailure = $true
  Assert-LifecycleFailure { Invoke-FixtureInstall } '*injected-install-finalization*'
  if ((Get-HWOSLeanGuardSha256 -Path $statePath) -cne $priorReceiptHash -or -not (Test-HWOSLeanGuardRecordedFiles -Root $leanRoot -Files $receipt.files.leanGuard) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $personalRoot -Files $receipt.files.personalContext)) { throw 'Failed reinstall did not restore exact trees and receipt bytes.' }
  $registry = Get-HWOSLeanGuardRegistryState -Path $registryPath
  if ((Get-HWOSLeanGuardTextSha256 -Text $registry.value) -cne $receipt.bootstrapSha256) { throw 'Failed reinstall did not restore immediate registry state.' }
  $global:HWOSDeploymentLifecycleInjectFailure = $false

  $retained = Join-Path $sandbox 'user-appdata\HenryWilliam\PersonalContext\user-sid'
  [IO.Directory]::CreateDirectory($retained) | Out-Null
  foreach ($name in @('personal-context.db','content-entropy.bin','search-key.bin','personal-context-index.db')) { [IO.File]::WriteAllText((Join-Path $retained $name), 'retain-' + $name) }
  $userHashes = Get-HWOSLeanGuardFileHashes -Root $retained
  & (Join-Path $PSScriptRoot 'Test-DeploymentRepair.ps1') -PackageRoot $package -LeanRoot $leanRoot -PersonalRoot $personalRoot -StateRoot $stateRoot -RegistryPath $registryPath -UserStore $retained -Install { Invoke-FixtureInstall }
  $receipt = Read-HWOSLeanGuardJson -Path $statePath
  $priorReceiptHash = Get-HWOSLeanGuardSha256 -Path $statePath
  $badReceipt = Read-HWOSLeanGuardJson -Path $statePath
  $badReceipt.installRoots.personalContext = $retained
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $badReceipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*outside the authorised uninstall target*'
  $badReceipt.installRoots.personalContext = $personalRoot
  $badReceipt.rollbackReceiptPath = Join-Path $sandbox 'unbounded.json'
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $badReceipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*outside the authorised rollback target*'
  if ((Get-HWOSLeanGuardSha256 -Path $statePath) -cne $priorReceiptHash) { throw 'Rejected uninstall mutated the receipt.' }
  $childJunction = Join-Path $personalRoot 'redirect'
  New-Item -ItemType Junction -Path $childJunction -Target $retained | Out-Null
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $receipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*reparse*'
  [IO.Directory]::Delete($childJunction)
  $result = & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | ConvertFrom-Json -ErrorAction Stop
  Assert-LifecyclePolicySentinels
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $result
  if ($result.result -cne 'PASS' -or (Test-Path -LiteralPath $statePath) -or (Test-Path -LiteralPath $leanRoot) -or (Test-Path -LiteralPath $personalRoot)) { throw 'Sandbox uninstall did not remove exact machine state.' }
  if (-not (Test-HWOSLeanGuardRecordedFiles -Root $retained -Files ([pscustomobject]$userHashes))) { throw 'Uninstall changed per-user stores.' }
  $restored = Get-HWOSLeanGuardRegistryState -Path $registryPath
  if ($restored.value -cne 'original-policy' -or $restored.valueKind -cne 'ExpandString') { throw 'Uninstall did not restore exact original policy value and kind.' }

  Invoke-FixtureInstall | Out-Null
  $v1PersonalHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $personalRoot)
  foreach ($relative in @('runtime\Invoke-HWOSLeanGuard.ps1', 'policy\guard-policy.json')) { [IO.File]::WriteAllText((Join-Path $leanRoot $relative), 'synthetic-v1-runtime') }
  [IO.File]::WriteAllText((Join-Path $leanRoot 'v1.txt'), 'v1-runtime')
  $v1Rollback = Join-Path $stateRoot 'rollback\prestate-v1.json'
  Write-HWOSLeanGuardJson -Path $v1Rollback -Value @{policyRegistryPath=$registryPath; registry=@{keyExists=$true;valueExists=$true;valueKind='String';value='before-v1'}}
  Write-HWOSLeanGuardJson -Path $statePath -Value @{schemaVersion='hw-os-lean-guard-state/v1';packageVersion='0.1.0';installRoot=$leanRoot;policyRegistryPath=$registryPath;preStatePath=$v1Rollback}
  $v1ReceiptHash = Get-HWOSLeanGuardSha256 -Path $statePath
  $v1MixedHashes = [pscustomobject](Get-HWOSLeanGuardFileHashes -Root $leanRoot)
  $global:HWOSDeploymentLifecycleInjectFailure = $true
  try { Assert-LifecycleFailure { Invoke-FixtureInstall } '*injected-install-finalization*' } finally { $global:HWOSDeploymentLifecycleInjectFailure = $false }
  if ((Get-HWOSLeanGuardSha256 -Path $statePath) -cne $v1ReceiptHash -or -not (Test-HWOSLeanGuardRecordedFiles -Root $leanRoot -Files $v1MixedHashes) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $personalRoot -Files $v1PersonalHashes)) { throw 'Failed v1 mixed-tree upgrade did not restore exact prestate.' }
  $upgrade = Invoke-FixtureInstall
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $upgrade
  if ($upgrade.result -cne 'PASS' -or (Test-Path -LiteralPath (Join-Path $leanRoot 'v1.txt'))) { throw 'v1 upgrade did not replace the old runtime.' }
  if ($upgrade.priorInstallation.receiptSha256 -cne $v1ReceiptHash -or $upgrade.priorInstallation.packageVersion -cne '0.1.0' -or $upgrade.priorInstallation.checkStatus -cne 'unsupported-receipt' -or $upgrade.priorInstallation.checks.receiptVersionMatch -ne $false) { throw 'v1 upgrade provenance misreported unevaluated checks.' }
  if (-not (Test-HWOSLeanGuardRecordedFiles -Root $personalRoot -Files $v1PersonalHashes) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $retained -Files ([pscustomobject]$userHashes))) { throw 'v1 mixed-tree upgrade changed current Personal Context or user stores.' }
  $upgraded = Read-HWOSLeanGuardJson -Path $statePath
  $upgradePrestate = Read-HWOSLeanGuardJson -Path $upgraded.rollbackReceiptPath
  if ($upgradePrestate.registry.value -cne 'before-v1' -or $upgradePrestate.priorReceipt.schemaVersion -cne 'hw-os-lean-guard-state/v1') { throw 'Upgrade did not retain original uninstall policy and v1 receipt.' }
  & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | Out-Null
  Assert-LifecyclePolicySentinels
  if ((Get-HWOSLeanGuardRegistryState -Path $registryPath).value -cne 'before-v1') { throw 'Upgraded uninstall restored the wrong policy.' }
  Invoke-FixtureInstall | Out-Null
  $global:HWOSDeploymentLifecycleCleanupFailure = $true
  $cleanupOutput = @()
  $cleanupFailure = $null
  try {
    & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | ForEach-Object { $cleanupOutput += $_ }
  } catch { $cleanupFailure = $_.Exception.Message }
  Assert-LifecyclePolicySentinels
  if ($cleanupFailure -notlike 'Machine uninstall committed; quarantine cleanup is incomplete.*') { throw "Expected committed cleanup failure, got '$cleanupFailure'." }
  $cleanupEvidence = ($cleanupOutput -join "`n") | ConvertFrom-Json -ErrorAction Stop
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $cleanupEvidence
  if ($cleanupEvidence.result -cne 'FAIL' -or -not $cleanupEvidence.removal.cleanupPending -or $cleanupEvidence.removal.status -cne 'removed-cleanup-pending' -or $cleanupEvidence.removal.retainedPaths.Count -ne 1 -or (Test-Path -LiteralPath $statePath) -or (Test-Path -LiteralPath $leanRoot) -or (Test-Path -LiteralPath $personalRoot)) { throw 'Uninstall entrypoint misreported its pending physical cleanup.' }
  if (-not (Test-Path -LiteralPath $cleanupEvidence.removal.retainedPaths[0])) { throw 'Pending cleanup metadata did not identify the retained quarantine.' }
  $global:HWOSDeploymentLifecycleCleanupFailure = $false
  $reinstalled = Invoke-FixtureInstall
  if ($reinstalled.result -cne 'PASS') { throw 'Real installer did not recover after committed uninstall with pending cleanup.' }
  & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | Out-Null
  Assert-LifecyclePolicySentinels
  Write-Output 'PASS: unrelated policy value, child key/value, and explicit key/child ACLs retained through install, reinstall, failure rollback, and uninstall'
  if (-not (Test-HWOSLeanGuardRecordedFiles -Root $retained -Files ([pscustomobject]$userHashes))) { throw 'Cleanup failure or reinstall changed per-user stores.' }
  Write-Output 'PASS: actual installer fresh install, failed reinstall with exact tree/receipt/policy rollback, v1 upgrade, bounded uninstall, original policy restore, retained user stores (Administrator/runtime/ACL mocked)'
} finally {
  Remove-Variable -Name HWOSDeploymentLifecycleInjectFailure -Scope Global -ErrorAction SilentlyContinue
  Remove-Variable -Name HWOSDeploymentLifecycleCleanupFailure -Scope Global -ErrorAction SilentlyContinue
  Remove-Item Function:Import-Module -ErrorAction SilentlyContinue
  foreach ($name in @('Test-HWOSLeanGuardAdministrator','Test-HWOSLeanGuardDotNetPrerequisite','Set-HWOSLeanGuardAcls')) { Remove-Item -LiteralPath "Function:global:$name" -ErrorAction SilentlyContinue }
  Microsoft.PowerShell.Core\Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force -Global
  if (Test-Path -LiteralPath $registryPath) { Remove-Item -LiteralPath $registryPath -Recurse -Force }
  $tempPrefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $sandbox.StartsWith($tempPrefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $sandbox) -notlike 'HWOSLeanGuardLifecycle-*') { throw 'Unsafe lifecycle sandbox cleanup target.' }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
  foreach ($name in @('Test-HWOSLeanGuardAdministrator','Test-HWOSLeanGuardDotNetPrerequisite','Set-HWOSLeanGuardAcls')) {
    if ((Get-Command $name).ModuleName -cne 'HWOSLeanGuard.Deployment') { throw 'Lifecycle fixture left a mocked deployment export.' }
  }
}
