$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$serverPath = Join-Path $root 'policy\server-managed-settings.json'
$endpointPath = Join-Path $root 'policy\endpoint-bootstrap-settings.json'
$server = [IO.File]::ReadAllText($serverPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
$endpoint = [IO.File]::ReadAllText($endpointPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
if ($null -ne $server.PSObject.Properties['claudeMd']) { throw 'Server payload must not duplicate organisation instructions; claudeMd is delivered once through Team organisation instructions.' }
if ($server.requiredMinimumVersion -cne '2.1.193' -or $null -ne $server.PSObject.Properties['minimumVersion']) { throw 'Server payload does not use the required version floor key.' }
if ($null -ne $server.PSObject.Properties['forceRemoteSettingsRefresh']) { throw 'Server payload duplicates the endpoint bootstrap.' }
foreach ($flag in @('allowManagedHooksOnly','allowManagedPermissionRulesOnly','allowAllClaudeAiMcps')) {
  if ($server.$flag -ne $true) { throw "Managed flag is not enabled: $flag" }
}
if ($null -ne $server.PSObject.Properties['allowedMcpServers'] -or $null -ne $server.PSObject.Properties['allowManagedMcpServersOnly']) { throw 'Server payload duplicates the organisation connector catalogue.' }
if ($null -ne $server.PSObject.Properties['disableSideloadFlags']) { throw 'disableSideloadFlags must remain an explicit Cowork utility exception.' }
if (@($server.strictPluginOnlyCustomization | Where-Object { $_ -ceq 'hooks' }).Count -ne 1 -or @($server.strictPluginOnlyCustomization | Where-Object { $_ -ceq 'mcp' }).Count -ne 1) { throw 'Managed hook and local MCP source restrictions are incomplete.' }
foreach ($rule in @('Read(//l/**)','Edit(//l/**)')) {
  if (@($server.permissions.deny | Where-Object { $_ -ceq $rule }).Count -ne 1) { throw "Managed L-drive deny rule is missing or duplicated: $rule" }
}
$preToolHook = $server.hooks.PreToolUse[0].hooks[0]
$expectedPreToolArgs = @('-NoLogo','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File','C:\Program Files\ClaudeCode\HWOSLeanGuard\runtime\Invoke-HWOSLeanGuard.ps1','-PolicyPath','C:\Program Files\ClaudeCode\HWOSLeanGuard\policy\guard-policy.json','-AuditDirectory','C:\ProgramData\HenryWilliam\LeanGuard\logs')
if (@($server.hooks.PreToolUse).Count -ne 1 -or @($server.hooks.PreToolUse[0].hooks).Count -ne 1 -or $server.hooks.PreToolUse[0].matcher -cne '*' -or $preToolHook.command -cne 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -or @($preToolHook.args).Count -ne $expectedPreToolArgs.Count -or ((@($preToolHook.args) -join "`0") -cne ($expectedPreToolArgs -join "`0")) -or $preToolHook.timeout -ne 30) { throw 'Managed PreToolUse hook binding changed.' }
$sessionHooks = @($server.hooks.SessionStart)
if ($sessionHooks.Count -ne 1 -or $sessionHooks[0].matcher -cne 'startup|resume|fork|clear|compact' -or @($sessionHooks[0].hooks).Count -ne 1) { throw 'Managed SessionStart hook binding is not singular or does not include the exact fork matcher.' }
$sessionHook = $sessionHooks[0].hooks[0]
if ($sessionHook.type -cne 'command' -or $sessionHook.command -cne 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -or -not (@($sessionHook.args) -ccontains 'C:\Program Files\ClaudeCode\HWOSLeanGuard\runtime\Invoke-HWOSPersonalContextSessionStart.ps1') -or $sessionHook.timeout -ne 2) { throw 'Managed SessionStart hook binding is not exact.' }
$promptHooks = @($server.hooks.UserPromptSubmit)
if ($promptHooks.Count -ne 1 -or @($promptHooks[0].hooks).Count -ne 1) { throw 'Managed UserPromptSubmit hook binding is not singular.' }
$promptHook = $promptHooks[0].hooks[0]
if ($promptHook.type -cne 'command' -or $promptHook.command -cne 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe' -or -not (@($promptHook.args) -ccontains 'C:\Program Files\ClaudeCode\HWOSLeanGuard\runtime\Invoke-HWOSContextBroker.ps1') -or $promptHook.timeout -ne 15) { throw 'Managed UserPromptSubmit hook binding is not exact.' }
if ($null -ne $server.hooks.PSObject.Properties['SessionEnd']) { throw 'Managed settings must not add a SessionEnd hook.' }
$endpointKeys = @($endpoint.PSObject.Properties.Name)
if ($endpoint.forceRemoteSettingsRefresh -ne $true -or @($endpointKeys | Where-Object { $_ -cnotin @('$schema','forceRemoteSettingsRefresh') }).Count -gt 0) { throw 'Endpoint payload is not a minimal remote-refresh bootstrap.' }
Write-Output 'PASS: server-authoritative policy and minimal endpoint bootstrap'
