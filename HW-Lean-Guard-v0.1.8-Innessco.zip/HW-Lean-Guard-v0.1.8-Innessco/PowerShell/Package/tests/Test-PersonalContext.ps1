$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$packageRoot = Split-Path -Parent $PSScriptRoot
$repositoryRoot = Split-Path -Parent $packageRoot
$required = @(
  'global.json',
  'NuGet.Config',
  'personal-context/HW.PersonalContext.sln',
  'personal-context/src/HW.PersonalContext/HW.PersonalContext.csproj',
  'personal-context/tests/HW.PersonalContext.Tests/HW.PersonalContext.Tests.csproj',
  'personal-context/tests/HW.PersonalContext.Tests/packages.lock.json',
  'scripts/Build-PersonalContext.ps1',
  'package/personal-context/HWPersonalContext.dll',
  'package/personal-context/HWPersonalContext.runtimeconfig.json',
  'package/personal-context/contracts/personal-context-packet.schema.json',
  'package/runtime/Invoke-HWOSContextBroker.ps1',
  'package/runtime/Invoke-HWOSPersonalContextSessionStart.ps1'
  'package/tests/Test-PersonalContextHook.ps1'
  'package/tests/Test-PersonalContextBuild.ps1'
  'personal-context/tests/HW.PersonalContext.Tests/StoragePathTests.cs'
  'package/tests/fixtures/personal-context-hooks/LitigationFixture.ps1'
  'package/tests/fixtures/personal-context-hooks/PersonalContextFixture.cmd'
)
$missing = @(
  $required | Where-Object {
    -not (Test-Path -LiteralPath (Join-Path $repositoryRoot $_) -PathType Leaf)
  }
)
if ($missing.Count -gt 0) {
  throw "Personal Context source/integration is incomplete: $($missing -join ', ')"
}

$schemaPath = Join-Path $repositoryRoot 'package\personal-context\contracts\personal-context-packet.schema.json'
$sourceSchemaPath = Join-Path $repositoryRoot 'personal-context\contracts\personal-context-packet.schema.json'
if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($schemaPath)) -cne [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceSchemaPath))) { throw 'Packaged Personal Context schema differs from source.' }
$schema = [IO.File]::ReadAllText($schemaPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
$expectedTypes = @('working_preference','professional_profile','workflow','colleague_preference','tool_or_site_convention','reference_note','temporary_focus')
$expectedRequired = @('id','scope','type','content','confidence','sourceKind','createdAt','updatedAt','briefing','status')
if ($schema.additionalProperties -ne $false -or
    $schema.properties.scope.const -cne 'personal' -or
    $schema.properties.confidence.const -cne 'user_confirmed' -or
    $schema.properties.sourceKind.const -cne 'explicit_save' -or
    ((@($schema.properties.type.enum) -join "`0") -cne ($expectedTypes -join "`0")) -or
    @($expectedRequired | Where-Object { @($schema.required) -cnotcontains $_ }).Count -ne 0) {
  throw 'Personal Context packet schema does not enforce the v0.1.8 personal-only contract.'
}

$hookTest = Join-Path $PSScriptRoot 'Test-PersonalContextHook.ps1'
$start = [Diagnostics.ProcessStartInfo]::new()
$start.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$hookTest`""
$start.UseShellExecute = $false
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$process = [Diagnostics.Process]::Start($start)
$stdout = $process.StandardOutput.ReadToEnd()
$stderr = $process.StandardError.ReadToEnd()
$process.WaitForExit()
if ($process.ExitCode -ne 0) { throw "Personal Context hook test failed: $stderr" }
Write-Output $stdout.TrimEnd()

& (Join-Path $PSScriptRoot 'Test-PersonalContextBuild.ps1')
& (Join-Path $repositoryRoot 'scripts\Build-PersonalContext.ps1') -VerifyPackage
Write-Output 'PASS: Personal Context source, tests, deterministic publish, and package integration'
