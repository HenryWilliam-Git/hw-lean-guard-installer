[CmdletBinding()]
param([string]$EvidencePath, [string]$GuardPath, [string]$NameFilter)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $PSScriptRoot
$guard = Join-Path $package 'runtime\Invoke-HWOSLeanGuard.ps1'
if ($GuardPath) { $guard = [IO.Path]::GetFullPath($GuardPath) }
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardTests-shell-' + [guid]::NewGuid().ToString('N'))
$protected = Join-Path $sandbox 'protected source'
$ordinary = Join-Path $sandbox 'ordinary.txt'
$source = Join-Path $protected 'source.txt'
$outside = Join-Path $sandbox 'outside.txt'
$workbench = Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)) 'Claude Workbench'
$destination = Join-Path $workbench 'synthetic-matter\source.txt'
$policyPath = Join-Path $sandbox 'policy.json'
$audit = Join-Path $sandbox 'audit'
$cases = New-Object 'System.Collections.Generic.List[object]'
function Add-Case {
  param([string]$Name,[string]$Tool,[string]$Command,[string]$Decision,[string]$Rule = '')
  $cases.Add([pscustomobject]@{ Name=$Name; Payload=@{tool_name=$Tool;tool_input=@{command=$Command}}; Decision=$Decision; Rule=$Rule })
}
function Add-NativeCase {
  param([string]$Name,[string]$Tool,[string]$Path,[string]$Decision)
  $cases.Add([pscustomobject]@{ Name=$Name; Payload=@{tool_name=$Tool;tool_input=@{path=$Path}}; Decision=$Decision; Rule='' })
}
[void][IO.Directory]::CreateDirectory($protected)
$policy = Get-Content -LiteralPath (Join-Path $package 'policy\guard-policy.json') -Raw | ConvertFrom-Json
$policy.protectedRoots = @($policy.protectedRoots) + @($protected)
$policy.protectedUncRoots = @('\\synthetic-server\protected share')
[IO.File]::WriteAllText($policyPath,($policy | ConvertTo-Json -Depth 20),[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($ordinary,'Username: synthetic-user',[Text.UTF8Encoding]::new($false))
[IO.File]::WriteAllText($source,'synthetic source',[Text.UTF8Encoding]::new($false))
$psCopy = "Copy-Item -LiteralPath '$source' -Destination '$destination'"
$bashSource = $source.Replace('\','/')
$bashDestination = $destination.Replace('\','/')
$bashOutside = $outside.Replace('\','/')
$bashCopy = "cp '$bashSource' '$bashDestination'"
Add-Case 'heredoc full colon prose is inert' Bash ("cat > '$bashOutside' <<'EOF'`nSources read in full: individual: L: $protected`nEOF") allow
Add-Case 'heredoc no colon control' Bash ("cat > '$bashOutside' <<'EOF'`nSources read in full`nEOF") allow
Add-Case 'quoted PowerShell data is inert' PowerShell ("Set-Content -LiteralPath '$outside' -Value 'full: individual: L: $protected'") allow
Add-Case 'quoted Bash data is inert' Bash ("printf '%s' 'full: L: $protected' > '$bashOutside'") allow
Add-Case 'heredoc followed by protected redirect' Bash ("cat > '$bashOutside' <<'EOF'`ntext`nEOF`nprintf x > '$bashSource'") deny
Add-Case 'heredoc protected destination' Bash ("cat > '$bashSource' <<'EOF'`ntext`nEOF") deny
Add-Case 'quoted heredoc substitution is inert' Bash ("cat > '$bashOutside' <<'EOF'`n`$(printf x > '$bashSource')`nEOF") allow
Add-Case 'unquoted heredoc substitution executes' Bash ("cat > '$bashOutside' <<EOF`n`$(printf x > '$bashSource')`nEOF") deny
Add-Case 'double quoted Bash substitution executes' Bash ('printf "%s" "$(printf x > ''{0}'')"' -f $bashSource) deny
Add-Case 'single quoted Bash substitution inert' Bash ('printf ''$(printf x > "{0}")'' > ''{1}''' -f $bashSource,$bashOutside) allow
Add-Case 'PowerShell substitution executes' PowerShell ('Set-Content ''{0}'' "$(Set-Content ''{1}'' changed)"' -f $outside,$source) deny
Add-Case 'literal PowerShell copy' PowerShell $psCopy allow protected-source-copy-to-claude-workbench
Add-Case 'positional PowerShell copy' PowerShell ("Copy-Item '$source' '$destination'") allow
Add-Case 'PowerShell cp alias copy' PowerShell ("cp '$source' '$destination'") allow
Add-Case 'PowerShell module-qualified copy' PowerShell ("Microsoft.PowerShell.Management\Copy-Item '$source' '$destination'") allow
Add-Case 'Bash cp copy' Bash $bashCopy allow protected-source-copy-to-claude-workbench
Add-Case 'Bash absolute cp copy' Bash ("/usr/bin/cp -- '$bashSource' '$bashDestination'") allow
Add-Case 'Bash cp outside destination' Bash ("cp '$bashSource' '$bashOutside'") deny
Add-Case 'Bash cp protected destination' Bash ("cp '$bashOutside' '$bashSource'") deny
Add-Case 'Bash mv protected source' Bash ("mv '$bashSource' '$bashDestination'") deny
Add-Case 'PowerShell move protected source' PowerShell ("Move-Item '$source' '$destination'") deny
Add-Case 'PowerShell alias move protected source' PowerShell ("mi '$source' '$destination'") deny
Add-Case 'native protected delete precedes ask' Delete '' deny
$cases[$cases.Count-1].Payload.tool_input = @{path=$source}
Add-NativeCase 'native ordinary delete asks' Delete $ordinary ask
Add-NativeCase 'ordinary mcpb delete asks' Delete (Join-Path $sandbox 'package.mcpb') ask
Add-NativeCase 'MCP filesystem protected delete denies' mcp__filesystem__delete_file $source deny
Add-Case 'PowerShell protected delete' PowerShell ("Remove-Item '$source'") deny
Add-Case 'Bash protected delete' Bash ("rm -f '$bashSource'") deny
Add-Case 'PowerShell ordinary delete' PowerShell ("Remove-Item '$ordinary'") ask
Add-Case 'Bash ordinary delete' Bash ("rm -f '$bashOutside'") ask
Add-Case 'copy plus member expression' PowerShell ($psCopy + "; [IO.File]::WriteAllText('$source','changed')") deny
Add-Case 'recognized method ordinary file deletion asks' PowerShell ("[IO.File]::Delete('$ordinary')") ask delete-confirmation-required
Add-Case 'recognized method ordinary directory deletion asks' PowerShell ("[IO.Directory]::Delete('$sandbox\\ordinary-directory')") ask delete-confirmation-required
Add-Case 'recognized method protected deletion denies' PowerShell ("[IO.File]::Delete('$source')") deny protected-path-write-deny
Add-Case 'copy plus ordinary extra statement' PowerShell ($psCopy + '; Write-Output finished') deny
Add-Case 'copy plus extra expression' PowerShell ($psCopy + '; 1+1') deny
Add-Case 'Bash copy plus extra statement' Bash ($bashCopy + '; printf finished') deny
Add-Case 'PowerShell dynamic destination' PowerShell ("Copy-Item -LiteralPath '$source' -Destination `$destination") deny
Add-Case 'Bash dynamic destination' Bash ('cp ''{0}'' "$destination"' -f $bashSource) deny
Add-Case 'PowerShell assigned dynamic source' PowerShell ("`$source = '$source'; Copy-Item `$source '$destination'") deny
Add-Case 'Bash assigned dynamic source' Bash ('source=''{0}''; cp "$source" ''{1}''' -f $bashSource,$bashDestination) deny
Add-Case 'PowerShell unsafe copy flag' PowerShell ($psCopy + ' -PassThru -WhatIf:$false') deny
Add-Case 'Bash unsafe copy flag' Bash ("cp --remove-destination '$bashSource' '$bashDestination'") deny
Add-Case 'Bash xcopy protected source outside' Bash ("xcopy '$bashSource' '$bashOutside'") deny
Add-Case 'robocopy protected source outside' PowerShell ("robocopy '$protected' '$sandbox' source.txt") deny
Add-Case 'robocopy move source denied' PowerShell ("robocopy '$protected' '$workbench' /MOVE") deny
Add-Case 'copy Workbench lookalike denied' PowerShell ("Copy-Item '$source' '$workbench-fake\source.txt'") deny
Add-Case 'copy Workbench traversal escape denied' PowerShell ("Copy-Item '$source' '$workbench\..\source.txt'") deny
Add-Case 'protected path slash and case variants' Bash ("printf x > '$($bashSource.ToUpperInvariant())'") deny
Add-Case 'protected path lookalike allowed' PowerShell ("Set-Content '$protected-other\source.txt' changed") allow
Add-Case 'UNC protected destination' PowerShell "Set-Content '\\synthetic-server\protected share\source.txt' changed" deny
Add-Case 'UNC protected source outside' Bash "cp '//synthetic-server/protected share/source.txt' '$bashOutside'" deny
Add-Case 'L source copy remains prohibited' PowerShell ("Copy-Item 'L:\Matters\source.txt' '$destination'") deny
Add-Case 'Bash powershell literal wrapper copy' Bash ("powershell.exe -NoProfile -Command `"Copy-Item -LiteralPath '$source' -Destination '$destination'`"") allow
Add-Case 'Bash nested shell literal copy' Bash ('bash -c "cp ''{0}'' ''{1}''"' -f $bashSource,$bashDestination) allow
Add-Case 'protected redirect after ordinary statement' PowerShell ("Write-Output full; 'text' > '$source'") deny
Add-Case 'ordinary workflow background data' Bash 'npm test' allow
$cjkName = [string][char]0xD55C + [char]0xAE00
Add-Case 'CJK protected source copy' PowerShell ("Copy-Item '$protected\$cjkName source.txt' '$workbench\$cjkName source.txt'") allow
Add-Case 'all intended PowerShell wrapper flags' Bash ("powershell.exe -NoLogo -NoProfile -NonInteractive -Command `"Copy-Item -LiteralPath '$source' -Destination '$destination'`"") allow
Add-Case 'process substitution protected write' Bash ("cat <(printf x > '$bashSource')") deny
Add-Case 'backtick substitution protected write' Bash ('printf "%s" "`printf x > ''{0}''`"' -f $bashSource) deny
Add-Case 'PowerShell expandable protected path' PowerShell ('Set-Content "{0}\$name" changed' -f $protected) deny
Add-Case 'PowerShell expandable protected source' PowerShell ('Copy-Item "{0}\$name" ''{1}''' -f $protected,$destination) deny
Add-Case 'Bash default expansion protected source' Bash ('cp "${source:-' + $bashSource + '}" ''' + $bashDestination + '''') deny
Add-Case 'command prefix copy' Bash ("command cp '$bashSource' '$bashDestination'") allow
Add-Case 'command prefix outside copy' Bash ("command cp '$bashSource' '$bashOutside'") deny
Add-Case 'env prefix outside copy' Bash ("env cp '$bashSource' '$bashOutside'") deny
Add-Case 'literal expression wrapper protected write' PowerShell ("Invoke-Expression `"Set-Content '$source' changed`"") deny
$encoded = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($psCopy))
Add-Case 'encoded protected copy never admitted' Bash ("powershell.exe -EncodedCommand $encoded") deny
Add-Case 'Bash dynamic wrapper protected copy' Bash ('bash -c "cp ''{0}'' ''$destination''"' -f $bashSource) deny
Add-Case 'MSYS source copy' Bash ("cp '$($bashSource -replace '^([A-Za-z]):/', '/$1/')' '$bashDestination'") allow
Add-Case 'Bash credential source scan' Bash ("cat '$bashSource'") deny credential-bearing-file-read-deny
[IO.File]::WriteAllText($source,'Password: synthetic-password',[Text.UTF8Encoding]::new($false))
Add-Case 'heredoc credential-looking command is inert' Bash ("cat > '$bashOutside' <<'EOF'`ncat '$bashSource'`nEOF") allow
$junction = Join-Path $workbench ('.guard-shell-test-' + [guid]::NewGuid().ToString('N'))
$createdWorkbench = -not (Test-Path -LiteralPath $workbench)
if ($createdWorkbench) { [void][IO.Directory]::CreateDirectory($workbench) }
New-Item -ItemType Junction -Path $junction -Target $sandbox | Out-Null
Add-Case 'Workbench reparse destination denies copy' PowerShell ("Copy-Item '$source' '$junction\copied.txt'") deny
Add-Case 'provider-qualified protected write' PowerShell ("Set-Content 'FileSystem::$source' changed") deny
Add-Case 'extended path protected write' PowerShell ("Set-Content '\\?\$source' changed") deny
Add-Case 'Workbench internal traversal rejected' PowerShell ("Copy-Item '$source' '$workbench\nested\..\source.txt'") deny
Add-Case 'Workbench alternate stream rejected' PowerShell ("Copy-Item '$source' '$destination`:hidden'") deny
Add-Case 'Bash loop protected copy outside' Bash ("for item in one; do cp '$bashSource' '$bashOutside'; done") deny
Add-Case 'Bash conditional protected write' Bash ("if true; then touch '$bashSource'; fi") deny
Add-Case 'Bash time wrapper outside copy' Bash ("time cp '$bashSource' '$bashOutside'") deny
Add-Case 'dotnet protected source copy outside' PowerShell ("[IO.File]::Copy('$source','$outside')") deny
Add-Case 'dotnet protected destination copy' PowerShell ("[IO.File]::Copy('$ordinary','$source')") deny
Add-Case 'expandable heredoc inner single quotes do not suppress substitution' Bash ("cat > '$bashOutside' <<EOF`n'`$(touch '$bashSource')'`nEOF") deny
Add-Case 'expandable heredoc inner double quotes do not suppress substitution' Bash ("cat > '$bashOutside' <<EOF`n`"`$(touch '$bashSource')`"`nEOF") deny
Add-Case 'quoted heredoc inner quotes preserve inert substitution' Bash ("cat > '$bashOutside' <<'EOF'`n'`$(touch '$bashSource')'`nEOF") allow
Add-Case 'expandable heredoc backslash quote prose remains inert' Bash ("cat > '$bashOutside' <<EOF`n\`"; touch '$bashSource'; #`nEOF") allow
Add-Case 'expandable heredoc substitution retains double quoted path' Bash ("cat > '$bashOutside' <<EOF`n`$(touch `"$bashSource`")`nEOF") deny
Add-Case 'expandable heredoc escaped substitution stays inert' Bash ("cat > '$bashOutside' <<EOF`n\`$(touch '$bashSource')`nEOF") allow
Add-Case 'camelcase sendAt remains a delayed send' mcp__outlook__send_internal '' deny delayed-or-background-action
$cases[$cases.Count - 1].Payload.tool_input = @{to=@('lawyer@hwdev.com.au');confirm=$true;sendAt='tomorrow'}
Add-Case 'protected copy denial precedes ordinary delete ask' Bash ("cp '$bashSource' '$bashOutside'; rm '$bashOutside'") deny protected-source-copy-destination-deny
Add-Case 'scheduled native delete denial precedes ask' Delete '' deny delayed-or-background-action
$cases[$cases.Count - 1].Payload.tool_input = @{path=$ordinary;scheduled=$true}
Add-Case 'Bash protected directory relative write' Bash ("cd '$($protected.Replace('\','/'))'; touch relative.txt") deny protected-path-write-deny
Add-Case 'Bash protected directory relative copy outside' Bash ("cd '$($protected.Replace('\','/'))'; cp source.txt '$bashOutside'") deny protected-source-copy-destination-deny
Add-Case 'PowerShell protected directory relative write' PowerShell ("Set-Location '$protected'; Set-Content relative.txt changed") deny protected-path-write-deny
Add-Case 'PowerShell protected directory relative copy outside' PowerShell ("Set-Location '$protected'; Copy-Item source.txt '$outside'") deny protected-source-copy-destination-deny
Add-Case 'Bash ordinary directory relative write' Bash ("cd '$($sandbox.Replace('\','/'))'; touch relative.txt") allow
Add-Case 'quoted directory prose remains inert' Bash ("printf '%s' 'cd $protected'; touch relative.txt") allow
Add-Case 'PowerShell short c wrapper protected write' Bash ("powershell.exe -c `"Set-Content -LiteralPath '$source' -Value x`"") deny protected-path-write-deny
$encodedWrite = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes("Set-Content -LiteralPath '$source' -Value x"))
Add-Case 'PowerShell enc wrapper protected write' Bash ("powershell.exe -enc $encodedWrite") deny protected-path-write-deny
Add-Case 'Bash combined lc wrapper protected write' Bash ("bash -lc `"touch '$bashSource'`"") deny protected-path-write-deny
Add-Case 'env assignment wrapper protected copy outside' Bash ("env FOO=bar cp '$bashSource' '$bashOutside'") deny protected-source-copy-destination-deny
Add-Case 'ordinary PowerShell File wrapper is unchanged' Bash ("powershell.exe -File '$ordinary'") allow
Add-Case 'env assignment wrapper has no protected copy exception' Bash ("env FOO=bar cp '$bashSource' '$bashDestination'") deny protected-source-copy-destination-deny
Add-Case 'Bash combined lc wrapper has no protected copy exception' Bash ("bash -lc `"cp '$bashSource' '$bashDestination'`"") deny protected-source-copy-destination-deny
Add-Case 'PowerShell short c literal copy remains bounded' Bash ("powershell.exe -NoProfile -c `"Copy-Item -LiteralPath '$source' -Destination '$destination'`"") allow protected-source-copy-to-claude-workbench
Add-Case 'later ordinary assignment cannot hide protected variable write' PowerShell ("`$p='$source'; Set-Content -LiteralPath `$p -Value x; `$p='$ordinary'") deny protected-path-write-deny
Add-Case 'reversed protected assignment remains conservative' PowerShell ("`$p='$ordinary'; Set-Content -LiteralPath `$p -Value x; `$p='$source'") deny protected-path-write-deny
Add-Case 'ordinary variable assignment candidates remain allowed' PowerShell ("`$p='$ordinary'; Set-Content -LiteralPath `$p -Value x; `$p='$outside'") allow
$results = New-Object 'System.Collections.Generic.List[object]'
try {
  foreach ($case in $cases) {
    if ($NameFilter -and $case.Name -notmatch $NameFilter) { continue }
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$guard`" -PolicyPath `"$policyPath`" -AuditDirectory `"$audit`""
    $start.UseShellExecute=$false; $start.RedirectStandardInput=$true; $start.RedirectStandardOutput=$true; $start.RedirectStandardError=$true
    $process = [Diagnostics.Process]::Start($start)
    $process.StandardInput.Write(($case.Payload | ConvertTo-Json -Depth 20 -Compress)); $process.StandardInput.Close()
    $stdout=$process.StandardOutput.ReadToEnd(); $stderr=$process.StandardError.ReadToEnd(); $process.WaitForExit()
    $actual = ''; $reason = ''
    if ($stdout.Trim()) { $response=$stdout | ConvertFrom-Json; $actual=$response.hookSpecificOutput.permissionDecision; $reason=$response.hookSpecificOutput.permissionDecisionReason }
    $pass = $process.ExitCode -eq 0 -and -not $stderr.Trim() -and $actual -ceq $case.Decision -and (-not $case.Rule -or $reason.StartsWith('[HW OS Lean Guard:'+$case.Rule+']'))
    $results.Add([pscustomobject]@{Name=$case.Name;Expected=$case.Decision;Actual=$actual;Pass=$pass;ExitCode=$process.ExitCode;Reason=$reason;Error=$stderr})
    if (-not $pass) { Write-Output "FAIL: $($case.Name): expected $($case.Decision), actual $actual, exit $($process.ExitCode), $reason $stderr" }
  }
  $failed = @($results | Where-Object { -not $_.Pass })
  if ($EvidencePath) {
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent ([IO.Path]::GetFullPath($EvidencePath))))
    [IO.File]::WriteAllText([IO.Path]::GetFullPath($EvidencePath),($results | ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false))
  }
  if ($failed.Count) { throw "$($failed.Count)/$($results.Count) shell guard regressions failed." }
  Write-Output "PASS: $($results.Count) shell guard regressions via JSON stdin; no payload executed."
} finally {
  if (Test-Path -LiteralPath $junction) {
    $entry = Get-Item -LiteralPath $junction -Force
    if ($entry.LinkType -ne 'Junction' -or [string]$entry.Target -ne $sandbox -or -not [IO.Path]::GetFullPath($junction).StartsWith([IO.Path]::GetFullPath($workbench) + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Synthetic junction changed before cleanup.' }
    [IO.File]::SetAttributes($junction, ($entry.Attributes -band (-bnot [IO.FileAttributes]::ReadOnly)))
    [IO.Directory]::Delete($junction)
  }
  if ($createdWorkbench -and @(Get-ChildItem -LiteralPath $workbench -Force).Count -eq 0) { [IO.Directory]::Delete($workbench) }
  $resolved = [IO.Path]::GetFullPath($sandbox)
  if ($resolved.StartsWith([IO.Path]::GetFullPath([IO.Path]::GetTempPath()),[StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $resolved).StartsWith('HWOSLeanGuardTests-shell-')) { Remove-Item -LiteralPath $resolved -Recurse -Force }
}
