$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$deployment = Join-Path (Split-Path -Parent $PSScriptRoot) 'deployment'
Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
$deploymentModule = Get-Module 'HWOSLeanGuard.Deployment'
$originalAcls = & $deploymentModule { ${function:Set-HWOSLeanGuardTreeAcls} }
& $deploymentModule { function script:Set-HWOSLeanGuardTreeAcls { param($Root,$Grants,$FailureLabel) } }
$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardV2Tests-' + [Guid]::NewGuid().ToString('N'))))
$registryPath = 'HKCU:\SOFTWARE\HWOSLeanGuardTests\' + [Guid]::NewGuid().ToString('N')
function Write-FixtureFile {
  param([string]$Path, [string]$Text)
  [IO.Directory]::CreateDirectory((Split-Path -Parent $Path)) | Out-Null
  [IO.File]::WriteAllText($Path, $Text, [Text.UTF8Encoding]::new($false))
}
function Assert-Failure {
  param([scriptblock]$Action, [string]$Pattern)
  $failure = $null
  try { & $Action | Out-Null } catch { $failure = $_.Exception.Message }
  if ($null -eq $failure -or $failure -notlike $Pattern) { throw "Expected '$Pattern', received '$failure'." }
}
try {
  $v1Root = Join-Path $sandbox 'v1-state'
  Write-HWOSLeanGuardJson -Path (Join-Path $v1Root 'state\install-state.json') -Value @{ schemaVersion = 'hw-os-lean-guard-state/v1' }
  $v1Checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $v1Root -PolicyRegistryPath $registryPath
  if (-not $v1Checks.Contains('receiptVersionMatch') -or $v1Checks.receiptVersionMatch -ne $false) { throw 'v1 receipts must be explicitly rejected by v2 installed-state detection.' }
  if (-not (Test-HWOSLeanGuardReceiptUpgradePrestate -State ([pscustomobject]@{schemaVersion='hw-os-lean-guard-state/v1'}))) { throw 'v1 upgrade prestate was rejected.' }
  if (-not (Test-HWOSLeanGuardDotNetPrerequisite -RuntimeList @('Microsoft.NETCore.App 8.0.30 [C:\dotnet]') -RuntimeArchitecture 'x64')) { throw 'Exact x64 runtime was rejected.' }
  foreach ($version in @('8.0.29','8.0.31','8.0.300')) {
    if (Test-HWOSLeanGuardDotNetPrerequisite -RuntimeList @("Microsoft.NETCore.App $version [C:\dotnet]") -RuntimeArchitecture 'x64') { throw 'Adjacent runtime was accepted.' }
  }
  if (Test-HWOSLeanGuardDotNetPrerequisite -RuntimeList @('Microsoft.NETCore.App 8.0.30 [C:\dotnet]') -RuntimeArchitecture 'x86') { throw 'x86 runtime was accepted.' }
  if (Test-HWOSLeanGuardDotNetPrerequisite -RuntimeList @('Microsoft.WindowsDesktop.App 8.0.30 [C:\dotnet]') -RuntimeArchitecture 'x64') { throw 'Desktop runtime without NETCore was accepted.' }

  $sourceA = Join-Path $sandbox 'source-a'; $sourceB = Join-Path $sandbox 'source-b'
  $targetA = Join-Path $sandbox 'machine\a'; $targetB = Join-Path $sandbox 'machine\b'
  Write-FixtureFile (Join-Path $sourceA 'new.txt') 'new-a'; Write-FixtureFile (Join-Path $sourceB 'new.txt') 'new-b'
  Write-FixtureFile (Join-Path $targetA 'old.txt') 'old-a'; Write-FixtureFile (Join-Path $targetB 'old.txt') 'old-b'
  $trees = @([pscustomobject]@{sourceRoot=$sourceA;destinationRoot=$targetA;relativeFiles=@()}, [pscustomobject]@{sourceRoot=$sourceB;destinationRoot=$targetB;relativeFiles=@()})
  foreach ($overlap in @($targetA, (Join-Path $targetA 'nested'))) {
    Assert-Failure { Assert-HWOSLeanGuardSafeDestination -Path @($targetA,$overlap) } '*overlap*'
  }
  foreach ($folder in @('UserProfile','Windows','ProgramFiles','CommonApplicationData')) {
    $protectedRoot = [Environment]::GetFolderPath([Environment+SpecialFolder]::$folder)
    Assert-Failure { Assert-HWOSLeanGuardSafeDestination -Path $protectedRoot } '*shared or profile root*'
  }
  Assert-Failure { Invoke-HWOSLeanGuardTwoRootSwap -Trees $trees -AfterSwap { throw 'injected-post-swap' } } 'injected-post-swap'
  if ([IO.File]::ReadAllText((Join-Path $targetA 'old.txt')) -cne 'old-a' -or [IO.File]::ReadAllText((Join-Path $targetB 'old.txt')) -cne 'old-b') { throw 'Both prior trees were not restored.' }
  $module = Get-Module 'HWOSLeanGuard.Deployment'
  $originalCopy = & $module { ${function:Copy-HWOSLeanGuardTree} }
  try {
    & $module { param($Original) $script:TestOriginalCopy = $Original; $script:TestCopyCount = 0; function script:Copy-HWOSLeanGuardTree { param($Tree,$StagingRoot) $script:TestCopyCount++; if ($script:TestCopyCount -eq 2) { throw 'injected-second-stage' }; & $script:TestOriginalCopy -Tree $Tree -StagingRoot $StagingRoot } } $originalCopy
    Assert-Failure { Invoke-HWOSLeanGuardTwoRootSwap -Trees $trees } 'injected-second-stage'
    if ([IO.File]::ReadAllText((Join-Path $targetA 'old.txt')) -cne 'old-a' -or [IO.File]::ReadAllText((Join-Path $targetB 'old.txt')) -cne 'old-b') { throw 'Preparation failure changed an untouched destination.' }
  } finally { & $module { param($Original) Set-Item Function:script:Copy-HWOSLeanGuardTree $Original } $originalCopy }
  Invoke-HWOSLeanGuardTwoRootSwap -Trees $trees
  if ([IO.File]::ReadAllText((Join-Path $targetA 'new.txt')) -cne 'new-a' -or [IO.File]::ReadAllText((Join-Path $targetB 'new.txt')) -cne 'new-b') { throw 'Two-root promotion failed.' }
  if (@(Get-ChildItem -LiteralPath (Split-Path -Parent $targetA) -Force | Where-Object Name -Like '.hwos-*').Count -ne 0) { throw 'Transaction left scratch trees.' }
  $hashes = Get-HWOSLeanGuardFileHashes -Root $targetA
  if (-not (Test-HWOSLeanGuardRecordedFiles -Root $targetA -Files ([pscustomobject]$hashes))) { throw 'Exact recorded files were rejected.' }
  Write-FixtureFile (Join-Path $targetA 'extra.txt') 'unexpected'
  if (Test-HWOSLeanGuardRecordedFiles -Root $targetA -Files ([pscustomobject]$hashes)) { throw 'Unrecorded installed file was accepted.' }
  Remove-Item -LiteralPath (Join-Path $targetA 'extra.txt') -Force
  if (Test-HWOSLeanGuardRecordedFiles -Root $targetA -Files ([pscustomobject]@{'..\source-a\new.txt'=$hashes['new.txt']})) { throw 'Receipt path traversal was accepted.' }
  $junction = Join-Path $sandbox 'junction'
  New-Item -ItemType Junction -Path $junction -Target $targetA | Out-Null
  Assert-Failure { Assert-HWOSLeanGuardSafeDestination -Path (Join-Path $junction 'child') } '*reparse*'
  if (Test-HWOSLeanGuardRecordedFiles -Root $junction -Files ([pscustomobject]$hashes)) { throw 'Reparse installed root was accepted.' }
  Write-Output 'PASS: v2 detection, exact x64 prerequisite, overlap and reparse denial, two-root rollback, preparation failure preservation, extra-file denial'
} finally {
  & $deploymentModule { param($Original) Set-Item Function:script:Set-HWOSLeanGuardTreeAcls $Original } $originalAcls
  if (Test-Path -LiteralPath $registryPath) { Remove-Item -LiteralPath $registryPath -Recurse -Force }
  $tempPrefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $sandbox.StartsWith($tempPrefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $sandbox) -notlike 'HWOSLeanGuardV2Tests-*') { throw 'Unsafe sandbox cleanup target.' }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
