[CmdletBinding()]
param([string]$EvidencePath)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $PSScriptRoot
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardTests-helpers-' + [guid]::NewGuid().ToString('N'))
$runtime = Join-Path $sandbox 'runtime'
[void][IO.Directory]::CreateDirectory($runtime)
$helpers = @('HWOS.ShellAnalysis.ps1', 'HWOS.PowerShellAnalysis.ps1', 'HWOS.BashAnalysis.ps1', 'HWOS.CmdAnalysis.ps1')
$results = New-Object 'System.Collections.Generic.List[object]'
try {
  foreach ($helper in $helpers) {
    foreach ($failure in @('missing', 'malformed')) {
      foreach ($file in @('Invoke-HWOSLeanGuard.ps1') + $helpers) {
        Copy-Item -LiteralPath (Join-Path $package ('runtime\' + $file)) -Destination (Join-Path $runtime $file) -Force
      }
      $target = [IO.Path]::GetFullPath((Join-Path $runtime $helper))
      if (-not $target.StartsWith([IO.Path]::GetFullPath($runtime) + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid helper fixture target.' }
      if ($failure -eq 'missing') { Remove-Item -LiteralPath $target -Force }
      else { [IO.File]::WriteAllText($target, 'function Incomplete {', [Text.UTF8Encoding]::new($false)) }
      $start = [Diagnostics.ProcessStartInfo]::new()
      $start.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
      $entry = Join-Path $runtime 'Invoke-HWOSLeanGuard.ps1'
      $policy = Join-Path $package 'policy\guard-policy.json'
      $audit = Join-Path $sandbox 'audit'
      $start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$entry`" -PolicyPath `"$policy`" -AuditDirectory `"$audit`""
      $start.UseShellExecute = $false
      $start.RedirectStandardInput = $true
      $start.RedirectStandardOutput = $true
      $start.RedirectStandardError = $true
      $process = [Diagnostics.Process]::Start($start)
      $process.StandardInput.Write('{"tool_name":"Bash","tool_input":{"command":"printf synthetic"}}')
      $process.StandardInput.Close()
      $stdout = $process.StandardOutput.ReadToEnd()
      $stderr = $process.StandardError.ReadToEnd()
      $process.WaitForExit()
      $pass = $process.ExitCode -eq 2 -and $stdout.Length -eq 0 -and $stderr.Contains('[HW OS Lean Guard:runtime-helper-unavailable]')
      $results.Add([pscustomobject]@{Helper=$helper;Failure=$failure;Pass=$pass;ExitCode=$process.ExitCode;OutputEmpty=($stdout.Length -eq 0)})
      if (-not $pass) { throw "Helper $helper $failure did not block with exit 2: $($process.ExitCode), $stdout $stderr" }
    }
  }
  if ($EvidencePath) {
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent ([IO.Path]::GetFullPath($EvidencePath))))
    [IO.File]::WriteAllText([IO.Path]::GetFullPath($EvidencePath), ($results | ConvertTo-Json -Depth 5), [Text.UTF8Encoding]::new($false))
  }
  Write-Output 'PASS: 8 missing/malformed runtime helper cases exit 2 without allow output.'
} finally {
  $resolved = [IO.Path]::GetFullPath($sandbox)
  if ($resolved.StartsWith([IO.Path]::GetFullPath([IO.Path]::GetTempPath()), [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $resolved).StartsWith('HWOSLeanGuardTests-helpers-')) {
    Remove-Item -LiteralPath $resolved -Recurse -Force
  }
}
