$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$intune = Join-Path $root 'intune'
foreach ($file in Get-ChildItem -LiteralPath $intune -File | Where-Object { $_.Extension -in @('.ps1','.psm1') }) {
  $tokens = $null; $errors = $null
  [void][Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
  if ($errors.Count -gt 0) { throw "PowerShell parse error in $($file.Name): $($errors[0].Message)" }
}
$metadata = [IO.File]::ReadAllText((Join-Path $intune 'intunewin-metadata.json'), [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
if ($metadata.packageVersion -cne ([IO.File]::ReadAllText((Join-Path $root 'VERSION')).Trim())) { throw 'Intune metadata version differs from package/VERSION.' }
if ($metadata.installBehavior -cne 'system' -or -not $metadata.installCommand.StartsWith('%SystemRoot%\Sysnative\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Intune system/x64 command metadata is incomplete.' }
if (-not $metadata.installCommand.Contains('-ServerManagedPolicyConfirmed')) { throw 'Intune install command does not require the server-policy readiness gate.' }
$installFailure = $null
try {
  & (Join-Path $intune 'Install.ps1') | Out-Null
} catch {
  $installFailure = $_.Exception.Message
}
if ($installFailure -cne 'Intune installation requires confirmation that the server-managed policy is active.') { throw 'Intune installation did not fail closed before server-policy confirmation.' }
$start = [Diagnostics.ProcessStartInfo]::new()
$start.FileName = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$(Join-Path $intune 'Detect.ps1')`""
$start.UseShellExecute = $false
$start.RedirectStandardOutput = $true
$start.RedirectStandardError = $true
$process = [Diagnostics.Process]::Start($start)
$stdout = $process.StandardOutput.ReadToEnd()
$process.WaitForExit()
if ($process.ExitCode -ne 1 -or -not [string]::IsNullOrEmpty($stdout)) { throw 'Intune absent-state detection must exit 1 without stdout.' }
$previewTool = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
$buildScript = Join-Path $intune 'Build-HWOSLeanGuardIntuneWin.ps1'
$buildCommand = Get-Command -Name $buildScript -CommandType ExternalScript
if ($buildCommand.Parameters.ContainsKey('ExpectedToolSha256')) { throw 'The caller must not be able to select the approved preparation-tool hash.' }
Import-Module (Join-Path $intune 'HWOSLeanGuard.IntuneTrust.psm1') -Force
$approvedEvidence = @{
  ToolSha256 = 'c1ba45b5cb939e84af064bb7ff4b38fb3dfe33c8dc1078fd9b157672eae671f6'
  SignatureStatus = 'Valid'
  SignerSubject = 'CN=Microsoft Corporation, O=Microsoft Corporation, L=Redmond, S=Washington, C=US'
  SignerThumbprint = '3f56a45111684d454e231cfdc4da5c8d370f9816'
}
$approvedResult = Assert-HWOSApprovedIntunePreparationToolEvidence @approvedEvidence
if ($approvedResult.toolSha256 -cne $approvedEvidence.ToolSha256 -or $approvedResult.toolSignerThumbprint -cne $approvedEvidence.SignerThumbprint) { throw 'Approved Intune preparation-tool evidence was not preserved.' }
function Assert-IntuneTrustFailure {
  param([hashtable]$Evidence, [string]$ExpectedMessage)
  $failure = $null
  try {
    Assert-HWOSApprovedIntunePreparationToolEvidence @Evidence | Out-Null
  } catch {
    $failure = $_.Exception.Message
  }
  if ($failure -cne $ExpectedMessage) { throw "Unexpected Intune trust result. Expected '$ExpectedMessage', got '$failure'." }
}
$wrongHash = @{} + $approvedEvidence
$wrongHash.ToolSha256 = ('0' * 64)
Assert-IntuneTrustFailure $wrongHash 'IntuneWinAppUtil.exe hash does not match the package-approved value.'
$invalidSignature = @{} + $approvedEvidence
$invalidSignature.SignatureStatus = 'HashMismatch'
Assert-IntuneTrustFailure $invalidSignature 'IntuneWinAppUtil.exe does not have a valid Authenticode signature.'
$wrongSubject = @{} + $approvedEvidence
$wrongSubject.SignerSubject = 'CN=Microsoft Windows, O=Microsoft Corporation, L=Redmond, S=Washington, C=US'
Assert-IntuneTrustFailure $wrongSubject 'IntuneWinAppUtil.exe does not match the package-approved Microsoft signer.'
$wrongThumbprint = @{} + $approvedEvidence
$wrongThumbprint.SignerThumbprint = ('0' * 40)
Assert-IntuneTrustFailure $wrongThumbprint 'IntuneWinAppUtil.exe signer thumbprint does not match the package-approved certificate.'
$buildFailure = $null
try {
  & $buildScript -IntuneWinAppUtilPath $previewTool | Out-Null
} catch {
  $buildFailure = $_.Exception.Message
}
if ($buildFailure -cne 'IntuneWinAppUtil.exe hash does not match the package-approved value.') { throw 'Intune build did not reject a valid Microsoft-signed executable with the wrong package-approved hash.' }
Write-Output 'PASS: Intune entrypoints and detection semantics'
