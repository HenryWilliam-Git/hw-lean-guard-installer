@echo off
set "HWOS_TEST_COMMAND=retrieve"
if /I "%~1"=="briefing" set "HWOS_TEST_COMMAND=briefing"
if /I not "%HWOS_TEST_COMMAND%"=="briefing" more >nul
if "%HWOS_PERSONAL_CONTEXT_TEST_MODE%"=="empty" echo {"schemaVersion":"hw-personal-context-cli/v1","command":"%HWOS_TEST_COMMAND%","ok":true,"data":{"context":""}}& exit /b 0
if "%HWOS_PERSONAL_CONTEXT_TEST_MODE%"=="malformed" echo not-json& exit /b 0
if "%HWOS_PERSONAL_CONTEXT_TEST_MODE%"=="wrong-envelope" echo {"schemaVersion":"wrong","command":"retrieve","ok":true,"data":{"context":"PERSONAL"}}& exit /b 0
if "%HWOS_PERSONAL_CONTEXT_TEST_MODE%"=="failure" exit /b 7
if "%HWOS_PERSONAL_CONTEXT_TEST_MODE%"=="timeout" %SystemRoot%\System32\ping.exe -n 3 127.0.0.1 >nul& exit /b 0
echo {"schemaVersion":"hw-personal-context-cli/v1","command":"%HWOS_TEST_COMMAND%","ok":true,"data":{"context":"PERSONAL"}}
exit /b 0
