$null = [Console]::In.ReadToEnd()
switch ([Environment]::GetEnvironmentVariable('HWOS_LITIGATION_CONTEXT_TEST_MODE')) {
  'empty' { exit 0 }
  'malformed' { [Console]::Out.Write('not-json'); exit 0 }
  'timeout' { Start-Sleep -Milliseconds 3200; exit 0 }
  default { [Console]::Out.Write('{"hookSpecificOutput":{"hookEventName":"UserPromptSubmit","additionalContext":"LITIGATION"}}'); exit 0 }
}
