$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$repositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$scratchRoot = Join-Path ([IO.Path]::GetTempPath()) ("hwpc-build-test-{0}" -f [Guid]::NewGuid().ToString('N'))
$powerShell = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

try {
  New-Item -ItemType Directory -Path $scratchRoot -Force | Out-Null
  foreach ($relative in @('global.json', 'NuGet.Config', 'scripts\Build-PersonalContext.ps1')) {
    $destination = Join-Path $scratchRoot $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $repositoryRoot $relative) -Destination $destination
  }
  $sourceRoot = Join-Path $repositoryRoot 'personal-context'
  Get-ChildItem -LiteralPath $sourceRoot -File -Recurse | Where-Object {
    $_.FullName -notmatch '[\\/](bin|obj)[\\/]'
  } | ForEach-Object {
    $relative = $_.FullName.Substring($repositoryRoot.Length + 1)
    $destination = Join-Path $scratchRoot $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
    Copy-Item -LiteralPath $_.FullName -Destination $destination
  }
  $packageRoot = Join-Path $scratchRoot 'package\personal-context'
  New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null
  $marker = Join-Path $packageRoot 'reviewed-package.marker'
  [IO.File]::WriteAllText($marker, 'Synthetic reviewed package bytes.', [Text.UTF8Encoding]::new($false))
  $beforeBytes = [Convert]::ToBase64String([IO.File]::ReadAllBytes($marker))

  $start = [Diagnostics.ProcessStartInfo]::new()
  $start.FileName = $powerShell
  $start.Arguments = "-NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File `"$(Join-Path $scratchRoot 'scripts\Build-PersonalContext.ps1')`""
  $start.WorkingDirectory = $scratchRoot
  $start.UseShellExecute = $false
  $start.CreateNoWindow = $true
  $start.RedirectStandardOutput = $true
  $start.RedirectStandardError = $true
  $process = [Diagnostics.Process]::Start($start)
  try {
    $stdoutTask = $process.StandardOutput.ReadToEndAsync()
    $stderrTask = $process.StandardError.ReadToEndAsync()
    $process.WaitForExit()
    $stdout = $stdoutTask.GetAwaiter().GetResult()
    $stderr = $stderrTask.GetAwaiter().GetResult()
    if ($process.ExitCode -ne 0) { throw "Default build failed with exit $($process.ExitCode): $stdout $stderr" }
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Default build replaced packaged bytes without -Apply.' }
    if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($marker)) -cne $beforeBytes -or
        @(Get-ChildItem -LiteralPath $packageRoot -File -Recurse).Count -ne 1) {
      throw 'Default build changed packaged bytes without -Apply.'
    }
    if (-not [string]::IsNullOrWhiteSpace($stderr)) { throw "Default build wrote stderr: $stderr" }
    Write-Output 'PASS: default build preserves packaged bytes without -Apply; synthetic root only'
  } finally { $process.Dispose() }
} finally {
  $resolvedScratch = [IO.Path]::GetFullPath($scratchRoot)
  $resolvedTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $resolvedScratch.StartsWith($resolvedTemp, [StringComparison]::OrdinalIgnoreCase) -or
      [IO.Path]::GetFileName($resolvedScratch) -notlike 'hwpc-build-test-*') {
    throw 'Refusing to remove an unexpected build-test directory.'
  }
  if (Test-Path -LiteralPath $resolvedScratch) { Remove-Item -LiteralPath $resolvedScratch -Recurse -Force }
}
