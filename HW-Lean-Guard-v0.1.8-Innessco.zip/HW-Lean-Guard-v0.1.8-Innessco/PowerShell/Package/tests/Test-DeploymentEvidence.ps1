param([Parameter(Mandatory = $true)][object]$Evidence)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$schema = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $PSScriptRoot) 'contracts\evidence.schema.json')) | ConvertFrom-Json -ErrorAction Stop
$actualNames = @($Evidence.PSObject.Properties.Name)
foreach ($required in $schema.required) { if ($actualNames -cnotcontains $required) { throw "Evidence required field missing: $required" } }
if ($actualNames -cnotcontains 'removal') {
  foreach ($required in $schema.allOf[0].then.required) { if ($actualNames -cnotcontains $required) { throw "Install evidence required field missing: $required" } }
}
foreach ($property in $Evidence.PSObject.Properties) {
  if (@($schema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Evidence has an uncontracted field: $($property.Name)" }
  $rule = $schema.properties.($property.Name)
  $constraints = @($rule.PSObject.Properties.Name)
  if ($constraints -contains 'const' -and $property.Value -cne $rule.const) { throw "Evidence constant mismatch: $($property.Name)" }
  if ($constraints -contains 'enum' -and $rule.enum -cnotcontains $property.Value) { throw "Evidence enum mismatch: $($property.Name)" }
  if ($constraints -contains 'pattern' -and ($property.Value -isnot [string] -or $property.Value -cnotmatch $rule.pattern)) { throw "Evidence pattern mismatch: $($property.Name)" }
  if ($constraints -contains 'format') {
    $parsedDate = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse([string]$property.Value, [ref]$parsedDate)) { throw 'Evidence timestamp is invalid.' }
  }
}
$checkProperties = @($Evidence.checks.PSObject.Properties)
if ($checkProperties.Count -lt $schema.properties.checks.minProperties) { throw 'Evidence checks are empty.' }
foreach ($check in $checkProperties) { if ($check.Value -isnot [bool]) { throw "Evidence check is not boolean: $($check.Name)" } }
if ($Evidence.result -ceq 'PASS' -and @($checkProperties | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'PASS evidence contains a failed check.' }
if ($actualNames -ccontains 'priorInstallation' -and $null -ne $Evidence.priorInstallation) {
  $prior = $Evidence.priorInstallation
  $priorSchema = $schema.properties.priorInstallation
  foreach ($required in $priorSchema.required) { if (@($prior.PSObject.Properties.Name) -cnotcontains $required) { throw "Prior installation required field missing: $required" } }
  foreach ($property in $prior.PSObject.Properties) { if (@($priorSchema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Prior installation has an uncontracted field: $($property.Name)" } }
  if ($prior.receiptSha256 -isnot [string] -or $prior.receiptSha256 -cnotmatch $priorSchema.properties.receiptSha256.pattern -or $prior.packageVersion -isnot [string] -or $prior.packageVersion -cnotmatch $priorSchema.properties.packageVersion.pattern -or $priorSchema.properties.checkStatus.enum -cnotcontains $prior.checkStatus) { throw 'Prior installation provenance is invalid.' }
  if (@($prior.checks.PSObject.Properties).Count -lt 1) { throw 'Prior installation checks are missing.' }
  foreach ($check in $prior.checks.PSObject.Properties) { if ($check.Value -isnot [bool]) { throw 'Prior installation check is not boolean.' } }
}
if ($actualNames -contains 'removal') {
  $removalSchema = $schema.properties.removal
  foreach ($required in $removalSchema.required) { if (@($Evidence.removal.PSObject.Properties.Name) -cnotcontains $required) { throw "Removal evidence required field missing: $required" } }
  foreach ($property in $Evidence.removal.PSObject.Properties) { if (@($removalSchema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Removal evidence has an uncontracted field: $($property.Name)" } }
  if ($removalSchema.properties.status.enum -cnotcontains $Evidence.removal.status -or $Evidence.removal.cleanupPending -isnot [bool] -or $Evidence.removal.retainedPaths -isnot [array] -or [string]::IsNullOrWhiteSpace($Evidence.removal.recoveryJournalPath)) { throw 'Removal evidence is invalid.' }
  foreach ($path in $Evidence.removal.retainedPaths) { if ($path -isnot [string] -or [string]::IsNullOrWhiteSpace($path)) { throw 'Retained quarantine path is invalid.' } }
  if ($Evidence.removal.cleanupPending -ne ($Evidence.removal.status -ceq 'removed-cleanup-pending') -or ($Evidence.result -ceq 'PASS' -and ($Evidence.removal.cleanupPending -or $Evidence.removal.retainedPaths.Count -gt 0))) { throw 'Removal evidence contradicts its cleanup state.' }
}
