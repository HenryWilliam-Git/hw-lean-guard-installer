$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$instructions = [IO.File]::ReadAllText((Join-Path $root 'policy\org-instructions.md'), [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
if ($instructions.Length -gt 3000) { throw "Organisation instructions exceed 3000 characters: $($instructions.Length)." }
foreach ($required in @(
  'Copies into approved Claude Workbench roots are allowed; source mutation never is',
  'Confirm each deletion once; no standing approval',
  'No consequential external actions',
  'Unsent Outlook drafts are allowed, including externally addressed drafts',
  'Only the approved Outlook/Teams send capability may send synchronously',
  'Preserve source wording exactly'
)) {
  if (-not $instructions.Contains($required)) { throw "Required instruction text is missing: $required" }
}
$filesSection = [regex]::Match($instructions, '(?ms)^Files\s+(?<body>.*?)(?=^Communications\s*$)')
if (-not $filesSection.Success -or $filesSection.Groups['body'].Value -notmatch '(?i)direct\s+Claude\s+access\s+to\s+L:\\\s+is\s+prohibited') {
  throw 'Organisation instructions do not enforce the reviewed L-drive prohibition.'
}
$readme = [IO.File]::ReadAllText((Join-Path $root 'README.md'), [Text.Encoding]::UTF8)
if (-not $readme.Contains('`disableSideloadFlags` is deliberately absent')) { throw 'Cowork utility exception is not explicit.' }
foreach ($required in @(
  'Server-managed settings is the single policy authority',
  'without duplicating that connector catalogue in JSON',
  'user and project MCP registrations do not load',
  'Cowork''s internally supplied session configuration remains the explicit `--mcp-config` exception'
)) {
  if (-not $readme.Contains($required)) { throw "Managed-settings contract is not explicit: $required" }
}
$deploymentText = @(Get-ChildItem -LiteralPath (Join-Path $root 'deployment') -File -Filter '*.ps1' | ForEach-Object { [IO.File]::ReadAllText($_.FullName) }) -join "`n"
if ($deploymentText -match '(?i)icacls[^\r\n]+L:\\') { throw 'Deployment package attempts to change the L-drive ACL.' }
Write-Output 'PASS: contract and explicit exceptions'
