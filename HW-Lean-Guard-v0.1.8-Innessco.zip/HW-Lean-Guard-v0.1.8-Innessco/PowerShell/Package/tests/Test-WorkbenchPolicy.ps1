$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$root = Split-Path -Parent $PSScriptRoot
$configurator = Join-Path $root 'deployment\Configure-HWOSClaudeWorkbench.ps1'
if (-not (Test-Path -LiteralPath $configurator -PathType Leaf)) { throw 'Workbench policy configurator is missing.' }
$tokens = $null
$errors = $null
[void][Management.Automation.Language.Parser]::ParseFile($configurator, [ref]$tokens, [ref]$errors)
if ($errors.Count -gt 0) { throw "PowerShell parse error in Workbench configurator: $($errors[0].Message)" }

$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardWorkbenchTests-" + [Guid]::NewGuid().ToString('N'))))
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
if (-not $sandbox.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Workbench test sandbox escaped the temporary directory.' }
$desktop = Join-Path $sandbox 'Desktop Known Folder'
$userState = Join-Path $sandbox 'User State'
$registryTestRoot = 'HKCU:\SOFTWARE\HWOSLeanGuardWorkbenchTests'
$registryBase = Join-Path $registryTestRoot ([Guid]::NewGuid().ToString('N'))
$userPolicy = Join-Path $registryBase 'User'
$machinePolicy = Join-Path $registryBase 'Machine'
$workbench = Join-Path $desktop 'Claude Workbench'
$priorValue = 'C:\Previous Claude Workspace'
$removalPolicy = Join-Path $registryBase 'RemovalFailure'
$removalState = Join-Path $sandbox 'Removal Failure State'

function Assert-UnrelatedPolicyPreserved {
  param([string]$Stage)
  $preservedKey = Get-Item -LiteralPath $userPolicy
  $preservedChild = Join-Path $userPolicy 'UnrelatedChild'
  if ($preservedKey.GetValue('unrelatedPolicy') -cne 'retain-value' -or -not (Test-Path -LiteralPath $preservedChild)) { throw "Workbench $Stage replaced unrelated policy values or subkeys." }
  if ((Get-Item -LiteralPath $preservedChild).GetValue('childPolicy') -cne 'retain-child') { throw "Workbench $Stage changed an unrelated subkey value." }
  if ($preservedKey.GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All) -cne $policySddl -or (Get-Item -LiteralPath $preservedChild).GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All) -cne $childPolicySddl) { throw "Workbench $Stage changed existing policy ACLs." }
}

try {
  [IO.Directory]::CreateDirectory($desktop) | Out-Null
  $preview = & $configurator -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($preview.applyRequested -ne $false -or $preview.restoreRequested -ne $false -or $preview.workbenchRoot -cne $workbench -or $preview.policyValueKind -cne 'MultiString' -or $preview.machinePolicyConflict -ne $false) {
    throw 'Workbench policy preview contract is invalid.'
  }
  if (Test-Path -LiteralPath $workbench) { throw 'Workbench preview created the folder.' }
  if (Test-Path -LiteralPath $userPolicy) { throw 'Workbench preview created the user policy.' }

  New-Item -Path $machinePolicy -Force | Out-Null
  New-ItemProperty -LiteralPath $machinePolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@('C:\Conflicting Machine Workspace')) -PropertyType MultiString -Force | Out-Null
  $conflictPreview = & $configurator -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($conflictPreview.machinePolicyConflict -ne $true) { throw 'Conflicting machine policy was not detected.' }
  $conflictFailure = $null
  try {
    & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch {
    $conflictFailure = $_.Exception.Message
  }
  if ($conflictFailure -cne 'A conflicting machine-level allowedWorkspaceFolders policy overrides the current-user policy.') {
    throw 'Workbench configurator did not fail closed on a conflicting machine policy.'
  }
  Remove-Item -LiteralPath $machinePolicy -Recurse -Force

  New-Item -Path $userPolicy -Force | Out-Null
  New-ItemProperty -LiteralPath $userPolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@($priorValue)) -PropertyType MultiString -Force | Out-Null
  New-ItemProperty -LiteralPath $userPolicy -Name 'unrelatedPolicy' -Value 'retain-value' -PropertyType String -Force | Out-Null
  $unrelatedChild = Join-Path $userPolicy 'UnrelatedChild'
  New-Item -Path $unrelatedChild -Force | Out-Null
  New-ItemProperty -LiteralPath $unrelatedChild -Name 'childPolicy' -Value 'retain-child' -PropertyType String -Force | Out-Null
  $fixtureAclKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($userPolicy.Substring('HKCU:\'.Length), $true)
  try {
    $fixtureAcl = $fixtureAclKey.GetAccessControl()
    [void]$fixtureAcl.AddAccessRule([Security.AccessControl.RegistryAccessRule]::new([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.AccessControl.RegistryRights]::ReadKey, [Security.AccessControl.AccessControlType]::Allow))
    $fixtureAclKey.SetAccessControl($fixtureAcl)
  } finally { $fixtureAclKey.Dispose() }
  $policySddl = (Get-Item -LiteralPath $userPolicy).GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All)
  $childPolicySddl = (Get-Item -LiteralPath $unrelatedChild).GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::All)
  $applyResult = & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($applyResult.result -cne 'PASS' -or $applyResult.policyExact -ne $true -or $applyResult.workbenchExists -ne $true -or $applyResult.policyValueKind -cne 'MultiString' -or $applyResult.registryWritePerformed -ne $true) {
    throw 'Workbench policy application did not pass exact readback.'
  }
  $key = Get-Item -LiteralPath $userPolicy
  $value = [string[]]@($key.GetValue('allowedWorkspaceFolders', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames))
  if ($key.GetValueKind('allowedWorkspaceFolders').ToString() -cne 'MultiString' -or $value.Count -ne 1 -or $value[0] -cne $workbench) {
    throw 'Workbench user policy registry readback is not exact.'
  }
  Assert-UnrelatedPolicyPreserved -Stage 'Apply'

  $statePath = Join-Path $userState 'state\workbench-policy-prestate.json'
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Workbench policy prestate was not written.' }
  $prestateHash = (Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant()
  New-ItemProperty -LiteralPath $userPolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@('C:\Drifted Workspace')) -PropertyType MultiString -Force | Out-Null
  & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  if ((Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $prestateHash) { throw 'Repeat apply overwrote the original Workbench policy prestate.' }

  $readOnlyCases = @(
    @{ Name = 'exact'; Kind = 'MultiString'; Values = @($workbench); Succeeds = $true },
    @{ Name = 'wrong value'; Kind = 'MultiString'; Values = @($priorValue); Succeeds = $false },
    @{ Name = 'wrong type'; Kind = 'String'; Values = @($workbench); Succeeds = $false },
    @{ Name = 'multiple values'; Kind = 'MultiString'; Values = @($workbench, $priorValue); Succeeds = $false },
    @{ Name = 'wrong case'; Kind = 'MultiString'; Values = @($workbench.ToUpperInvariant()); Succeeds = $false },
    @{ Name = 'machine conflict'; Kind = 'MultiString'; Values = @($workbench); Succeeds = $false }
  )
  $readOnlyFailures = @()
  foreach ($readOnlyCase in $readOnlyCases) {
    $fixtureValue = if ($readOnlyCase.Kind -ceq 'String') { [string]$readOnlyCase.Values[0] } else { [string[]]$readOnlyCase.Values }
    New-ItemProperty -LiteralPath $userPolicy -Name 'allowedWorkspaceFolders' -Value $fixtureValue -PropertyType $readOnlyCase.Kind -Force | Out-Null
    if ($readOnlyCase.Name -ceq 'machine conflict') {
      New-Item -Path $machinePolicy -Force | Out-Null
      New-ItemProperty -LiteralPath $machinePolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@($priorValue)) -PropertyType MultiString -Force | Out-Null
    }
    if ($readOnlyCase.Succeeds) { [IO.Directory]::Delete($workbench) }
    $readOnlyRights = [Security.AccessControl.RegistryRights]::ReadPermissions -bor [Security.AccessControl.RegistryRights]::ChangePermissions
    $readOnlyKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($userPolicy.Substring('HKCU:\'.Length), [Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree, $readOnlyRights)
    if ($null -eq $readOnlyKey) { throw 'Read-only policy test could not open its fixture key.' }
    $blockedReadOnlyAcl = $readOnlyKey.GetAccessControl()
    $deniedReadOnlyRights = [Security.AccessControl.RegistryRights]::SetValue -bor [Security.AccessControl.RegistryRights]::Delete
    $denyReadOnlyWrite = [Security.AccessControl.RegistryAccessRule]::new([Security.Principal.WindowsIdentity]::GetCurrent().User, $deniedReadOnlyRights, [Security.AccessControl.InheritanceFlags]::None, [Security.AccessControl.PropagationFlags]::None, [Security.AccessControl.AccessControlType]::Deny)
    [void]$blockedReadOnlyAcl.AddAccessRule($denyReadOnlyWrite)
    try {
      $readOnlyKey.SetAccessControl($blockedReadOnlyAcl)
      $blockedSddl = $readOnlyKey.GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access)
      $readOnlyFailure = $null
      $readOnlyResult = $null
      try {
        $readOnlyResult = & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
      } catch { $readOnlyFailure = $_.Exception.Message }
      $readOnlyReadback = Get-Item -LiteralPath $userPolicy
      $readOnlyValues = @($readOnlyReadback.GetValue('allowedWorkspaceFolders', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames))
      if ($readOnlyReadback.GetValueKind('allowedWorkspaceFolders').ToString() -cne $readOnlyCase.Kind -or ($readOnlyValues | ConvertTo-Json -Compress) -cne ($readOnlyCase.Values | ConvertTo-Json -Compress)) { throw 'Read-only Apply changed the fixture policy.' }
      if ($readOnlyKey.GetAccessControl().GetSecurityDescriptorSddlForm([Security.AccessControl.AccessControlSections]::Access) -cne $blockedSddl) { throw 'Read-only Apply changed the fixture ACL.' }
      if ((Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $prestateHash) { throw 'Read-only Apply overwrote the original prestate.' }
      if ($readOnlyCase.Succeeds) {
        if ($null -ne $readOnlyFailure) { $readOnlyFailures += "Exact read-only policy failed: $readOnlyFailure" }
        elseif ($readOnlyResult.result -cne 'PASS' -or $readOnlyResult.policyExact -ne $true -or $readOnlyResult.workbenchExists -ne $true -or $readOnlyResult.registryWritePerformed -ne $false -or -not (Test-Path -LiteralPath $workbench -PathType Container)) { throw 'Exact read-only Apply skipped folder/readback validation or reported a registry write.' }
      } elseif ([string]::IsNullOrWhiteSpace($readOnlyFailure)) {
        $readOnlyFailures += "Read-only $($readOnlyCase.Name) was accepted."
      } elseif ($readOnlyCase.Name -ceq 'machine conflict' -and $readOnlyFailure -cne 'A conflicting machine-level allowedWorkspaceFolders policy overrides the current-user policy.') {
        throw 'Exact read-only policy bypassed the machine policy conflict gate.'
      }
    } finally {
      $restoredReadOnlyAcl = $readOnlyKey.GetAccessControl()
      [void]$restoredReadOnlyAcl.RemoveAccessRuleSpecific($denyReadOnlyWrite)
      $readOnlyKey.SetAccessControl($restoredReadOnlyAcl)
      $readOnlyKey.Dispose()
    }
  }
  Remove-Item -LiteralPath $machinePolicy -Recurse -Force
  if ($readOnlyFailures.Count -gt 0) { throw ($readOnlyFailures -join '; ') }
  Write-Output 'PASS: 6 read-only policy cases retain exact type/value/ACL/prestate, folder validation, and machine conflict rejection'

  $prestateBytes = [IO.File]::ReadAllBytes($statePath)
  [IO.File]::WriteAllText($statePath, '{"tampered":true}', [Text.UTF8Encoding]::new($false))
  $tamperFailure = $null
  try {
    & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $applyResult.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch { $tamperFailure = $_.Exception.Message }
  if ($tamperFailure -cne 'Workbench policy prestate SHA-256 mismatch.') { throw 'Workbench policy restore accepted a tampered prestate.' }
  [IO.File]::WriteAllBytes($statePath, $prestateBytes)
  $restoreResult = & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $applyResult.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  $restoredKey = Get-Item -LiteralPath $userPolicy
  $restoredValue = [string[]]@($restoredKey.GetValue('allowedWorkspaceFolders', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames))
  if ($restoreResult.result -cne 'PASS' -or $restoreResult.workbenchRetained -ne $true -or $restoredKey.GetValueKind('allowedWorkspaceFolders').ToString() -cne 'MultiString' -or $restoredValue.Count -ne 1 -or $restoredValue[0] -cne $priorValue) {
    throw 'Workbench policy restore did not preserve the folder and restore the prior user policy.'
  }
  Assert-UnrelatedPolicyPreserved -Stage 'Restore'
  Write-Output 'PASS: Apply and authenticated Restore preserve unrelated values, subkeys, and policy ACLs'

  New-Item -Path $removalPolicy -Force | Out-Null
  $removalApply = & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $removalPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $removalState | ConvertFrom-Json -ErrorAction Stop
  $removalSubKey = $removalPolicy.Substring('HKCU:\'.Length)
  $aclRights = [Security.AccessControl.RegistryRights]::ReadPermissions -bor [Security.AccessControl.RegistryRights]::ChangePermissions
  $removalKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($removalSubKey, [Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree, $aclRights)
  if ($null -eq $removalKey) { throw 'Removal-failure test could not open its policy key.' }
  $blockedRemovalAcl = $removalKey.GetAccessControl()
  $denySetValue = [Security.AccessControl.RegistryAccessRule]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent().User,
    [Security.AccessControl.RegistryRights]::SetValue,
    [Security.AccessControl.InheritanceFlags]::None,
    [Security.AccessControl.PropagationFlags]::None,
    [Security.AccessControl.AccessControlType]::Deny
  )
  [void]$blockedRemovalAcl.AddAccessRule($denySetValue)
  $removalKey.SetAccessControl($blockedRemovalAcl)
  $removalFailure = $null
  try {
    & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $removalApply.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $removalPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $removalState | Out-Null
  } catch {
    $removalFailure = $_.Exception.Message
  } finally {
    $restoredRemovalAcl = $removalKey.GetAccessControl()
    [void]$restoredRemovalAcl.RemoveAccessRuleSpecific($denySetValue)
    $removalKey.SetAccessControl($restoredRemovalAcl)
    $removalKey.Dispose()
  }
  if ([string]::IsNullOrWhiteSpace($removalFailure)) { throw 'Workbench policy restore swallowed a registry removal failure.' }

  $relativeFailure = $null
  try {
    & $configurator -DesktopPath 'relative\Desktop' -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch {
    $relativeFailure = $_.Exception.Message
  }
  if ($relativeFailure -cne 'The signed-in user Desktop Known Folder must resolve to a non-empty rooted path.') {
    throw 'Workbench configurator accepted a relative Desktop path.'
  }

  $boundaryPolicy = Join-Path $registryBase 'ProtectedRootUser'
  $boundaryMachinePolicy = Join-Path $registryBase 'ProtectedRootMachine'
  $boundaryState = Join-Path $sandbox 'Protected Root State'
  New-Item -Path $boundaryPolicy -Force | Out-Null
  New-ItemProperty -LiteralPath $boundaryPolicy -Name 'allowedWorkspaceFolders' -Value $priorValue -PropertyType String -Force | Out-Null
  New-Item -Path $boundaryMachinePolicy -Force | Out-Null
  # This conflict prevents an unfixed Apply from reaching any real protected folder.
  New-ItemProperty -LiteralPath $boundaryMachinePolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@('C:\Conflicting Machine Workspace')) -PropertyType MultiString -Force | Out-Null
  $protectedDesktops = @(
    'L:\LeanGuard-Test-Desktop',
    'C:\Program Files\ClaudeCode\HWOSLeanGuard\Desktop',
    'C:\Program Files\HenryWilliam\PersonalContext',
    'c:\program files\henrywilliam\personalcontext',
    'C:\PROGRAM FILES\HENRYWILLIAM\PERSONALCONTEXT\Nested\Desktop',
    'C:\Program Files\HenryWilliam\PersonalContext\Nested\..\Desktop',
    'C:/Program Files/HenryWilliam/PersonalContext/Nested/Desktop',
    'C:\Program Files\HenryWilliam\PersonalContext\'
  )
  $boundaryFailures = @()
  foreach ($protectedDesktop in $protectedDesktops) {
    foreach ($applyBoundary in @($false, $true)) {
      $protectedFailure = $null
      try {
        & $configurator -Apply:$applyBoundary -Confirm:$false -DesktopPath $protectedDesktop -PolicyRegistryPath $boundaryPolicy -MachinePolicyRegistryPath $boundaryMachinePolicy -UserStateRoot $boundaryState | Out-Null
      } catch { $protectedFailure = $_.Exception.Message }
      $mode = if ($applyBoundary) { 'Apply' } else { 'Preview' }
      if ($protectedFailure -cne 'The resolved Claude Workbench path intersects a protected root.') {
        $observed = if ($null -eq $protectedFailure) { 'accepted' } else { $protectedFailure }
        $boundaryFailures += "${mode}: $protectedDesktop => $observed"
      }
      $boundaryKey = Get-Item -LiteralPath $boundaryPolicy
      if ($boundaryKey.GetValueKind('allowedWorkspaceFolders').ToString() -cne 'String' -or $boundaryKey.GetValue('allowedWorkspaceFolders') -cne $priorValue) {
        throw "Protected-root $mode changed the user policy before rejection."
      }
      if (Test-Path -LiteralPath $boundaryState) { throw "Protected-root $mode wrote prestate before rejection." }
    }
  }
  $lookalikeDesktops = @(
    'C:\Program Files\HenryWilliam\PersonalContext-Lookalike',
    'C:\Program Files\HenryWilliam\PersonalContextSibling\Nested',
    'c:\program files\henrywilliam\personalcontextual'
  )
  foreach ($lookalikeDesktop in $lookalikeDesktops) {
    $lookalikePreview = & $configurator -DesktopPath $lookalikeDesktop -PolicyRegistryPath $boundaryPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $boundaryState | ConvertFrom-Json -ErrorAction Stop
    $expectedLookalike = [IO.Path]::GetFullPath([IO.Path]::Combine($lookalikeDesktop, 'Claude Workbench'))
    if ($lookalikePreview.workbenchRoot -cne $expectedLookalike -or $lookalikePreview.applyRequested -ne $false) { throw 'Workbench configurator rejected or changed a protected-root lookalike.' }
    if (Test-Path -LiteralPath $boundaryState) { throw 'Lookalike preview wrote prestate.' }
  }
  if ($boundaryFailures.Count -gt 0) { throw "Protected-root boundary failures: $($boundaryFailures -join '; ')" }
  Write-Output "PASS: $($protectedDesktops.Count * 2) protected-root Preview/Apply rejections before policy/prestate writes and $($lookalikeDesktops.Count) allowed lookalikes"

  $junctionTarget = Join-Path $sandbox 'Junction Target'
  $junctionDesktop = Join-Path $sandbox 'Junction Desktop'
  [IO.Directory]::CreateDirectory($junctionTarget) | Out-Null
  New-Item -ItemType Junction -Path $junctionDesktop -Target $junctionTarget | Out-Null
  $reparseFailure = $null
  try { & $configurator -DesktopPath $junctionDesktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null } catch { $reparseFailure = $_.Exception.Message }
  if ($reparseFailure -cne 'The resolved Claude Workbench path contains a redirecting reparse point.') { throw 'Workbench configurator accepted a redirecting reparse-backed Desktop path.' }
} finally {
  $registryBaseSubKey = $registryBase.Substring('HKCU:\'.Length)
  if (-not $registryBaseSubKey.StartsWith('SOFTWARE\HWOSLeanGuardWorkbenchTests\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Workbench test registry cleanup target escaped its test root.'
  }
  [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($registryBaseSubKey, $true)
  $registryTestSubKey = $registryTestRoot.Substring('HKCU:\'.Length)
  $rootKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registryTestSubKey, $true)
  if ($null -ne $rootKey) {
    $deleteTestRoot = $rootKey.ValueCount -eq 0 -and $rootKey.SubKeyCount -eq 0
    $rootKey.Dispose()
    if ($deleteTestRoot) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKey($registryTestSubKey, $false) }
  }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}

Write-Output 'PASS: Workbench preview, conflict/reparse/protected-root gates, MultiString apply, authenticated restore, and cleanup'
