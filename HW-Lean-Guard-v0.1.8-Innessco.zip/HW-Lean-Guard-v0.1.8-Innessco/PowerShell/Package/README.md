# HW Claude Lean Guard v0.1.8

This package moves the primary policy boundary to Claude Team organisation controls and keeps a small endpoint guard for consequences that still need deterministic, local enforcement.

Version 0.1.8 corrects the shell-operation and protected-path findings on top of v0.1.7. Personal Context remains an inactive technical preview. Package installation capability, remote hook activation and observed endpoint behavior are separate states. The unchanged v0.1.7 remote-settings candidate is still only a source candidate; installing these files does not publish it or activate Personal Context.

## Control split

| Boundary | Primary control | Endpoint guard role |
| --- | --- | --- |
| Confidentiality, source fidelity, draft status and escalation | Organisation instructions | None; these are behavioural requirements and remain subject to human review. |
| Approved connectors and settings precedence | Server-managed settings is the single policy authority | HKLM contains only the cross-source remote-refresh bootstrap; it does not duplicate organisation policy. |
| Lawyer access to matter drives | Existing user identity and filesystem permissions | The package never changes ACLs on `L:\` or configured UNC matter roots. |
| Direct Claude access to `L:\` | Organisation instructions and managed Read/Edit permissions | Prohibit direct access while leaving ordinary lawyer Windows access unchanged. Computed subprocess paths remain a documented residual risk. |
| Claude Workbench destination | Organisation instructions and the endpoint guard's protected-source copy check | Resolve the signed-in user's Windows Desktop Known Folder and admit only its `Claude Workbench` descendant; never hardcode a drive, username, OneDrive tenant or FSLogix path. |
| Claude Workbench user policy | Claude Desktop `allowedWorkspaceFolders` | The one-command installer creates the resolved `Desktop\Claude Workbench` folder and writes one exact current-user `MultiString` policy value after machine installation passes. A conflicting machine policy fails closed. |
| Credential-bearing text files | Organisation instructions and endpoint guard | Deny bounded files containing non-placeholder password/passphrase/token assignments before model context. |
| Internal/staging email | Organisation instructions and the approved connector's own gate | Require exact approved domains, exact draft review, Boolean confirmation, and no delayed/background delivery. |
| Litigation prompts | Organisation baseline plus managed prompt hook | Inject conservative and jurisdiction-aware guidance before substantive work. |
| Personal Context | Explicit user save, per-user DPAPI storage and bounded advisory retrieval | The candidate Context Broker preserves litigation output and omits personalization on Personal Context failure. It cannot change `PreToolUse` decisions. |
| Personal Context runtime | Protected `C:\Program Files\HenryWilliam\PersonalContext` root | Ordinary users receive read/execute access; direct modification is denied by the protected-root policy. |
| Filing, payment, transfer and submission tools | Connector design and organisation policy | Deny only the exact restricted capability identities listed in `policy/guard-policy.json`. Source text containing those words remains inert. |

## Explicit utility exceptions

- `disableSideloadFlags` is deliberately absent. Anthropic documents that it also rejects flags used by Cowork local sessions. Cowork's authorised local-session bootstrap is therefore retained.
- Claude-native tools are not blanket-disabled. Managed hooks evaluate the proposed operation, destination and structured recipient fields.
- `allowAllClaudeAiMcps` admits the claude.ai connectors enabled by the organisation without duplicating that connector catalogue in JSON.
- `strictPluginOnlyCustomization` locks the `mcp` surface so user and project MCP registrations do not load. Cowork's internally supplied session configuration remains the explicit `--mcp-config` exception because `disableSideloadFlags` would also disable Cowork local sessions.
- Source text is immutable evidence. The guard does not inspect document bodies, messages, prompts, summaries or extracted text for legal or risk vocabulary.
- Credential classification is the narrow exception: the guard inspects bounded readable text only for structured secret assignments before a file read enters model context. Oversized, unreadable and binary files remain outside that classifier.
- Shell file controls analyze operational operands, excluding inert heredoc/document data. Proven literal protected-source copies may enter the actual Claude Workbench; direct L-drive access and protected destinations remain denied. Unknown dynamic protected-copy forms do not acquire a blanket allow.
- Ordinary recognized deletion asks once, including `.mcpb` files. Protected source/runtime mutation is denied before confirmation. The old automatic MCPB replacement exception is no longer active.

These exceptions do not permit persistent user or project MCP registration. `allowManagedHooksOnly`, `allowManagedPermissionRulesOnly` and `strictPluginOnlyCustomization` keep those administrative surfaces managed.

## Delivery channels

- `policy/server-managed-settings.json` is the v0.1.7 Claude Code managed-settings candidate (hooks, permissions, managed flags). It retains Lean Guard `PreToolUse`, proposes Personal Context `SessionStart` and one Context Broker `UserPromptSubmit`, and contains no `claudeMd`. Publication and activation require a separate organisation-owner decision; the current remote payload remains unchanged.
- `policy/endpoint-bootstrap-settings.json` contains only `forceRemoteSettingsRefresh: true`. This documented cross-source exception closes the first-launch fetch window without repeating instructions, permissions, connectors or hooks.
- `policy/org-instructions.md` is the canonical instruction text. It is delivered exactly once, through Claude Team Organization instructions (Admin Settings > Organization and access), which apply to every Claude surface. It is never duplicated as `claudeMd` in the managed-settings payload; see `docs/delivery-channel-split.md`.

The endpoint installer writes only the refresh bootstrap to `HKLM\SOFTWARE\Policies\ClaudeCode\Settings`. It installs Lean Guard, litigation and the candidate hooks under `C:\Program Files\ClaudeCode\HWOSLeanGuard`, and the compiled Personal Context subtree under `C:\Program Files\HenryWilliam\PersonalContext`. State, rollback and metadata-only audit records live under `C:\ProgramData\HenryWilliam\LeanGuard`. Apply requires exact x64 `Microsoft.NETCore.App 8.0.30` and `-ServerManagedPolicyConfirmed` after confirming remote managed settings. This switch confirms the existing remote channel, not Personal Context activation.

Both machine roots are staged and hash-checked before promotion. A v2 receipt records both file trees, runtime prerequisite, bootstrap and candidate settings hashes. Detection rejects a v1 receipt as current installation evidence; v1 is accepted only as upgrade prestate. Machine uninstall requires validated v2 targets, restores the captured HKLM prestate and preserves per-user Personal Context data. The encoded UAC loader retains protected staging and the in-memory manifest anchor from v0.1.6.

Existing registry keys are retained: machine operations modify only `Settings`, and Workbench operations modify only `allowedWorkspaceFolders`. Unrelated values, subkeys and ACLs survive apply and restore. When Workbench already has the exact single MultiString value, Apply validates the folder and readback without rewriting that value. Incorrect read-only policy remains an error, not an excuse to change ACLs.

The elevated machine installer does not set user or machine environment variables, write FSLogix `redirections.xml`, or configure AppData, TEMP or cache exclusions. After that machine installation passes, the one-command wrapper runs `deployment/Configure-HWOSClaudeWorkbench.ps1` in the original signed-in user context. It resolves the Desktop Known Folder, creates only its `Claude Workbench` child and writes exactly that path to the current-user `allowedWorkspaceFolders` policy. Guard and Personal Context machine subtrees cannot be selected as Workbench destinations. FSLogix and storage exclusions remain a separate Innessco host-management input.

## Personal Context data boundary

The user-session executable supports explicit save, list, search, edit, forget, export, briefing, retrieval, rebuild and health operations. Save/edit require `--confirmed-personal`; hook commands cannot save. There is no automatic capture, transcript/file/mailbox/clipboard importer, vector search or Matter memory. Structural admission rejects the specified Matter/source paths and source types, but cannot prove that a user has correctly classified all text as personal. That semantic limitation remains an activation gate.

Canonical content and keys are DPAPI `CurrentUser` protected beneath `%APPDATA%\HenryWilliam\PersonalContext\<SID>`. The rebuildable HMAC-token FTS5 index is beneath the corresponding `%LOCALAPPDATA%` namespace. The index retains no plaintext content or query terms, but reveals repeated-token relationships and approximate token counts. No store or key is placed in shared ProgramData. Two-user ACL/DPAPI isolation and FSLogix roaming behavior remain unverified deployment gates.

The runtime is SHA-256 pinned through the package manifest and release evidence. No Authenticode signing key was available and no certificate signature is claimed. See [the technical specification](../docs/personal-context-technical-spec.md) and [integration review](../docs/integration-v0.1.7-review.md) for budgets, failure behavior and acceptance gates.

## Safe workflow

```powershell
# Preview only
.\deployment\Install-HWOSLeanGuard.ps1

# Elevated local install
.\deployment\Install-HWOSLeanGuard.ps1 -Apply -ServerManagedPolicyConfirmed

# Innessco bundle validation only
.\deployment\Install-HWOSLeanGuardOneCommand.ps1 -ValidateOnly

# One-command install; requests UAC when the current shell is not elevated
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\deployment\Install-HWOSLeanGuardOneCommand.ps1 -ServerManagedPolicyConfirmed

# Preview current-user Workbench resolution and policy conflict state
.\deployment\Configure-HWOSClaudeWorkbench.ps1

# Restore the captured pre-install current-user allowedWorkspaceFolders value; the Workbench folder is retained
.\deployment\Configure-HWOSClaudeWorkbench.ps1 -Restore -ExpectedPrestateSha256 '<apply-result prestateSha256>' -Confirm:$false

# Intune detection semantics: PASS writes one line and exits 0; failure is silent and exits 1
.\intune\Detect.ps1

# Safe uninstall restores the exact pre-install HKLM value
.\deployment\Uninstall-HWOSLeanGuard.ps1 -Apply
```

`intune/Build-HWOSLeanGuardIntuneWin.ps1` only stages and packages files locally. It does not upload, assign or deploy an Intune application.
