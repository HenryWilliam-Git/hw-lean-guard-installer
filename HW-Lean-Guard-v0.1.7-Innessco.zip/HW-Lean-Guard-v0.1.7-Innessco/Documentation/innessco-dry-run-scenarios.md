# Innessco Lean Guard v0.1.7 dry-run scenarios

Status: executable acceptance instructions; no target-host result is claimed. The release delivers an inactive Personal Context preview. Running a read-only preview, installing files and activating remote hooks are distinct actions.

## Operator intake without installation

Run DR-01 through DR-04 in a signed-in test-user session from the extracted `HW-Lean-Guard-v0.1.7-Innessco` root. Record UTC time, approved de-identified host/user identifiers, command, exit code and stdout/stderr. Stop on any mismatch. Keep sensitive paths and test content out of public evidence.

| ID | Gate | Expected result | Evidence |
| --- | --- | --- | --- |
| DR-01 | ZIP identity | Version, size and SHA-256 match the reviewed package record and release digest | ZIP hash and release/package records |
| DR-02 | Extracted integrity | Complete `HANDOFF-SHA256SUMS`, no unsafe/missing/extra paths or changed bytes | Checksum transcript |
| DR-03 | One-command and machine preview | v0.1.7, no apply/UAC; both intended roots; current-user Workbench preview | Both JSON responses and relevant unchanged-state inventory |
| DR-04 | Prerequisite and policy | Exact x64 NETCore 8.0.30 present; Desktop rooted; no machine policy conflict; existing remote settings confirmed | Runtime inventory, Workbench preview and Claude `/status` |

Before extraction, calculate the ZIP SHA-256 and compare it to the owner-supplied release record. From the extraction root, the following read-only check validates the handoff file list and bytes:

```powershell
$bundleRoot = [IO.Path]::GetFullPath((Get-Location).Path).TrimEnd('\')
$listed = @{}
foreach ($line in Get-Content -LiteralPath .\HANDOFF-SHA256SUMS) {
  if ($line -cnotmatch '^([0-9a-f]{64})  (.+)$') { throw 'Invalid checksum line.' }
  $expectedHash = $Matches[1]
  $relative = $Matches[2]
  if ([IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative.Contains(':')) { throw 'Unsafe checksum path.' }
  $target = [IO.Path]::GetFullPath((Join-Path $bundleRoot $relative))
  if (-not $target.StartsWith($bundleRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or $listed.ContainsKey($target)) { throw 'Escaped or duplicate path.' }
  if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw 'Missing handoff file.' }
  if ((Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant() -cne $expectedHash) { throw 'Handoff hash mismatch.' }
  $listed[$target] = $true
}
$actual = @(Get-ChildItem -LiteralPath $bundleRoot -File -Recurse | Where-Object FullName -NE (Join-Path $bundleRoot 'HANDOFF-SHA256SUMS'))
if ($actual.Count -ne $listed.Count -or @($actual | Where-Object { -not $listed.ContainsKey($_.FullName) }).Count -gt 0) { throw 'Missing or extra handoff file.' }
'PASS: complete handoff integrity'
```

Run the previews without `-Apply`:

```powershell
.\Install-HWOSLeanGuard.ps1 -ValidateOnly
.\PowerShell\Package\deployment\Install-HWOSLeanGuard.ps1
.\PowerShell\Package\deployment\Configure-HWOSClaudeWorkbench.ps1
& 'C:\Program Files\dotnet\dotnet.exe' --info
& 'C:\Program Files\dotnet\dotnet.exe' --list-runtimes
```

Expect one-command `applyRequested=false`, `uacRequested=false`, package `0.1.7`, and `workbench.policyScope=current-user` with `policyValueKind=MultiString`. Machine preview must name both Program Files roots and x64 runtime `8.0.30`. Preview alone does not establish prerequisite availability; independently require x64 architecture and exact `Microsoft.NETCore.App 8.0.30`. A newer runtime, x86 runtime or WindowsDesktop-only listing is insufficient. The Workbench configurator must report a rooted Desktop and no conflicting HKLM policy. Confirm its actual folder and HKCU/HKLM values are unchanged after preview.

`-ServerManagedPolicyConfirmed` confirms the existing remote-managed channel. It is not approval to publish the packaged candidate or activate Personal Context.

## Source qualification before release

These checks run from the reviewed repository, not from the minimal operator ZIP:

```powershell
.\scripts\Build-PersonalContext.ps1 -VerifyPackage
.\package\tests\Test-DeploymentV2.ps1
.\package\tests\Invoke-Tests.ps1 -Suite All
.\scripts\Test-InnesscoPackage.ps1
```

The release evidence must bind results to the fixed implementation SHA. Include actual compiled CLI lifecycle and SQLite plaintext inspections, Personal Context failure with litigation preserved, retained guard decisions, strict manifest checks, v1-to-v2 upgrade handling, two-root rollback, UAC staging/tamper/cancellation and original-user Workbench apply/restore. Development source, solution and lock files are required for the full suite and are not assumed present in the operator bundle. Passing source tests does not prove real Program Files ACLs or active Claude hooks.

## Separately authorized controlled-host tests

Do not run these against target Program Files, HKLM or user data until that host/test scope is approved. Use only disposable synthetic personal content with no person, client, Matter or source-document data. Record store/key/index prestate before any CLI mutation; remove only the test packet when a store already existed. Never delete another user's store or keys as cleanup.

| ID | Scenario | Required observation |
| --- | --- | --- |
| DR-05 | Missing/wrong prerequisite | Installation fails before machine mutation; exact runtime succeeds in the approved sandbox |
| DR-06 | UAC cancellation and staging tamper | Cancellation installs nothing; changed package/staged bytes cannot execute; protected stage cleaned or explicitly reported |
| DR-07 | Clean install and v1 upgrade | Both machine roots and every recorded hash match; v2 version/runtime/bootstrap/candidate checks true; prior HKLM prestate retained |
| DR-08 | Failed second-tree preparation/promotion | Both prior trees and registry restored; no partial success; retained cleanup errors reported |
| DR-09 | Workbench user phase | Original user's exact Desktop child and one HKCU MultiString; machine conflict refused; authenticated restore preserves folder |
| DR-10 | Machine uninstall | Validated two roots and v2 receipt removed, captured HKLM restored, evidence and all user PC data retained |
| DR-11 | Actual packaged CLI | Save/search/briefing/edit/supersession/forget/export/rebuild/health work; rejected Matter/source fixtures persist nothing; no plaintext content/query in databases |
| DR-12 | Two-user same-host isolation | Second user cannot read first user's store or unprotect its DPAPI blobs; no cross-user query path; own namespace remains functional |
| DR-13 | FSLogix and host switch | Canonical packets/keys survive approved sign-out/host switch; local index rebuilds; no live SQLite WAL on SMB; ordinary Workbench persistence retained |
| DR-14 | Separate hook activation | Only after owner approval and candidate publication: fresh real SessionStart/broker context, litigation preserved on PC failure, independent Lean Guard controls retained |

For an approved isolated install test, use the wrapper's explicit `-InstallRoot`, `-PersonalContextInstallRoot`, `-StateRoot`, `-PolicyRegistryPath` and Workbench test-path parameters. Resolve and record every test target first. Never omit the second root, which would otherwise use its real Program Files default. Test through the actual UAC wrapper, then perform elevated independent receipt/hash/ACL readback. An HKCU fixture or mocked ACL test is not real machine-security evidence.

After separately authorized actual-host installation, read-only machine detection is:

```powershell
.\PowerShell\Package\deployment\Detect-HWOSLeanGuard.ps1
Get-Content -LiteralPath 'C:\ProgramData\HenryWilliam\LeanGuard\state\install-state.json'
```

Require all current v2 checks and both root hashes to match the release record. A v1 receipt is accepted as upgrade prestate only and must fail current detection. Detection does not establish that the packaged managed-settings candidate is published or active.

## Handoff decision

Record pass/fail/pending for each applicable scenario, with exact source/artifact identity and cleanup evidence. SHA-256 integrity is available; no Authenticode signature is claimed. Semantic client/Matter admission, signing, same-host isolation, FSLogix behavior, actual endpoint install and active-hook verification remain separate gates. An inactive preview may be released with those gates pending, but must not be represented as activated or production-live verified.
