# Lean Guard 0.1.7 production handoff

## Handoff status

This handoff describes the v0.1.7 integration candidate based on published v0.1.6. It adds an inactive explicit-save Personal Context preview, candidate Claude Code hooks, a protected second machine root and v2 installation receipts while retaining secured UAC delivery and original-user Workbench configuration.

Final implementation SHA, tests, release publication, artifact digests and CI must be read from the v0.1.7 release record. This document does not claim those pending results. No v0.1.7 endpoint installation, managed-settings publication, Personal Context activation, two-user isolation or pooled-host live verification has been performed by this release task. Package publication does not authorize Innessco to begin target-host execution.

## Approved handoff inputs

| Input | Location |
| --- | --- |
| Direct installer | `package/deployment/Install-HWOSLeanGuardOneCommand.ps1` |
| Workbench configurator | `package/deployment/Configure-HWOSClaudeWorkbench.ps1` |
| Personal Context payload | `package/personal-context/` |
| Exact runtime prerequisite | x64 `Microsoft.NETCore.App 8.0.30`; a newer or x86-only runtime does not satisfy this package |
| Release record and final hashes | `evidence/release-candidate/2026-09-07-v0.1.7/release-candidate.json` |
| Delta UAT record | `evidence/release-candidate/2026-09-07-v0.1.7/delta-uat.json` |
| Evidence checksums | `evidence/release-candidate/2026-09-07-v0.1.7/SHA256SUMS` |
| Rollback entry point | `PowerShell/Package/deployment/Uninstall-HWOSLeanGuard.ps1` in the extracted bundle |
| Cloud-only architecture | `docs/assets/cloud-only-production-architecture.jpg` |
| Innessco dry-run scenarios | `docs/innessco-v0.1.7-dry-run-scenarios.md` |
| Extractable Innessco bundle target | `evidence/innessco-package/v0.1.7/HW-Lean-Guard-v0.1.7-Innessco.zip` |

Innessco must verify the ZIP and extracted-file hashes before execution. The package must not be edited, partially copied or rebuilt during intake. When UAC is required, the parent launches an encoded minimal loader that copies the package into Administrator-only ProgramData staging, verifies the expected manifest SHA-256 and every staged file before executing the elevated child, and removes that stage in `finally`.

Existing Organization instructions and remote hooks remain the active policy channels. The v0.1.7 settings file is a candidate only. Before installation is reported complete, verify both installed roots, v2 receipt, exact runtime and current-user Workbench policy. Before activation is reported complete, obtain separate approval, publish the candidate and verify its behavior in a fresh real Claude Code session. Only the approved Workbench may be mountable; direct `L:\` access remains prohibited.

For online delivery, follow [Public online installation](public-online-install.md). The evergreen bootstrap selects the currently published release, so verify that its release metadata names the approved version. The one-line command must authenticate the immutable bootstrap digest before execution; the bootstrap then verifies the versioned ZIP, archive paths and package manifest. A prepared v0.1.7 command is not evidence that the public release exists or that an endpoint has been installed.

For operator delivery, use the versioned Innessco bundle. It contains one extraction root, the root installer, the complete manifest-validated package, current handoff, cloud-only architecture JPG and integrity records. The IntuneWin artifact is not an Innessco deployment input. Repository validation requires a matching deterministic bundle for the current `package/VERSION`, so every new release or included-input change must regenerate and validate the bundle.

## Approved production execution model

Henry William has enabled and manages Cowork in the cloud through Claude organization controls.

- Cowork agent and code execution run on Anthropic infrastructure.
- Claude Desktop brokers permission-controlled access when a cloud session needs an approved local folder.
- Claude Code tools and commands run in each user's Windows session.
- Claude Code managed settings and Lean Guard apply to Claude Code, not cloud Cowork.
- Local Cowork execution and local Cowork Linux VMs are outside scope.
- Virtual Machine Platform and nested virtualisation are not Stage 1 prerequisites.

Innessco is not being asked to configure the cloud-Cowork organization control, Organization instructions, Claude Code managed settings or managed hooks. Innessco owns the machine and user-context deployment surfaces described below.

## Personal Context preview and activation boundary

The CLI accepts only explicitly confirmed personal packets. It does not automatically capture conversations, transcripts, files, emails, attachments, clipboard data or Matter content. There is no Matter memory or bulk importer. Structural path/source checks reject known disallowed forms; they cannot guarantee that every user-classified packet is semantically personal. Authoritative client/Matter admission controls remain an activation gate.

Installation can provision `C:\Program Files\HenryWilliam\PersonalContext` with ordinary-user read/execute access. The signed-in-user CLI stores DPAPI-encrypted canonical packets and keys beneath `%APPDATA%\HenryWilliam\PersonalContext\<SID>` and a rebuildable HMAC-token FTS5 index beneath the corresponding `%LOCALAPPDATA%` path. No user store is created by the machine installer. No machine uninstall deletes these user databases, indexes or keys.

Activation remains pending owner approval and evidence of same-host second-user ACL read denial, DPAPI unprotect denial, no cross-user query path, reviewed semantic admission and FSLogix persistence/index rebuild. The index still reveals token repetition and approximate counts and must be treated as sensitive. There is no DPAPI recovery escrow. No Authenticode key was available, so SHA-256 integrity must not be described as a certificate signature.

## Current pooled-host assumptions for Innessco confirmation

The following reflects Henry William's current assessment. Please correct any inaccurate or incomplete assumption and advise of any Stage 1 implication.

- Host-P05-0 is a shared multi-session host using `Standard_E8as_v5`: 8 vCPU, 64 GiB RAM, AMD EPYC, x86-64 and no local temp disk.
- Its 128 GB `Premium_LRS` managed OS disk is persistent, not ephemeral. The installed runtime, HKLM bootstrap and local `ProgramData` state therefore survive ordinary stop/start and reboot.
- Users are load-balanced between eligible hosts. FSLogix persists the user profile externally and OneDrive Known Folder Move persists Desktop independently of the selected host.
- Every session host, including a newly added or replaced host, requires the elevated machine-wide install. A reimaged or recomposed host requires the command to be rerun and hashes reverified.
- Local audit evidence must be forwarded or retained before host replacement/reimage. The operational design must also address concurrent multi-user append monitoring and user attribution outside this narrow package change.
- No extra Lean Guard HKLM schema is required. HKLM remains the remote-refresh bootstrap only.

## Target storage and capacity model

Henry William requires the following deployment outcome:

- required Claude authentication, configuration and persistent user state follows the user through FSLogix;
- Personal Context canonical data and keys require an explicitly confirmed Roaming AppData inclusion; its Local AppData index requires a tested local-only/rebuild policy before activation;
- approved work product remains under OneDrive Known Folder Move at `Desktop\Claude Workbench`;
- disposable `%TEMP%`, Claude Desktop and Claude Code cache data is excluded from roaming storage where supportable and placed under managed host-local cleanup, retention and monitoring;
- machine-wide application, package and update data remains machine-managed rather than duplicated inside each user profile;
- Lean Guard state, evidence and audit logs under `C:\ProgramData\HenryWilliam\LeanGuard` are protected from disposable cleanup; and
- cloud Cowork session data remains in the user's approved Claude cloud account, leaving only required Desktop broker data and caches on the endpoint.

This is an outcome requirement rather than a prescribed FSLogix or endpoint-management implementation. Please provide the proposed Innessco implementation for Stage 1, including:

- FSLogix inclusion, exclusion and redirection rules;
- the user or device context used to deploy those rules;
- the managed host-local TEMP/cache locations;
- cleanup and retention cadence with active-session and evidence protections;
- disk monitoring, alerting and minimum-free-space threshold;
- new-host, reimage and recomposition compliance; and
- capacity remediation, resize or scale-out triggers.

If the exact split is not supportable, propose the closest deployable alternative that preserves durable user state, OneDrive-backed work product, controlled disposable data, no unnecessary per-user duplication and centrally monitored host capacity.

## Claude Workbench user dependency

For each signed-in pooled user, Innessco must:

1. resolve the Windows Desktop Known Folder in user context with `[Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)`;
2. require a non-empty rooted result and never fall back to the SYSTEM profile or a guessed drive;
3. run the reviewed one-command installer in that signed-in user context so it creates only the `Claude Workbench` child folder;
4. verify the installer configured the Claude Desktop HKCU `allowedWorkspaceFolders` `MultiString` with exactly that resolved absolute path and did not authorise `L:\` for Claude or change ordinary Windows access;
5. confirm the installer refused any conflicting HKLM `allowedWorkspaceFolders` value that would override the user policy; and
6. repeat the user-context policy at sign-in when required by the pooled profile lifecycle.

The logical user-facing location is always `Desktop\Claude Workbench`, even when OneDrive Known Folder Move or FSLogix changes the underlying absolute path.

This is a Claude-specific restriction. It must not remove, unmap, restrict or change the ACLs for the user's ordinary Windows access to `L:\`; users continue to access and modify that drive directly through approved Windows applications and credentials.

Cloud Cowork reaches this folder through Claude Desktop's permission-controlled local-file broker. `L:\` must not be added to the Cowork workspace allowlist.

## Direct PowerShell installation

After separate target-host authorization, extract the complete reviewed ZIP to a local folder, verify `HANDOFF-SHA256SUMS`, confirm exact x64 `Microsoft.NETCore.App 8.0.30` and Claude `/status` showing `Enterprise managed settings (remote)`, then run from the extraction root:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-HWOSLeanGuard.ps1 -ServerManagedPolicyConfirmed
```

The command validates the complete package manifest, requests UAC when needed, verifies protected staged files, and runs the two-root transaction. It fails unless v2 receipt, version, exact runtime, registry, candidate-settings hash and both installed file trees pass readback. A v1 receipt is accepted only as upgrade prestate. A cancelled UAC prompt is not an installation. Preserve output and the new receipt under `C:\ProgramData\HenryWilliam\LeanGuard\evidence`. The confirmation switch verifies the existing remote-policy channel; it does not activate Personal Context.

The command creates the signed-in user's resolved `Desktop\Claude Workbench` and configures its HKCU `allowedWorkspaceFolders` policy. It does not set environment variables or install FSLogix, AppData, TEMP or cache exclusions. Do not promote environment-variable values, profile paths, OneDrive tenant paths or `redirections.xml` content observed in staging into production defaults. Resolve those remaining values independently for each target user and host. The `%USERPROFILE%` token in the narrow legacy MCPB replacement rule remains a runtime token and must not be replaced with a staging profile path.

Run the command once on every approved session host. Rerun it after replacement, reimage or recomposition. Direct PowerShell execution does not provide central assignment, scheduled remediation or fleet detection, so Innessco must name the host inventory, execution mechanism, monitoring owner and redeployment trigger.

## Required Innessco deployment response

Before Stage 1 execution, please provide:

1. The proposed FSLogix, TEMP/cache cleanup and disk-monitoring implementation for the target storage model.
2. The user-context method used to create and authorise `Desktop\Claude Workbench` after the Desktop Known Folder is available.
3. Any deviation from the target storage outcome and the closest supported alternative.
4. Which exact hosts define Jay's Stage 1 target, the four-user Stage 2 pilot and the remaining-user Stage 3 rollout.
5. What controlled execution mechanism and installation deadline apply to current, new, replaced and reimaged hosts.
6. Who monitors install, detection, cleanup and capacity failures and who can approve Stages 2 and 3, pause or rollback.
7. Where command output, endpoint audit and incident records are retained before host replacement/reimage.
8. Whether the organization requires Authenticode/catalog signing beyond SHA-256 pinning.
9. Which target-specific FSLogix, Workbench, AppData, TEMP and cache exclusions are applied separately, and how staging values are prevented from becoming production defaults.
10. How exact x64 .NET 8.0.30 will be provisioned and kept available on every target host, including replacement/reimage.
11. The separately authorized two-user and FSLogix Personal Context test plan and its evidence owner.

## Henry William owner actions

The organization owner must:

1. confirm the already-published English Organization instructions in a fresh session;
2. confirm the already-published Claude Code managed-settings JSON in `/permissions` and hook output;
3. retain the approved exact `hwdev.com.au` production domain and deny subdomains/lookalikes;
4. verify fresh Claude Code sessions receive the existing active hooks, and keep the Personal Context candidate unpublished until its separate activation gates pass;
5. retain and operate the cloud-Cowork organization controls; and
6. approve each rollout stage and residual-risk decision.

## Three-stage rollout

1. **Stage 1 - Jay:** deploy to Jay's controlled pooled AVD host, verify machine, user-context and storage dependencies, and monitor one normal work cycle.
2. **Stage 2 - one-week pilot:** after written approval, deploy only to John Nash, Michele Izzo, Gidon Kangisser and Linda Mulenda. Monitor installation, detection, policy, connector, user-experience, AppData, TEMP, cache, log and host-capacity outcomes for one week.
3. **Stage 3 - firm-wide rollout:** proceed only after Henry William reviews the full Stage 2 evidence, provides the final remaining-user list and issues separate written approval.

Each stage must record assigned host/user count, installation success, detection result, installed hashes, policy state, cloud-Cowork and Claude Code smoke results, storage-path results, disk-capacity evidence and any incident or rollback.

Stage 2 evidence must cover the complete one-week observation period.

## Production-live acceptance

A device is production-live verified only when:

- the direct installer reports `PASS` and the execution record identifies the exact host and package version;
- v2 installed-state detection reports all checks true, including exact x64 .NET 8.0.30;
- both installed machine roots and policy hashes match the release record;
- HKLM contains the remote-refresh bootstrap only;
- updated Organization instructions are observed in behavior;
- Lean Guard and litigation hooks execute with no stderr;
- cloud Cowork reports cloud execution and does not require a local Cowork VM;
- Claude Desktop brokers access to the approved Claude Workbench folder and does not authorise `L:\`;
- required Claude user state persists through FSLogix while Claude Workbench remains in OneDrive;
- disposable TEMP/cache data is covered by the deployed cleanup, retention and monitoring controls;
- the production smoke scenarios in `implementation-plan.md` pass; and
- audit and rollback ownership are available.

If Personal Context is included in the production-live claim, its separate activation, two-user isolation, semantic admission, signing and FSLogix gates must also pass. A successful inactive-preview installation does not meet those gates.

## Rollback

Rollback authority must be named before Stage 2, and Stage 3 must not begin without confirmed monitoring and rollback ownership. From an elevated PowerShell in the extracted bundle, run `PowerShell\Package\deployment\Uninstall-HWOSLeanGuard.ps1 -Apply -Confirm:$false`. Verify:

- both recorded machine install roots are absent;
- the previous HKLM state is restored;
- detection reports not installed;
- retained evidence is readable; and
- ordinary lawyer source access is unchanged.

Per-user Personal Context databases, indexes and DPAPI files must remain untouched. Restore Workbench policy separately in the original signed-in user context using the captured prestate hash. If Personal Context hooks were separately activated, the organization owner must first coordinate remote-policy rollback so active hooks do not point at removed files.

## Prohibited delivery patterns

- Do not configure endpoints to `git pull` from GitHub.
- Do not execute mutable branch content on AVD hosts.
- Do not edit, partially copy or rebuild the manifest-validated package at Innessco.
- Do not paste Organization instructions into `claudeMd` or HKLM.
- Do not add `$schema` to the Admin console managed-settings payload.
- Do not represent Claude Code managed settings or Lean Guard as cloud-Cowork enforcement.
- Do not enable Virtual Machine Platform or nested virtualisation solely for this cloud-only production model.
- Do not add disposable TEMP/cache cleanup to the Lean Guard runtime or delete Lean Guard `ProgramData` evidence.
- Do not accept an artifact from a mutable draft release, branch download or unverified local rebuild.
