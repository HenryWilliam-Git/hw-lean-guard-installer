[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [switch]$Restore,
  [string]$DesktopPath,
  [string]$PolicyRegistryPath = 'HKCU:\SOFTWARE\Policies\Claude',
  [string]$MachinePolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\Claude',
  [string]$UserStateRoot,
  [string]$ExpectedPrestateSha256
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

function Get-RegistryValueState {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][string]$Name
  )
  if (-not (Test-Path -LiteralPath $Path)) {
    return [ordered]@{ keyExists = $false; valueExists = $false; valueKind = $null; value = $null }
  }
  $key = Get-Item -LiteralPath $Path
  try {
    $value = $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind = $key.GetValueKind($Name).ToString()
    return [ordered]@{ keyExists = $true; valueExists = $true; valueKind = $kind; value = @($value) }
  } catch [ArgumentException] {
    return [ordered]@{ keyExists = $true; valueExists = $false; valueKind = $null; value = $null }
  } catch [IO.IOException] {
    return [ordered]@{ keyExists = $true; valueExists = $false; valueKind = $null; value = $null }
  }
}

function Restore-RegistryValueState {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)][object]$State
  )
  if ($State.valueExists) {
    New-Item -Path $Path -Force | Out-Null
    $kind = [Enum]::Parse([Microsoft.Win32.RegistryValueKind], [string]$State.valueKind)
    $value = if ($kind -eq [Microsoft.Win32.RegistryValueKind]::MultiString) { [string[]]@($State.value) } else { $State.value }
    New-ItemProperty -LiteralPath $Path -Name $Name -Value $value -PropertyType $kind -Force | Out-Null
  } elseif (Test-Path -LiteralPath $Path) {
    $current = Get-RegistryValueState -Path $Path -Name $Name
    if ($current.valueExists) {
      Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop
    }
    $key = Get-Item -LiteralPath $Path
    if (-not $State.keyExists -and $key.ValueCount -eq 0 -and @(Get-ChildItem -LiteralPath $Path).Count -eq 0) {
      Remove-Item -LiteralPath $Path -Force
    }
  }

  $restored = Get-RegistryValueState -Path $Path -Name $Name
  if ([bool]$restored.valueExists -ne [bool]$State.valueExists) {
    throw 'Registry policy restore readback failed.'
  }
  if ($State.valueExists) {
    $expectedValues = @($State.value)
    $actualValues = @($restored.value)
    if ([string]$restored.valueKind -cne [string]$State.valueKind -or $actualValues.Count -ne $expectedValues.Count) {
      throw 'Registry policy restore readback failed.'
    }
    for ($index = 0; $index -lt $expectedValues.Count; $index++) {
      if ([string]$actualValues[$index] -cne [string]$expectedValues[$index]) {
        throw 'Registry policy restore readback failed.'
      }
    }
  }
}

function Write-JsonNoBom {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][object]$Value
  )
  [IO.Directory]::CreateDirectory((Split-Path -Parent $Path)) | Out-Null
  [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 20), [Text.UTF8Encoding]::new($false))
}

function Assert-SafeWorkbenchPath {
  param([Parameter(Mandatory = $true)][string]$Path)
  $candidate = [IO.Path]::GetFullPath($Path)
  foreach ($protectedRoot in @('L:\', 'C:\Program Files\ClaudeCode\HWOSLeanGuard')) {
    $root = [IO.Path]::GetFullPath($protectedRoot).TrimEnd('\')
    if ($candidate.Equals($root, [StringComparison]::OrdinalIgnoreCase) -or $candidate.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) {
      throw 'The resolved Claude Workbench path intersects a protected root.'
    }
  }
  $cursor = $candidate
  while (-not [string]::IsNullOrWhiteSpace($cursor)) {
    if (Test-Path -LiteralPath $cursor) {
      $item = Get-Item -LiteralPath $cursor -Force
      if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
        $targets = @($item.Target | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        if (-not [string]::IsNullOrWhiteSpace([string]$item.LinkType) -or $targets.Count -gt 0) {
          throw 'The resolved Claude Workbench path contains a redirecting reparse point.'
        }
      }
    }
    $parent = Split-Path -Parent $cursor
    if ([string]::IsNullOrWhiteSpace($parent) -or $parent.Equals($cursor, [StringComparison]::OrdinalIgnoreCase)) { break }
    $cursor = $parent
  }
}

if ($Apply -and $Restore) { throw 'Choose either -Apply or -Restore, not both.' }
if ([Security.Principal.WindowsIdentity]::GetCurrent().IsSystem) { throw 'Workbench user policy must run in the signed-in user context, not SYSTEM.' }

if ([string]::IsNullOrWhiteSpace($DesktopPath)) {
  $DesktopPath = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
}
if ([string]::IsNullOrWhiteSpace($DesktopPath) -or -not [IO.Path]::IsPathRooted($DesktopPath)) {
  throw 'The signed-in user Desktop Known Folder must resolve to a non-empty rooted path.'
}
$desktopRoot = [IO.Path]::GetFullPath($DesktopPath).TrimEnd('\')
$workbenchRoot = [IO.Path]::GetFullPath([IO.Path]::Combine($desktopRoot, 'Claude Workbench'))
Assert-SafeWorkbenchPath -Path $workbenchRoot

if ([string]::IsNullOrWhiteSpace($UserStateRoot)) {
  if ([string]::IsNullOrWhiteSpace($env:LOCALAPPDATA) -or -not [IO.Path]::IsPathRooted($env:LOCALAPPDATA)) {
    throw 'LOCALAPPDATA must resolve to a rooted user path for reversible Workbench policy state.'
  }
  $UserStateRoot = Join-Path $env:LOCALAPPDATA 'HenryWilliam\LeanGuard'
}
$resolvedUserStateRoot = [IO.Path]::GetFullPath($UserStateRoot).TrimEnd('\')
$statePath = Join-Path $resolvedUserStateRoot 'state\workbench-policy-prestate.json'
$policyName = 'allowedWorkspaceFolders'

$userPolicyState = Get-RegistryValueState -Path $PolicyRegistryPath -Name $policyName
$machinePolicyState = Get-RegistryValueState -Path $MachinePolicyRegistryPath -Name $policyName
$machinePolicyExact = $machinePolicyState.valueExists -and [string]$machinePolicyState.valueKind -ceq 'MultiString' -and @($machinePolicyState.value).Count -eq 1 -and [string]$machinePolicyState.value[0] -ceq $workbenchRoot
$machinePolicyConflict = $machinePolicyState.valueExists -and -not $machinePolicyExact

$preview = [ordered]@{
  schemaVersion = 'hw-lean-guard-workbench-policy-preview/v1'
  applyRequested = [bool]$Apply
  restoreRequested = [bool]$Restore
  desktopKnownFolder = $desktopRoot
  workbenchRoot = $workbenchRoot
  workbenchExists = Test-Path -LiteralPath $workbenchRoot -PathType Container
  policyScope = 'current-user'
  policyRegistryPath = $PolicyRegistryPath
  policyName = $policyName
  policyValueKind = 'MultiString'
  policyValues = @($workbenchRoot)
  machinePolicyPresent = [bool]$machinePolicyState.valueExists
  machinePolicyExact = [bool]$machinePolicyExact
  machinePolicyConflict = [bool]$machinePolicyConflict
  statePath = $statePath
  sourceDriveAclsChanged = $false
  environmentVariablesChanged = $false
  fsLogixConfigured = $false
}
if (-not $Apply -and -not $Restore) { $preview | ConvertTo-Json -Depth 12; return }

if ($Restore) {
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Workbench policy prestate is missing; refusing an unbounded restore.' }
  if ($ExpectedPrestateSha256 -notmatch '^[0-9a-fA-F]{64}$') { throw 'Restore requires the exact prestate SHA-256 recorded by the apply result.' }
  $actualPrestateSha256 = (Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant()
  if ($actualPrestateSha256 -cne $ExpectedPrestateSha256.ToLowerInvariant()) { throw 'Workbench policy prestate SHA-256 mismatch.' }
  $receipt = [IO.File]::ReadAllText($statePath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
  if ($receipt.schemaVersion -cne 'hw-lean-guard-workbench-prestate/v1' -or -not ([string]$receipt.policyRegistryPath).Equals($PolicyRegistryPath, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Workbench policy prestate identity is invalid.'
  }
  if (-not $PSCmdlet.ShouldProcess($PolicyRegistryPath, 'Restore prior allowedWorkspaceFolders user policy')) { return }
  Restore-RegistryValueState -Path $PolicyRegistryPath -Name $policyName -State $receipt.registry
  [ordered]@{
    schemaVersion = 'hw-lean-guard-workbench-policy-result/v1'
    action = 'restore'
    workbenchRetained = Test-Path -LiteralPath $workbenchRoot -PathType Container
    priorPolicyRestored = $true
    sourceDriveAclsChanged = $false
    result = 'PASS'
  } | ConvertTo-Json -Depth 10
  return
}

if ($machinePolicyConflict) { throw 'A conflicting machine-level allowedWorkspaceFolders policy overrides the current-user policy.' }
if (-not $PSCmdlet.ShouldProcess($workbenchRoot, 'Create Claude Workbench and configure current-user allowedWorkspaceFolders')) { return }

$transactionPreState = $userPolicyState
try {
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) {
    Write-JsonNoBom -Path $statePath -Value ([ordered]@{
      schemaVersion = 'hw-lean-guard-workbench-prestate/v1'
      capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
      policyRegistryPath = $PolicyRegistryPath
      policyName = $policyName
      registry = $userPolicyState
    })
  }
  [IO.Directory]::CreateDirectory($workbenchRoot) | Out-Null
  Assert-SafeWorkbenchPath -Path $workbenchRoot
  New-Item -Path $PolicyRegistryPath -Force | Out-Null
  [string[]]$policyValue = @($workbenchRoot)
  New-ItemProperty -LiteralPath $PolicyRegistryPath -Name $policyName -Value $policyValue -PropertyType MultiString -Force | Out-Null

  $readback = Get-RegistryValueState -Path $PolicyRegistryPath -Name $policyName
  $policyExact = $readback.valueExists -and [string]$readback.valueKind -ceq 'MultiString' -and @($readback.value).Count -eq 1 -and [string]$readback.value[0] -ceq $workbenchRoot
  $folderExists = Test-Path -LiteralPath $workbenchRoot -PathType Container
  if (-not $policyExact -or -not $folderExists) { throw 'Workbench folder or allowedWorkspaceFolders readback failed.' }

  [ordered]@{
    schemaVersion = 'hw-lean-guard-workbench-policy-result/v1'
    action = 'apply'
    workbenchRoot = $workbenchRoot
    workbenchExists = $folderExists
    policyValueKind = [string]$readback.valueKind
    policyValues = @($readback.value)
    policyExact = $policyExact
    machinePolicyConflict = $false
    prestatePath = $statePath
    prestateSha256 = (Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant()
    sourceDriveAclsChanged = $false
    environmentVariablesChanged = $false
    fsLogixConfigured = $false
    result = 'PASS'
  } | ConvertTo-Json -Depth 12
} catch {
  $applyError = $_.Exception.Message
  try {
    Restore-RegistryValueState -Path $PolicyRegistryPath -Name $policyName -State $transactionPreState
  } catch {
    throw "Workbench policy apply failed: $applyError Rollback also failed: $($_.Exception.Message)"
  }
  throw
}
