Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'HWOSLeanGuard.Paths.ps1')
. (Join-Path $PSScriptRoot 'HWOSLeanGuard.Transaction.ps1')

function Test-HWOSLeanGuardAdministrator {
  $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
  $principal = [Security.Principal.WindowsPrincipal]::new($identity)
  return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-HWOSLeanGuardSha256 {
  param([Parameter(Mandatory = $true)][string]$Path)
  return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Get-HWOSLeanGuardTextSha256 {
  param([Parameter(Mandatory = $true)][string]$Text)
  $bytes = [Text.Encoding]::UTF8.GetBytes($Text)
  return ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash($bytes))).Replace('-', '').ToLowerInvariant()
}

function Read-HWOSLeanGuardJson {
  param([Parameter(Mandatory = $true)][string]$Path)
  return ([IO.File]::ReadAllText([IO.Path]::GetFullPath($Path), [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop)
}

function Write-HWOSLeanGuardJson {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][object]$Value
  )
  $parent = Split-Path -Parent ([IO.Path]::GetFullPath($Path))
  [IO.Directory]::CreateDirectory($parent) | Out-Null
  $json = $Value | ConvertTo-Json -Depth 40
  [IO.File]::WriteAllText([IO.Path]::GetFullPath($Path), $json, [Text.UTF8Encoding]::new($false))
}

function Assert-HWOSLeanGuardPackage {
  param([Parameter(Mandatory = $true)][string]$PackageRoot)
  $root = [IO.Path]::GetFullPath($PackageRoot)
  Assert-HWOSLeanGuardSafeTree -Root $root
  $manifestPath = Join-Path $root 'manifest.json'
  if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) { throw 'Package manifest is missing.' }
  $manifest = Read-HWOSLeanGuardJson -Path $manifestPath
  if ($manifest.schemaVersion -cne 'hw-os-lean-guard-manifest/v1' -or $manifest.packageVersion -cne '0.1.7') {
    throw 'Package manifest identity is invalid.'
  }
  $expected = @{}
  foreach ($property in $manifest.files.PSObject.Properties) {
    $relative = $property.Name.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $expected[$relative] = [string]$property.Value
    $candidate = Resolve-HWOSLeanGuardContainedFile -Root $root -Relative $relative
    if (-not $candidate.StartsWith($root.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Manifest path escapes package root.' }
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw "Manifest file missing: $relative" }
    if ((Get-HWOSLeanGuardSha256 -Path $candidate) -cne [string]$property.Value) { throw "Manifest hash mismatch: $relative" }
  }
  $actual = @(Get-ChildItem -LiteralPath $root -Recurse -File -Force | ForEach-Object { $_.FullName.Substring($root.Length).TrimStart('\') } | Where-Object { $_ -cne 'manifest.json' })
  $extra = @($actual | Where-Object { -not $expected.ContainsKey($_) })
  if ($extra.Count -gt 0) { throw "Package contains unmanifested files: $($extra -join ', ')" }
  return $manifest
}

function Get-HWOSLeanGuardRegistryState {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [string]$Name = 'Settings'
  )
  if (-not (Test-Path -LiteralPath $Path)) {
    return [ordered]@{ keyExists = $false; valueExists = $false; valueKind = $null; value = $null }
  }
  $key = Get-Item -LiteralPath $Path
  try {
    $value = $key.GetValue($Name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind = $key.GetValueKind($Name).ToString()
    return [ordered]@{ keyExists = $true; valueExists = $true; valueKind = $kind; value = $value }
  } catch [System.ArgumentException] {
    return [ordered]@{ keyExists = $true; valueExists = $false; valueKind = $null; value = $null }
  } catch [System.IO.IOException] {
    return [ordered]@{ keyExists = $true; valueExists = $false; valueKind = $null; value = $null }
  }
}

function Restore-HWOSLeanGuardRegistryState {
  param(
    [Parameter(Mandatory = $true)][string]$Path,
    [Parameter(Mandatory = $true)][object]$State,
    [string]$Name = 'Settings'
  )
  if ($State.valueExists) {
    New-Item -Path $Path -Force | Out-Null
    $kind = [Enum]::Parse([Microsoft.Win32.RegistryValueKind], [string]$State.valueKind)
    New-ItemProperty -LiteralPath $Path -Name $Name -Value ([string]$State.value) -PropertyType $kind -Force | Out-Null
  } elseif (Test-Path -LiteralPath $Path) {
    if ((Get-Item -LiteralPath $Path).GetValueNames() -contains $Name) { Remove-ItemProperty -LiteralPath $Path -Name $Name -ErrorAction Stop }
    if (-not $State.keyExists -and (Get-Item -LiteralPath $Path).ValueCount -eq 0 -and @(Get-ChildItem -LiteralPath $Path).Count -eq 0) {
      Remove-Item -LiteralPath $Path -Force
    }
  }
}

function Set-HWOSLeanGuardTreeAcls {
  param(
    [Parameter(Mandatory = $true)][string]$Root,
    [Parameter(Mandatory = $true)][string[]]$Grants,
    [Parameter(Mandatory = $true)][string]$FailureLabel
  )
  $grantArguments = @($Root, '/inheritance:r', '/grant:r') + $Grants + @('/C')
  $null = & icacls.exe @grantArguments
  if ($LASTEXITCODE -ne 0) { throw "Failed to secure the $FailureLabel root ACL." }
  if (@(Get-ChildItem -LiteralPath $Root -Force).Count -gt 0) {
    $null = & icacls.exe (Join-Path $Root '*') '/reset' '/T' '/C'
    if ($LASTEXITCODE -ne 0) { throw "Failed to reset inherited ACLs beneath the $FailureLabel root." }
  }
}

function Set-HWOSLeanGuardAcls {
  param(
    [Parameter(Mandatory = $true)][string]$InstallRoot,
    [string]$PersonalContextRoot,
    [Parameter(Mandatory = $true)][string]$StateRoot
  )
  $logs = Join-Path $StateRoot 'logs'
  [IO.Directory]::CreateDirectory($logs) | Out-Null
  Set-HWOSLeanGuardTreeAcls -Root $InstallRoot -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F', 'BUILTIN\Users:(OI)(CI)RX') -FailureLabel 'installed runtime'
  if (-not [string]::IsNullOrWhiteSpace($PersonalContextRoot)) { Set-HWOSLeanGuardTreeAcls -Root $PersonalContextRoot -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F', 'BUILTIN\Users:(OI)(CI)RX') -FailureLabel 'Personal Context runtime' }
  Set-HWOSLeanGuardTreeAcls -Root $StateRoot -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F') -FailureLabel 'state'
  Set-HWOSLeanGuardTreeAcls -Root $logs -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F', 'BUILTIN\Users:(OI)(CI)(RX,W)') -FailureLabel 'audit log'
}

. (Join-Path $PSScriptRoot 'HWOSLeanGuard.State.ps1')

Export-ModuleMember -Function @(
  'Assert-HWOSLeanGuardSafeDestination',
  'Assert-HWOSLeanGuardUninstallTargets',
  'Get-HWOSLeanGuardFileHashes',
  'Invoke-HWOSLeanGuardTwoRootSwap',
  'Remove-HWOSLeanGuardMachineInstall',
  'Test-HWOSLeanGuardDotNetPrerequisite',
  'Test-HWOSLeanGuardReceiptUpgradePrestate',
  'Test-HWOSLeanGuardRecordedFiles',
  'Assert-HWOSLeanGuardPackage',
  'Get-HWOSLeanGuardInstalledChecks',
  'Get-HWOSLeanGuardRegistryState',
  'Get-HWOSLeanGuardSha256',
  'Get-HWOSLeanGuardTextSha256',
  'Read-HWOSLeanGuardJson',
  'Restore-HWOSLeanGuardRegistryState',
  'Set-HWOSLeanGuardAcls',
  'Test-HWOSLeanGuardAdministrator',
  'Write-HWOSLeanGuardJson'
)
