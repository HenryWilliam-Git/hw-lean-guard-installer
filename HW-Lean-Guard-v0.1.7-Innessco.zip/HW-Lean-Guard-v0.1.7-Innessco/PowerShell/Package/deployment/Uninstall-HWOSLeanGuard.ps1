[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode',
  [string]$ExpectedLeanGuardRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$ExpectedPersonalContextRoot = 'C:\Program Files\HenryWilliam\PersonalContext'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
$statePath = Join-Path $StateRoot 'state\install-state.json'
if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Installed state receipt is missing; refusing an unbounded uninstall.' }
$state = Read-HWOSLeanGuardJson -Path $statePath
if ([string]$state.schemaVersion -cne 'hw-os-lean-guard-state/v2') { throw 'A v2 install receipt is required for the two-root uninstall.' }
$preview = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-uninstall-preview/v2'
  applyRequested = [bool]$Apply
  installRoots = $state.installRoots
  restoreSnapshot = [string]$state.rollbackReceiptPath
  userAppDataRetained = $true
  installReceiptRemoved = $true
  machineEvidenceRetained = $true
}
$null = Assert-HWOSLeanGuardUninstallTargets -State $state -StatePath $statePath -PolicyRegistryPath $PolicyRegistryPath -ExpectedLeanGuardRoot $ExpectedLeanGuardRoot -ExpectedPersonalContextRoot $ExpectedPersonalContextRoot
if (-not $Apply) { $preview | ConvertTo-Json -Depth 10; return }
if (-not (Test-HWOSLeanGuardAdministrator)) { throw 'Apply requires an elevated Administrator PowerShell.' }
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
if (@($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'Installed state has drifted; refusing compare-and-swap rollback.' }
$leanRoot = [IO.Path]::GetFullPath([string]$state.installRoots.leanGuard)
$personalRoot = [IO.Path]::GetFullPath([string]$state.installRoots.personalContext)
if (-not $leanRoot.Equals([IO.Path]::GetFullPath($ExpectedLeanGuardRoot), [StringComparison]::OrdinalIgnoreCase)) { throw 'Lean Guard install root is outside the authorised uninstall target.' }
if (-not $personalRoot.Equals([IO.Path]::GetFullPath($ExpectedPersonalContextRoot), [StringComparison]::OrdinalIgnoreCase)) { throw 'Personal Context install root is outside the authorised uninstall target.' }
if (-not $PSCmdlet.ShouldProcess("$leanRoot; $personalRoot", 'Restore prior bootstrap and remove the two exact machine roots while retaining every user AppData store')) { return }

Remove-HWOSLeanGuardMachineInstall -State $state -StatePath $statePath -PolicyRegistryPath $PolicyRegistryPath -ExpectedLeanGuardRoot $ExpectedLeanGuardRoot -ExpectedPersonalContextRoot $ExpectedPersonalContextRoot
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss-fff')
$evidence = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-evidence/v2'
  capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
  packageVersion = [string]$state.packageVersion
  checks = [ordered]@{ leanGuardRootRemoved = -not (Test-Path -LiteralPath $leanRoot); personalContextRootRemoved = -not (Test-Path -LiteralPath $personalRoot); installReceiptRemoved = -not (Test-Path -LiteralPath $statePath); priorRegistryStateRestored = $true; userAppDataRetained = $true }
  result = 'PASS'
}
Write-HWOSLeanGuardJson -Path (Join-Path $StateRoot "evidence\uninstall-$stamp.json") -Value $evidence
$evidence | ConvertTo-Json -Depth 10
