function Test-HWOSLeanGuardDotNetPrerequisite {
  param([AllowNull()][string[]]$RuntimeList, [string]$RuntimeArchitecture, [string]$DotNetPath = 'C:\Program Files\dotnet\dotnet.exe')
  if ($null -eq $RuntimeList) {
    if (-not (Test-Path -LiteralPath $DotNetPath -PathType Leaf)) { return $false }
    $runtimeInfo = @(& $DotNetPath --info 2>$null)
    if ($LASTEXITCODE -ne 0) { return $false }
    $RuntimeArchitecture = if (@($runtimeInfo | Where-Object { $_ -match '^\s*Architecture:\s*x64\s*$' }).Count -gt 0) { 'x64' } else { '' }
    $RuntimeList = @(& $DotNetPath --list-runtimes 2>$null)
    if ($LASTEXITCODE -ne 0) { return $false }
  }
  return $RuntimeArchitecture -ceq 'x64' -and @($RuntimeList | Where-Object { $_ -match '^Microsoft\.NETCore\.App\s+8\.0\.30(?:\s|$)' }).Count -gt 0
}

function Test-HWOSLeanGuardReceiptUpgradePrestate {
  param([Parameter(Mandatory = $true)][object]$State)
  return [string]$State.schemaVersion -cin @('hw-os-lean-guard-state/v1', 'hw-os-lean-guard-state/v2')
}

function Get-HWOSLeanGuardInstalledChecks {
  param([string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard', [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode', [AllowNull()][string[]]$DotNetRuntimeList, [string]$DotNetRuntimeArchitecture)
  $statePath = Join-Path $StateRoot 'state\install-state.json'
  $checks = [ordered]@{ statePresent = Test-Path -LiteralPath $statePath -PathType Leaf; receiptVersionMatch = $false; packageVersionMatch = $false; runtimePrerequisiteMatch = $false; registrySettingsMatch = $false; managedSettingsCandidateMatch = $false; installedFilesMatch = $false }
  if (-not $checks.statePresent) { return $checks }
  try {
    $state = Read-HWOSLeanGuardJson -Path $statePath
    $checks.receiptVersionMatch = [string]$state.schemaVersion -ceq 'hw-os-lean-guard-state/v2'
    if (-not $checks.receiptVersionMatch) { return $checks }
    $checks.packageVersionMatch = [string]$state.packageVersion -ceq '0.1.7'
    $checks.runtimePrerequisiteMatch = [string]$state.runtimePrerequisites.dotnetVersion -ceq '8.0.30' -and [string]$state.runtimePrerequisites.dotnetArchitecture -ceq 'x64' -and (Test-HWOSLeanGuardDotNetPrerequisite -RuntimeList $DotNetRuntimeList -RuntimeArchitecture $DotNetRuntimeArchitecture)
    Assert-HWOSLeanGuardSafeDestination -Path @([string]$state.installRoots.leanGuard, [string]$state.installRoots.personalContext, $StateRoot)
    $registry = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
    $checks.registrySettingsMatch = [string]$state.policyRegistryPath -ceq $PolicyRegistryPath -and $registry.valueExists -and (Get-HWOSLeanGuardTextSha256 -Text ([string]$registry.value)) -ceq [string]$state.bootstrapSha256
    $candidatePath = Join-Path ([string]$state.installRoots.leanGuard) 'policy\server-managed-settings.json'
    $checks.managedSettingsCandidateMatch = (Test-Path -LiteralPath $candidatePath -PathType Leaf) -and (Get-HWOSLeanGuardSha256 -Path $candidatePath) -ceq [string]$state.managedSettingsCandidateSha256
    $checks.installedFilesMatch = (Test-HWOSLeanGuardRecordedFiles -Root ([string]$state.installRoots.leanGuard) -Files $state.files.leanGuard) -and (Test-HWOSLeanGuardRecordedFiles -Root ([string]$state.installRoots.personalContext) -Files $state.files.personalContext)
  } catch { }
  return $checks
}

function Assert-HWOSLeanGuardUninstallTargets {
  param([Parameter(Mandatory = $true)][object]$State, [Parameter(Mandatory = $true)][string]$StatePath, [Parameter(Mandatory = $true)][string]$PolicyRegistryPath, [string]$ExpectedLeanGuardRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard', [string]$ExpectedPersonalContextRoot = 'C:\Program Files\HenryWilliam\PersonalContext')
  if ([string]$State.schemaVersion -cne 'hw-os-lean-guard-state/v2') { throw 'A v2 install receipt is required for the two-root uninstall.' }
  $stateRoot = Split-Path -Parent (Split-Path -Parent ([IO.Path]::GetFullPath($StatePath)))
  if (-not ([IO.Path]::GetFullPath($StatePath)).Equals((Join-Path $stateRoot 'state\install-state.json'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Install receipt is outside the authorised state target.' }
  $leanRoot = [IO.Path]::GetFullPath([string]$State.installRoots.leanGuard).TrimEnd('\')
  $personalRoot = [IO.Path]::GetFullPath([string]$State.installRoots.personalContext).TrimEnd('\')
  if (-not $leanRoot.Equals([IO.Path]::GetFullPath($ExpectedLeanGuardRoot).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Lean Guard install root is outside the authorised uninstall target.' }
  if (-not $personalRoot.Equals([IO.Path]::GetFullPath($ExpectedPersonalContextRoot).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Personal Context install root is outside the authorised uninstall target.' }
  Assert-HWOSLeanGuardSafeDestination -Path @($leanRoot, $personalRoot, $stateRoot)
  if ([string]$State.policyRegistryPath -cne $PolicyRegistryPath) { throw 'Policy registry target does not match the install receipt.' }
  $rollbackRoot = Join-Path $stateRoot 'rollback'
  $rollback = [IO.Path]::GetFullPath([string]$State.rollbackReceiptPath)
  if (-not (Split-Path -Parent $rollback).Equals($rollbackRoot, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $rollback) -notmatch '^prestate-[a-zA-Z0-9-]+\.json$') { throw 'Rollback receipt is outside the authorised rollback target.' }
  Assert-HWOSLeanGuardSafeTree -Root $rollback
  $preState = Read-HWOSLeanGuardJson -Path $rollback
  if ([string]$preState.policyRegistryPath -cne $PolicyRegistryPath) { throw 'Rollback registry target does not match the install receipt.' }
  return $preState
}

function Remove-HWOSLeanGuardMachineInstall {
  param([Parameter(Mandatory = $true)][object]$State, [Parameter(Mandatory = $true)][string]$StatePath, [Parameter(Mandatory = $true)][string]$PolicyRegistryPath, [string]$ExpectedLeanGuardRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard', [string]$ExpectedPersonalContextRoot = 'C:\Program Files\HenryWilliam\PersonalContext')
  $preState = Assert-HWOSLeanGuardUninstallTargets @PSBoundParameters
  $registry = Get-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath
  if (-not $registry.valueExists -or (Get-HWOSLeanGuardTextSha256 -Text ([string]$registry.value)) -cne [string]$State.bootstrapSha256 -or -not (Test-HWOSLeanGuardRecordedFiles -Root $State.installRoots.leanGuard -Files $State.files.leanGuard) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $State.installRoots.personalContext -Files $State.files.personalContext)) { throw 'Installed state has drifted; refusing compare-and-swap rollback.' }
  Invoke-HWOSLeanGuardUninstallTransaction -Roots @([string]$State.installRoots.leanGuard, [string]$State.installRoots.personalContext) -StatePath $StatePath -PolicyRegistryPath $PolicyRegistryPath -PriorRegistry $preState.registry -ImmediateRegistry $registry
}
