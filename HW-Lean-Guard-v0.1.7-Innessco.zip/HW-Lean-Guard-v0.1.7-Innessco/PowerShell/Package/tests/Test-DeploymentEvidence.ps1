param([Parameter(Mandatory = $true)][object]$Evidence)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$schema = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $PSScriptRoot) 'contracts\evidence.schema.json')) | ConvertFrom-Json -ErrorAction Stop
$actualNames = @($Evidence.PSObject.Properties.Name)
foreach ($required in $schema.required) { if ($actualNames -cnotcontains $required) { throw "Evidence required field missing: $required" } }
foreach ($property in $Evidence.PSObject.Properties) {
  if (@($schema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Evidence has an uncontracted field: $($property.Name)" }
  $rule = $schema.properties.($property.Name)
  $constraints = @($rule.PSObject.Properties.Name)
  if ($constraints -contains 'const' -and $property.Value -cne $rule.const) { throw "Evidence constant mismatch: $($property.Name)" }
  if ($constraints -contains 'enum' -and $rule.enum -cnotcontains $property.Value) { throw "Evidence enum mismatch: $($property.Name)" }
  if ($constraints -contains 'format') {
    $parsedDate = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse([string]$property.Value, [ref]$parsedDate)) { throw 'Evidence timestamp is invalid.' }
  }
}
$checkProperties = @($Evidence.checks.PSObject.Properties)
if ($checkProperties.Count -lt $schema.properties.checks.minProperties) { throw 'Evidence checks are empty.' }
foreach ($check in $checkProperties) { if ($check.Value -isnot [bool]) { throw "Evidence check is not boolean: $($check.Name)" } }
if ($Evidence.result -ceq 'PASS' -and @($checkProperties | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'PASS evidence contains a failed check.' }
if ($actualNames -contains 'removal') {
  $removalSchema = $schema.properties.removal
  foreach ($required in $removalSchema.required) { if (@($Evidence.removal.PSObject.Properties.Name) -cnotcontains $required) { throw "Removal evidence required field missing: $required" } }
  foreach ($property in $Evidence.removal.PSObject.Properties) { if (@($removalSchema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Removal evidence has an uncontracted field: $($property.Name)" } }
  if ($removalSchema.properties.status.enum -cnotcontains $Evidence.removal.status -or $Evidence.removal.cleanupPending -isnot [bool] -or $Evidence.removal.retainedPaths -isnot [array] -or [string]::IsNullOrWhiteSpace($Evidence.removal.recoveryJournalPath)) { throw 'Removal evidence is invalid.' }
  foreach ($path in $Evidence.removal.retainedPaths) { if ($path -isnot [string] -or [string]::IsNullOrWhiteSpace($path)) { throw 'Retained quarantine path is invalid.' } }
  if ($Evidence.removal.cleanupPending -ne ($Evidence.removal.status -ceq 'removed-cleanup-pending') -or ($Evidence.result -ceq 'PASS' -and ($Evidence.removal.cleanupPending -or $Evidence.removal.retainedPaths.Count -gt 0))) { throw 'Removal evidence contradicts its cleanup state.' }
}
