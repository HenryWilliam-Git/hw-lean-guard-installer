param([Parameter(Mandatory = $true)][object]$Evidence)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$schema = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $PSScriptRoot) 'contracts\evidence.schema.json')) | ConvertFrom-Json -ErrorAction Stop
$actualNames = @($Evidence.PSObject.Properties.Name)
foreach ($required in $schema.required) { if ($actualNames -cnotcontains $required) { throw "Evidence required field missing: $required" } }
foreach ($property in $Evidence.PSObject.Properties) {
  if (@($schema.properties.PSObject.Properties.Name) -cnotcontains $property.Name) { throw "Evidence has an uncontracted field: $($property.Name)" }
  $rule = $schema.properties.($property.Name)
  $constraints = @($rule.PSObject.Properties.Name)
  if ($constraints -contains 'const' -and $property.Value -cne $rule.const) { throw "Evidence constant mismatch: $($property.Name)" }
  if ($constraints -contains 'enum' -and $rule.enum -cnotcontains $property.Value) { throw "Evidence enum mismatch: $($property.Name)" }
  if ($constraints -contains 'format') {
    $parsedDate = [DateTimeOffset]::MinValue
    if (-not [DateTimeOffset]::TryParse([string]$property.Value, [ref]$parsedDate)) { throw 'Evidence timestamp is invalid.' }
  }
}
$checkProperties = @($Evidence.checks.PSObject.Properties)
if ($checkProperties.Count -lt $schema.properties.checks.minProperties) { throw 'Evidence checks are empty.' }
foreach ($check in $checkProperties) { if ($check.Value -isnot [bool]) { throw "Evidence check is not boolean: $($check.Name)" } }
if ($Evidence.result -ceq 'PASS' -and @($checkProperties | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'PASS evidence contains a failed check.' }
