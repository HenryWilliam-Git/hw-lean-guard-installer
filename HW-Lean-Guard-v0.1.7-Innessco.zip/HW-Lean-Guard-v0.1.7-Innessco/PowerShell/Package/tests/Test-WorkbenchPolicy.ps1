$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

$root = Split-Path -Parent $PSScriptRoot
$configurator = Join-Path $root 'deployment\Configure-HWOSClaudeWorkbench.ps1'
if (-not (Test-Path -LiteralPath $configurator -PathType Leaf)) { throw 'Workbench policy configurator is missing.' }
$tokens = $null
$errors = $null
[void][Management.Automation.Language.Parser]::ParseFile($configurator, [ref]$tokens, [ref]$errors)
if ($errors.Count -gt 0) { throw "PowerShell parse error in Workbench configurator: $($errors[0].Message)" }

$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardWorkbenchTests-" + [Guid]::NewGuid().ToString('N'))))
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
if (-not $sandbox.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Workbench test sandbox escaped the temporary directory.' }
$desktop = Join-Path $sandbox 'Desktop Known Folder'
$userState = Join-Path $sandbox 'User State'
$registryTestRoot = 'HKCU:\SOFTWARE\HWOSLeanGuardWorkbenchTests'
$registryBase = Join-Path $registryTestRoot ([Guid]::NewGuid().ToString('N'))
$userPolicy = Join-Path $registryBase 'User'
$machinePolicy = Join-Path $registryBase 'Machine'
$workbench = Join-Path $desktop 'Claude Workbench'
$priorValue = 'C:\Previous Claude Workspace'
$removalPolicy = Join-Path $registryBase 'RemovalFailure'
$removalState = Join-Path $sandbox 'Removal Failure State'

try {
  [IO.Directory]::CreateDirectory($desktop) | Out-Null
  $preview = & $configurator -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($preview.applyRequested -ne $false -or $preview.restoreRequested -ne $false -or $preview.workbenchRoot -cne $workbench -or $preview.policyValueKind -cne 'MultiString' -or $preview.machinePolicyConflict -ne $false) {
    throw 'Workbench policy preview contract is invalid.'
  }
  if (Test-Path -LiteralPath $workbench) { throw 'Workbench preview created the folder.' }
  if (Test-Path -LiteralPath $userPolicy) { throw 'Workbench preview created the user policy.' }

  New-Item -Path $machinePolicy -Force | Out-Null
  New-ItemProperty -LiteralPath $machinePolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@('C:\Conflicting Machine Workspace')) -PropertyType MultiString -Force | Out-Null
  $conflictPreview = & $configurator -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($conflictPreview.machinePolicyConflict -ne $true) { throw 'Conflicting machine policy was not detected.' }
  $conflictFailure = $null
  try {
    & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch {
    $conflictFailure = $_.Exception.Message
  }
  if ($conflictFailure -cne 'A conflicting machine-level allowedWorkspaceFolders policy overrides the current-user policy.') {
    throw 'Workbench configurator did not fail closed on a conflicting machine policy.'
  }
  Remove-Item -LiteralPath $machinePolicy -Recurse -Force

  New-Item -Path $userPolicy -Force | Out-Null
  New-ItemProperty -LiteralPath $userPolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@($priorValue)) -PropertyType MultiString -Force | Out-Null
  $applyResult = & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  if ($applyResult.result -cne 'PASS' -or $applyResult.policyExact -ne $true -or $applyResult.workbenchExists -ne $true -or $applyResult.policyValueKind -cne 'MultiString') {
    throw 'Workbench policy application did not pass exact readback.'
  }
  $key = Get-Item -LiteralPath $userPolicy
  $value = [string[]]@($key.GetValue('allowedWorkspaceFolders', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames))
  if ($key.GetValueKind('allowedWorkspaceFolders').ToString() -cne 'MultiString' -or $value.Count -ne 1 -or $value[0] -cne $workbench) {
    throw 'Workbench user policy registry readback is not exact.'
  }

  $statePath = Join-Path $userState 'state\workbench-policy-prestate.json'
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Workbench policy prestate was not written.' }
  $prestateHash = (Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant()
  New-ItemProperty -LiteralPath $userPolicy -Name 'allowedWorkspaceFolders' -Value ([string[]]@('C:\Drifted Workspace')) -PropertyType MultiString -Force | Out-Null
  & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  if ((Get-FileHash -LiteralPath $statePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $prestateHash) { throw 'Repeat apply overwrote the original Workbench policy prestate.' }

  $prestateBytes = [IO.File]::ReadAllBytes($statePath)
  [IO.File]::WriteAllText($statePath, '{"tampered":true}', [Text.UTF8Encoding]::new($false))
  $tamperFailure = $null
  try {
    & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $applyResult.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch { $tamperFailure = $_.Exception.Message }
  if ($tamperFailure -cne 'Workbench policy prestate SHA-256 mismatch.') { throw 'Workbench policy restore accepted a tampered prestate.' }
  [IO.File]::WriteAllBytes($statePath, $prestateBytes)
  $restoreResult = & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $applyResult.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | ConvertFrom-Json -ErrorAction Stop
  $restoredKey = Get-Item -LiteralPath $userPolicy
  $restoredValue = [string[]]@($restoredKey.GetValue('allowedWorkspaceFolders', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames))
  if ($restoreResult.result -cne 'PASS' -or $restoreResult.workbenchRetained -ne $true -or $restoredKey.GetValueKind('allowedWorkspaceFolders').ToString() -cne 'MultiString' -or $restoredValue.Count -ne 1 -or $restoredValue[0] -cne $priorValue) {
    throw 'Workbench policy restore did not preserve the folder and restore the prior user policy.'
  }

  New-Item -Path $removalPolicy -Force | Out-Null
  $removalApply = & $configurator -Apply -Confirm:$false -DesktopPath $desktop -PolicyRegistryPath $removalPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $removalState | ConvertFrom-Json -ErrorAction Stop
  $removalSubKey = $removalPolicy.Substring('HKCU:\'.Length)
  $aclRights = [Security.AccessControl.RegistryRights]::ReadPermissions -bor [Security.AccessControl.RegistryRights]::ChangePermissions
  $removalKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($removalSubKey, [Microsoft.Win32.RegistryKeyPermissionCheck]::ReadWriteSubTree, $aclRights)
  if ($null -eq $removalKey) { throw 'Removal-failure test could not open its policy key.' }
  $blockedRemovalAcl = $removalKey.GetAccessControl()
  $denySetValue = [Security.AccessControl.RegistryAccessRule]::new(
    [Security.Principal.WindowsIdentity]::GetCurrent().User,
    [Security.AccessControl.RegistryRights]::SetValue,
    [Security.AccessControl.InheritanceFlags]::None,
    [Security.AccessControl.PropagationFlags]::None,
    [Security.AccessControl.AccessControlType]::Deny
  )
  [void]$blockedRemovalAcl.AddAccessRule($denySetValue)
  $removalKey.SetAccessControl($blockedRemovalAcl)
  $removalFailure = $null
  try {
    & $configurator -Restore -Confirm:$false -ExpectedPrestateSha256 $removalApply.prestateSha256 -DesktopPath $desktop -PolicyRegistryPath $removalPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $removalState | Out-Null
  } catch {
    $removalFailure = $_.Exception.Message
  } finally {
    $restoredRemovalAcl = $removalKey.GetAccessControl()
    [void]$restoredRemovalAcl.RemoveAccessRuleSpecific($denySetValue)
    $removalKey.SetAccessControl($restoredRemovalAcl)
    $removalKey.Dispose()
  }
  if ([string]::IsNullOrWhiteSpace($removalFailure)) { throw 'Workbench policy restore swallowed a registry removal failure.' }

  $relativeFailure = $null
  try {
    & $configurator -DesktopPath 'relative\Desktop' -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null
  } catch {
    $relativeFailure = $_.Exception.Message
  }
  if ($relativeFailure -cne 'The signed-in user Desktop Known Folder must resolve to a non-empty rooted path.') {
    throw 'Workbench configurator accepted a relative Desktop path.'
  }

  $protectedFailure = $null
  try { & $configurator -DesktopPath 'L:\LeanGuard-Test-Desktop' -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null } catch { $protectedFailure = $_.Exception.Message }
  if ($protectedFailure -cne 'The resolved Claude Workbench path intersects a protected root.') { throw 'Workbench configurator accepted a protected-root Desktop path.' }

  $junctionTarget = Join-Path $sandbox 'Junction Target'
  $junctionDesktop = Join-Path $sandbox 'Junction Desktop'
  [IO.Directory]::CreateDirectory($junctionTarget) | Out-Null
  New-Item -ItemType Junction -Path $junctionDesktop -Target $junctionTarget | Out-Null
  $reparseFailure = $null
  try { & $configurator -DesktopPath $junctionDesktop -PolicyRegistryPath $userPolicy -MachinePolicyRegistryPath $machinePolicy -UserStateRoot $userState | Out-Null } catch { $reparseFailure = $_.Exception.Message }
  if ($reparseFailure -cne 'The resolved Claude Workbench path contains a redirecting reparse point.') { throw 'Workbench configurator accepted a redirecting reparse-backed Desktop path.' }
} finally {
  $registryBaseSubKey = $registryBase.Substring('HKCU:\'.Length)
  if (-not $registryBaseSubKey.StartsWith('SOFTWARE\HWOSLeanGuardWorkbenchTests\', [StringComparison]::OrdinalIgnoreCase)) {
    throw 'Workbench test registry cleanup target escaped its test root.'
  }
  [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKeyTree($registryBaseSubKey, $true)
  $registryTestSubKey = $registryTestRoot.Substring('HKCU:\'.Length)
  $rootKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey($registryTestSubKey, $true)
  if ($null -ne $rootKey) {
    $deleteTestRoot = $rootKey.ValueCount -eq 0 -and $rootKey.SubKeyCount -eq 0
    $rootKey.Dispose()
    if ($deleteTestRoot) { [Microsoft.Win32.Registry]::CurrentUser.DeleteSubKey($registryTestSubKey, $false) }
  }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}

Write-Output 'PASS: Workbench preview, conflict/reparse/protected-root gates, MultiString apply, authenticated restore, and cleanup'
