$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$package = Split-Path -Parent $PSScriptRoot
$deployment = Join-Path $package 'deployment'
$sandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ('HWOSLeanGuardLifecycle-' + [Guid]::NewGuid().ToString('N'))))
$registryPath = 'HKCU:\SOFTWARE\HWOSLeanGuardTests\' + [Guid]::NewGuid().ToString('N')
$stateRoot = Join-Path $sandbox 'state-root'
$leanRoot = Join-Path $sandbox 'machine\lean'
$personalRoot = Join-Path $sandbox 'machine\personal'
$statePath = Join-Path $stateRoot 'state\install-state.json'
$global:HWOSDeploymentLifecycleInjectFailure = $false
function Import-Module {
  param([Parameter(Position=0)][object]$Name, [switch]$Force)
  Microsoft.PowerShell.Core\Import-Module -Name $Name -Force:$Force -Global
  $module = Get-Module 'HWOSLeanGuard.Deployment'
  & $module {
    param($InjectFailure)
    $script:LifecycleInjectFailure = $InjectFailure
    function script:Test-HWOSLeanGuardAdministrator { return $true }
    function script:Test-HWOSLeanGuardDotNetPrerequisite { return $true }
    function script:Set-HWOSLeanGuardTreeAcls { param($Root,$Grants,$FailureLabel) }
    function script:Set-HWOSLeanGuardAcls { param($InstallRoot,$PersonalContextRoot,$StateRoot) if ($script:LifecycleInjectFailure) { throw 'injected-install-finalization' } }
    Export-ModuleMember -Function Test-HWOSLeanGuardAdministrator,Test-HWOSLeanGuardDotNetPrerequisite,Set-HWOSLeanGuardAcls
  } $global:HWOSDeploymentLifecycleInjectFailure
  function global:Test-HWOSLeanGuardAdministrator { return $true }
  function global:Test-HWOSLeanGuardDotNetPrerequisite { return $true }
  function global:Set-HWOSLeanGuardAcls { param($InstallRoot,$PersonalContextRoot,$StateRoot) if ($global:HWOSDeploymentLifecycleInjectFailure) { throw 'injected-install-finalization' } }
}
function Invoke-FixtureInstall {
  & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $package -InstallRoot $leanRoot -PersonalContextInstallRoot $personalRoot -StateRoot $stateRoot -PolicyRegistryPath $registryPath | ConvertFrom-Json -ErrorAction Stop
}
function Assert-LifecycleFailure {
  param([scriptblock]$Action, [string]$Pattern)
  $failure = $null
  try { & $Action | Out-Null } catch { $failure = $_.Exception.Message }
  if ($null -eq $failure -or $failure -notlike $Pattern) { throw "Expected '$Pattern', got '$failure'." }
}
try {
  New-Item -Path $registryPath -Force | Out-Null
  New-ItemProperty -LiteralPath $registryPath -Name Settings -Value 'original-policy' -PropertyType ExpandString -Force | Out-Null
  $installed = Invoke-FixtureInstall
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $installed
  $invalidEvidence = $installed.PSObject.Copy()
  $invalidEvidence | Add-Member -MemberType NoteProperty -Name unexpected -Value $false
  Assert-LifecycleFailure { & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $invalidEvidence } '*uncontracted field*'
  if ($installed.result -cne 'PASS') { throw 'Fresh sandbox install failed.' }
  $receipt = Read-HWOSLeanGuardJson -Path $statePath
  if ($receipt.schemaVersion -cne 'hw-os-lean-guard-state/v2' -or $receipt.packageVersion -cne '0.1.7' -or $receipt.runtimePrerequisites.dotnetArchitecture -cne 'x64') { throw 'Fresh install receipt is incomplete.' }
  if (-not (Test-Path -LiteralPath (Join-Path $leanRoot 'deployment\Configure-HWOSClaudeWorkbench.ps1'))) { throw 'Workbench restore configurator was omitted from the machine install.' }
  $nativeFiles = @($receipt.files.personalContext.PSObject.Properties | Where-Object Name -Match 'e_sqlite3\.dll$')
  if ($nativeFiles.Count -eq 0) { throw 'Personal Context native SQLite DLL is missing from the receipt.' }
  $nativePath = Join-Path $personalRoot $nativeFiles[0].Name
  $nativeBytes = [IO.File]::ReadAllBytes($nativePath)
  try {
    Remove-Item -LiteralPath $nativePath -Force
    if ((Get-HWOSLeanGuardInstalledChecks -StateRoot $stateRoot -PolicyRegistryPath $registryPath).installedFilesMatch) { throw 'Detector accepted a missing native DLL.' }
  } finally { [IO.File]::WriteAllBytes($nativePath, $nativeBytes) }
  $extraPath = Join-Path $personalRoot 'unexpected.dll'
  try {
    [IO.File]::WriteAllText($extraPath, 'unexpected')
    if ((Get-HWOSLeanGuardInstalledChecks -StateRoot $stateRoot -PolicyRegistryPath $registryPath).installedFilesMatch) { throw 'Detector accepted an additional installed DLL.' }
  } finally { Remove-Item -LiteralPath $extraPath -Force }
  $priorReceiptHash = Get-HWOSLeanGuardSha256 -Path $statePath
  $global:HWOSDeploymentLifecycleInjectFailure = $true
  Assert-LifecycleFailure { Invoke-FixtureInstall } '*injected-install-finalization*'
  if ((Get-HWOSLeanGuardSha256 -Path $statePath) -cne $priorReceiptHash -or -not (Test-HWOSLeanGuardRecordedFiles -Root $leanRoot -Files $receipt.files.leanGuard) -or -not (Test-HWOSLeanGuardRecordedFiles -Root $personalRoot -Files $receipt.files.personalContext)) { throw 'Failed reinstall did not restore exact trees and receipt bytes.' }
  $registry = Get-HWOSLeanGuardRegistryState -Path $registryPath
  if ((Get-HWOSLeanGuardTextSha256 -Text $registry.value) -cne $receipt.bootstrapSha256) { throw 'Failed reinstall did not restore immediate registry state.' }
  $global:HWOSDeploymentLifecycleInjectFailure = $false

  $retained = Join-Path $sandbox 'user-appdata\HenryWilliam\PersonalContext\user-sid'
  [IO.Directory]::CreateDirectory($retained) | Out-Null
  foreach ($name in @('personal-context.db','content-entropy.bin','search-key.bin','personal-context-index.db')) { [IO.File]::WriteAllText((Join-Path $retained $name), 'retain-' + $name) }
  $userHashes = Get-HWOSLeanGuardFileHashes -Root $retained
  $badReceipt = Read-HWOSLeanGuardJson -Path $statePath
  $badReceipt.installRoots.personalContext = $retained
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $badReceipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*outside the authorised uninstall target*'
  $badReceipt.installRoots.personalContext = $personalRoot
  $badReceipt.rollbackReceiptPath = Join-Path $sandbox 'unbounded.json'
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $badReceipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*outside the authorised rollback target*'
  if ((Get-HWOSLeanGuardSha256 -Path $statePath) -cne $priorReceiptHash) { throw 'Rejected uninstall mutated the receipt.' }
  $childJunction = Join-Path $personalRoot 'redirect'
  New-Item -ItemType Junction -Path $childJunction -Target $retained | Out-Null
  Assert-LifecycleFailure { Remove-HWOSLeanGuardMachineInstall -State $receipt -StatePath $statePath -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot } '*reparse*'
  [IO.Directory]::Delete($childJunction)
  $result = & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | ConvertFrom-Json -ErrorAction Stop
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $result
  if ($result.result -cne 'PASS' -or (Test-Path -LiteralPath $statePath) -or (Test-Path -LiteralPath $leanRoot) -or (Test-Path -LiteralPath $personalRoot)) { throw 'Sandbox uninstall did not remove exact machine state.' }
  if (-not (Test-HWOSLeanGuardRecordedFiles -Root $retained -Files ([pscustomobject]$userHashes))) { throw 'Uninstall changed per-user stores.' }
  $restored = Get-HWOSLeanGuardRegistryState -Path $registryPath
  if ($restored.value -cne 'original-policy' -or $restored.valueKind -cne 'ExpandString') { throw 'Uninstall did not restore exact original policy value and kind.' }

  [IO.Directory]::CreateDirectory($leanRoot) | Out-Null
  [IO.File]::WriteAllText((Join-Path $leanRoot 'v1.txt'), 'v1-runtime')
  $v1Rollback = Join-Path $stateRoot 'rollback\prestate-v1.json'
  Write-HWOSLeanGuardJson -Path $v1Rollback -Value @{policyRegistryPath=$registryPath; registry=@{keyExists=$true;valueExists=$true;valueKind='String';value='before-v1'}}
  Write-HWOSLeanGuardJson -Path $statePath -Value @{schemaVersion='hw-os-lean-guard-state/v1';installRoot=$leanRoot;policyRegistryPath=$registryPath;preStatePath=$v1Rollback}
  $upgrade = Invoke-FixtureInstall
  & (Join-Path $PSScriptRoot 'Test-DeploymentEvidence.ps1') -Evidence $upgrade
  if ($upgrade.result -cne 'PASS' -or (Test-Path -LiteralPath (Join-Path $leanRoot 'v1.txt'))) { throw 'v1 upgrade did not replace the old runtime.' }
  $upgraded = Read-HWOSLeanGuardJson -Path $statePath
  $upgradePrestate = Read-HWOSLeanGuardJson -Path $upgraded.rollbackReceiptPath
  if ($upgradePrestate.registry.value -cne 'before-v1' -or $upgradePrestate.priorReceipt.schemaVersion -cne 'hw-os-lean-guard-state/v1') { throw 'Upgrade did not retain original uninstall policy and v1 receipt.' }
  & (Join-Path $deployment 'Uninstall-HWOSLeanGuard.ps1') -Apply -Confirm:$false -StateRoot $stateRoot -PolicyRegistryPath $registryPath -ExpectedLeanGuardRoot $leanRoot -ExpectedPersonalContextRoot $personalRoot | Out-Null
  if ((Get-HWOSLeanGuardRegistryState -Path $registryPath).value -cne 'before-v1') { throw 'Upgraded uninstall restored the wrong policy.' }
  Write-Output 'PASS: actual installer fresh install, failed reinstall with exact tree/receipt/policy rollback, v1 upgrade, bounded uninstall, original policy restore, retained user stores (Administrator/runtime/ACL mocked)'
} finally {
  Remove-Variable -Name HWOSDeploymentLifecycleInjectFailure -Scope Global -ErrorAction SilentlyContinue
  Remove-Item Function:Import-Module -ErrorAction SilentlyContinue
  foreach ($name in @('Test-HWOSLeanGuardAdministrator','Test-HWOSLeanGuardDotNetPrerequisite','Set-HWOSLeanGuardAcls')) { Remove-Item -LiteralPath "Function:global:$name" -ErrorAction SilentlyContinue }
  Microsoft.PowerShell.Core\Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force -Global
  if (Test-Path -LiteralPath $registryPath) { Remove-Item -LiteralPath $registryPath -Recurse -Force }
  $tempPrefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $sandbox.StartsWith($tempPrefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $sandbox) -notlike 'HWOSLeanGuardLifecycle-*') { throw 'Unsafe lifecycle sandbox cleanup target.' }
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
  foreach ($name in @('Test-HWOSLeanGuardAdministrator','Test-HWOSLeanGuardDotNetPrerequisite','Set-HWOSLeanGuardAcls')) {
    if ((Get-Command $name).ModuleName -cne 'HWOSLeanGuard.Deployment') { throw 'Lifecycle fixture left a mocked deployment export.' }
  }
}
