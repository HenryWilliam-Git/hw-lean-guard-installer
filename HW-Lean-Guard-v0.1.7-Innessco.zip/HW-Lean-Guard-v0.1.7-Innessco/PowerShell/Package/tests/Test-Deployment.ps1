$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$deployment = Join-Path $root 'deployment'
foreach ($file in Get-ChildItem -LiteralPath $deployment -File | Where-Object { $_.Extension -in @('.ps1','.psm1') }) {
  $tokens = $null; $errors = $null
  [void][Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
  if ($errors.Count -gt 0) { throw "PowerShell parse error in $($file.Name): $($errors[0].Message)" }
}
$preview = & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -PackageRoot $root | ConvertFrom-Json -ErrorAction Stop
if ($preview.applyRequested -ne $false -or $preview.serverManagedPolicyConfirmed -ne $false -or $preview.settingsChannel -cne 'remote-refresh-bootstrap-only' -or $preview.sourceDriveAclsChanged -ne $false) { throw 'Install preview contract is unsafe.' }
if ($preview.schemaVersion -cne 'hw-os-lean-guard-install-preview/v2' -or $preview.runtimePrerequisites.dotnetVersion -cne '8.0.30' -or $preview.runtimePrerequisites.dotnetArchitecture -cne 'x64' -or [string]::IsNullOrWhiteSpace($preview.installRoots.personalContext) -or $preview.userAppDataChanged -ne $false) { throw 'Install preview omits the v2 machine root or exact runtime prerequisite.' }
if ($preview.environmentVariablesChanged -ne $false -or $preview.workbenchExclusionsConfigured -ne $false -or $preview.fsLogixConfigured -ne $false) { throw 'Installer must not configure staging environment variables or Workbench/FSLogix exclusions.' }
$deploymentText = @(
  Get-ChildItem -LiteralPath $deployment -File |
    Where-Object { $_.Extension -in @('.ps1','.psm1') } |
    Sort-Object FullName |
    ForEach-Object { [IO.File]::ReadAllText($_.FullName, [Text.Encoding]::UTF8) }
) -join "`n"
$forbiddenDeploymentPatterns = [ordered]@{
  'environment-variable API mutation' = '(?i)\[Environment\]::SetEnvironmentVariable|\bsetx(?:\.exe)?\b'
  'environment registry mutation' = '(?i)(?:HKLM|HKCU):\\(?:SYSTEM\\CurrentControlSet\\Control\\Session Manager\\)?Environment\b|(?:New-ItemProperty|Set-ItemProperty)[^\r\n]+(?:TEMP|TMP|APPDATA|LOCALAPPDATA|USERPROFILE|ONEDRIVE)'
  'FSLogix redirections mutation' = '(?i)(?:New-Item|Set-Content|Copy-Item|Out-File)[^\r\n]+redirections\.xml'
  'hardcoded user profile path' = '(?i)[A-Z]:\\Users\\'
  'staging-specific identity or storage' = '(?i)StagingHarness|jaycho-user-test|jay\.cho\.FSL0|BradAgent|OneDrive - HW Dev|hwdevfiles02|hwlfilesv2'
}
foreach ($entry in $forbiddenDeploymentPatterns.GetEnumerator()) {
  if ($deploymentText -match [string]$entry.Value) { throw "Deployment scripts contain forbidden $($entry.Key)." }
}
$confirmationFailure = $null
try {
  & (Join-Path $deployment 'Install-HWOSLeanGuard.ps1') -Apply -WhatIf -PackageRoot $root | Out-Null
} catch {
  $confirmationFailure = $_.Exception.Message
}
if ($confirmationFailure -cne 'Apply requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).') { throw 'Install did not fail closed before endpoint policy confirmation.' }
$oneCommandInstaller = Join-Path $deployment 'Install-HWOSLeanGuardOneCommand.ps1'
if (-not (Test-Path -LiteralPath $oneCommandInstaller -PathType Leaf)) { throw 'One-command PowerShell installer is missing.' }
$oneCommandPreview = & $oneCommandInstaller -ValidateOnly -PackageRoot $root | ConvertFrom-Json -ErrorAction Stop
if ($oneCommandPreview.installRoots.leanGuard -cne 'C:\Program Files\ClaudeCode\HWOSLeanGuard' -or $oneCommandPreview.installRoots.personalContext -cne 'C:\Program Files\HenryWilliam\PersonalContext' -or $oneCommandPreview.runtimePrerequisites.dotnetVersion -cne '8.0.30' -or $oneCommandPreview.runtimePrerequisites.dotnetArchitecture -cne 'x64') { throw 'One-command preview omits the two machine roots or exact prerequisite.' }
if ($oneCommandPreview.applyRequested -ne $false -or $oneCommandPreview.uacRequested -ne $false -or $oneCommandPreview.packageVersion -cne '0.1.7' -or $oneCommandPreview.workbench.policyValueKind -cne 'MultiString' -or $oneCommandPreview.workbench.machinePolicyConflict -ne $false) { throw 'One-command installer validation preview is unsafe.' }
$oneCommandConfirmationFailure = $null
try {
  & $oneCommandInstaller -PackageRoot $root | Out-Null
} catch {
  $oneCommandConfirmationFailure = $_.Exception.Message
}
if ($oneCommandConfirmationFailure -cne 'One-command installation requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).') { throw 'One-command installer did not fail closed before endpoint policy confirmation.' }
$oneCommandSource = [IO.File]::ReadAllText($oneCommandInstaller, [Text.Encoding]::UTF8)
foreach ($requiredSource in @('Start-Process', '-Verb', 'RunAs', 'Install-HWOSLeanGuard.ps1', 'Get-HWOSLeanGuardInstalledChecks')) {
  if (-not $oneCommandSource.Contains($requiredSource)) { throw "One-command installer is missing required behavior: $requiredSource" }
}
foreach ($secureElevationSource in @('-EncodedCommand', 'expectedManifestSha256', 'secureStageRoot', 'Elevated staged package manifest SHA-256 mismatch.')) {
  if (-not $oneCommandSource.Contains($secureElevationSource)) { throw "One-command installer does not authenticate an admin-only staged package before execution: $secureElevationSource" }
}
if ($oneCommandSource.Contains('-File `"$PSCommandPath`"')) {
  throw 'One-command installer elevates a script directly from the caller-controlled source tree.'
}
$loaderMatch = [regex]::Match($oneCommandSource, '(?s)\$elevatedLoader = @''\r?\n(?<loader>.*?)\r?\n''@')
if (-not $loaderMatch.Success) { throw 'One-command installer secure elevated loader is missing.' }
$testPayload = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('{"sourcePackageRoot":"C:\\test","expectedManifestSha256":"00","expectedPackageVersion":"0.1.7","installRoot":"C:\\test","stateRoot":"C:\\test","policyRegistryPath":"HKLM:\\test"}'))
$loaderText = $loaderMatch.Groups['loader'].Value.Replace('__PAYLOAD_BASE64__', $testPayload)
$loaderTokens = $null
$loaderErrors = $null
[void][Management.Automation.Language.Parser]::ParseInput($loaderText, [ref]$loaderTokens, [ref]$loaderErrors)
if ($loaderErrors.Count -gt 0) { throw "Secure elevated loader PowerShell parse error: $($loaderErrors[0].Message)" }
Import-Module (Join-Path $deployment 'HWOSLeanGuard.Deployment.psm1') -Force
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardDeployTests-" + [Guid]::NewGuid().ToString('N'))
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $sandbox -PolicyRegistryPath 'HKCU:\SOFTWARE\HWOSLeanGuardTests\Absent'
if ($checks.statePresent -ne $false -or $checks.registrySettingsMatch -ne $false -or $checks.installedFilesMatch -ne $false) { throw 'Absent-state detection is not fail closed.' }
$testRegistryPath = "HKCU:\SOFTWARE\HWOSLeanGuardTests\$([Guid]::NewGuid().ToString('N'))"
try {
  New-Item -Path $testRegistryPath -Force | Out-Null
  $registryState = Get-HWOSLeanGuardRegistryState -Path $testRegistryPath
  if ($registryState.keyExists -ne $true -or $registryState.valueExists -ne $false) { throw 'Existing registry key without Settings was not captured correctly.' }
} finally {
  if (Test-Path -LiteralPath $testRegistryPath) { Remove-Item -LiteralPath $testRegistryPath -Recurse -Force }
}
$aclSandbox = [IO.Path]::GetFullPath((Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardAclTests-" + [Guid]::NewGuid().ToString('N'))))
$tempRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
if (-not $aclSandbox.StartsWith($tempRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'ACL sandbox escaped the temporary directory.' }
$aclInstall = Join-Path $aclSandbox 'install'
$aclInstallFile = Join-Path $aclInstall 'runtime\guard.ps1'
$cleanupPrincipal = "${env:USERDOMAIN}\${env:USERNAME}"
try {
  [IO.Directory]::CreateDirectory((Split-Path -Parent $aclInstallFile)) | Out-Null
  [IO.File]::WriteAllText($aclInstallFile, 'guard', [Text.UTF8Encoding]::new($false))
  $deploymentModule = Get-Module 'HWOSLeanGuard.Deployment'
  & $deploymentModule {
    param([string]$InstallRoot)
    Set-HWOSLeanGuardTreeAcls -Root $InstallRoot -Grants @('SYSTEM:(OI)(CI)F', 'BUILTIN\Administrators:(OI)(CI)F', 'BUILTIN\Users:(OI)(CI)RX') -FailureLabel 'ACL regression sandbox'
  } $aclInstall
  $installedText = [IO.File]::ReadAllText($aclInstallFile, [Text.Encoding]::UTF8)
  if ($installedText -cne 'guard') { throw 'Installed runtime child file is not readable after ACL application.' }
} finally {
  if (Test-Path -LiteralPath $aclSandbox) {
    foreach ($cleanupRoot in @($aclInstall)) {
      if (Test-Path -LiteralPath $cleanupRoot) {
        $null = & icacls.exe $cleanupRoot '/grant:r' "${cleanupPrincipal}:(OI)(CI)F" '/C'
        $null = & icacls.exe (Join-Path $cleanupRoot '*') '/reset' '/T' '/C'
      }
    }
    $null = & icacls.exe $aclSandbox '/grant:r' "${cleanupPrincipal}:(OI)(CI)F" '/C'
    Remove-Item -LiteralPath $aclSandbox -Recurse -Force
  }
}
& (Join-Path $PSScriptRoot 'Test-DeploymentV2.ps1')
& (Join-Path $PSScriptRoot 'Test-DeploymentUninstallTransaction.ps1')
& (Join-Path $PSScriptRoot 'Test-DeploymentLifecycle.ps1')
& (Join-Path $PSScriptRoot 'Test-DeploymentElevation.ps1')
Write-Output 'PASS: deployment preview, no-staging-environment contract, one-command elevation, registry prestate, ACL inheritance, and fail-closed detection'
