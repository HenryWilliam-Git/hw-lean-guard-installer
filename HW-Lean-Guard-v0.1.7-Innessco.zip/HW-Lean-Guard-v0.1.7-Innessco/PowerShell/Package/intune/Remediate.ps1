[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$statePath = 'C:\ProgramData\HenryWilliam\LeanGuard\state\install-state.json'
$settingsPath = 'C:\Program Files\ClaudeCode\HWOSLeanGuard\policy\endpoint-bootstrap-settings.json'
$registryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
try {
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf) -or -not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) { exit 1 }
  $state = [IO.File]::ReadAllText($statePath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
  if ([string]$state.schemaVersion -cne 'hw-os-lean-guard-state/v2' -or [string]$state.packageVersion -cne '0.1.7') { exit 1 }
  if (-not [Environment]::Is64BitProcess -or [string]$state.runtimePrerequisites.dotnetVersion -cne '8.0.30' -or [string]$state.runtimePrerequisites.dotnetArchitecture -cne 'x64') { exit 1 }
  $dotnet = 'C:\Program Files\dotnet\dotnet.exe'
  if (-not (Test-Path -LiteralPath $dotnet -PathType Leaf)) { exit 1 }
  $runtimeInfo = @(& $dotnet --info 2>$null)
  if ($LASTEXITCODE -ne 0 -or @($runtimeInfo | Where-Object { $_ -match '^\s*Architecture:\s*x64\s*$' }).Count -eq 0) { exit 1 }
  if ([string]$state.policyRegistryPath -cne $registryPath) { exit 1 }
  $runtimes = @(& $dotnet --list-runtimes 2>$null)
  if ($LASTEXITCODE -ne 0 -or @($runtimes | Where-Object { $_ -match '^Microsoft\.NETCore\.App 8\.0\.30 \[' }).Count -ne 1) { exit 1 }
  $expectedRoots = [ordered]@{
    leanGuard = 'C:\Program Files\ClaudeCode\HWOSLeanGuard'
    personalContext = 'C:\Program Files\HenryWilliam\PersonalContext'
  }
  foreach ($name in $expectedRoots.Keys) {
    $root = [IO.Path]::GetFullPath([string]$state.installRoots.$name).TrimEnd('\')
    if ($root -cne $expectedRoots[$name]) { exit 1 }
    $ancestor = $root
    while (-not [string]::IsNullOrWhiteSpace($ancestor)) {
      if ((Test-Path -LiteralPath $ancestor) -and ((Get-Item -LiteralPath $ancestor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { exit 1 }
      $ancestor = Split-Path -Parent $ancestor
    }
    $entries = @(Get-ChildItem -LiteralPath $root -Recurse -Force)
    if (@($entries | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }).Count -gt 0) { exit 1 }
    $recorded = @($state.files.$name.PSObject.Properties)
    if ($recorded.Count -eq 0 -or @($entries | Where-Object { -not $_.PSIsContainer }).Count -ne $recorded.Count) { exit 1 }
    $seen = @{}
    foreach ($property in $recorded) {
      if ([IO.Path]::IsPathRooted($property.Name) -or $property.Name -match '(^|[\\/])\.\.?([\\/]|$)|:') { exit 1 }
      $path = [IO.Path]::GetFullPath((Join-Path $root $property.Name))
      if (-not $path.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) { exit 1 }
      if ($seen.ContainsKey($path) -or [string]$property.Value -cnotmatch '^[0-9a-f]{64}$') { exit 1 }
      $seen[$path] = $true
      if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { exit 1 }
      if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$property.Value) { exit 1 }
    }
  }
  $candidatePath = Join-Path ([string]$state.installRoots.leanGuard) 'policy\server-managed-settings.json'
  if (-not (Test-Path -LiteralPath $candidatePath -PathType Leaf) -or (Get-FileHash -LiteralPath $candidatePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$state.managedSettingsCandidateSha256) { exit 1 }
  $settings = [IO.File]::ReadAllText($settingsPath, [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
  $hash = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($settings)))).Replace('-', '').ToLowerInvariant()
  if ($hash -cne [string]$state.bootstrapSha256) { exit 1 }
  New-Item -Path $registryPath -Force | Out-Null
  New-ItemProperty -LiteralPath $registryPath -Name 'Settings' -Value $settings -PropertyType String -Force | Out-Null
  & (Join-Path $PSScriptRoot 'Detect.ps1') | Out-Null
  exit $LASTEXITCODE
} catch { exit 1 }
