function Get-HWOSDriveConnection {
 param([string]$Letter)
 if(-not ('HWOSResourceNetwork' -as [type])) {
 Add-Type -TypeDefinition @"
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class HWOSResourceNetwork {
 [DllImport("mpr.dll", CharSet=CharSet.Unicode)]
 public static extern int WNetGetConnection(string local, StringBuilder remote, ref int length);
}
"@
 }
 $length=32768; $buffer=New-Object Text.StringBuilder $length
 $status=[HWOSResourceNetwork]::WNetGetConnection(($Letter+':'),$buffer,[ref]$length)
 if($status -eq 0){return $buffer.ToString()}
 if($status -ne 2250){return '?'}
 $drive=Get-PSDrive -Name $Letter -PSProvider FileSystem -ErrorAction SilentlyContinue
 if($null -ne $drive -and $null -ne $drive.PSObject.Properties['DisplayRoot'] -and $drive.DisplayRoot){return [string]$drive.DisplayRoot}
 try { if(([IO.DriveInfo]::new($Letter+':\')).DriveType -eq [IO.DriveType]::Network){return '?'} } catch { return '?' }
 return $null
}# Submitted resource classifier. Does not mediate child-process or connector I/O.
function Test-HWOSAmbiguousResourceComponent {
  param([string]$Path)
  foreach ($component in @($Path -split '[\\/]')) {
    if ($component -notin @('.','..') -and $component -match '[ .]$') { return $true }
  }
  return $false
}
function Get-HWOSResourcePath {
  param([string]$Value)
  $value = [Environment]::ExpandEnvironmentVariables($Value)
  if (Test-HWOSAmbiguousResourceComponent $value) { return $null }
  if ($value -match '^file:') { try { $value = ([uri]$value).LocalPath } catch { return $null } }
  $value = $value.Replace('/', '\')
  if ($value.StartsWith('\\?\UNC\', [StringComparison]::OrdinalIgnoreCase)) {
    if ($value -notmatch '^\\\\\?\\UNC\\[^\\]+\\[^\\]+(?:\\|$)') { return $null }
    $value = '\\' + $value.Substring(8)
  }
  elseif ($value.StartsWith('\\?\')) {
    if ($value -notmatch '^\\\\\?\\[A-Za-z]:\\') { return $null }
    $value = $value.Substring(4)
  }
  if ($value.StartsWith('\') -and -not $value.StartsWith('\\')) { return $null }
  if (($value -replace '^[A-Za-z]:','').Contains(':')) { return $null }
  if ($value -match '^\\\\[?.]\\' -or $value -match '[$%*?]|~[0-9]' -or $value -match '^[A-Za-z]:[^\\]') { return $null }
  if ($value -match '^([A-Za-z]):\\') {
    $letter = $Matches[1]
    $remote=Get-HWOSDriveConnection $letter
    if($remote -eq '?'){return $null}
    if($remote){$value=$remote.TrimEnd('\')+$value.Substring(2)}
  }  if (-not [IO.Path]::IsPathRooted($value)) {
    $base = [string](Get-HWOSPropertyValue -Object $payload -Names @('cwd'))
    if (-not $base -or $base -notmatch '^(?:[A-Za-z]:[\\/]|[\\/]{2}[^\\/]+[\\/][^\\/]+)') { return $null }
    $base = Get-HWOSResourcePath $base
    if (-not $base) { return $null }
    $value = Join-Path $base $value
  }
  if (Test-HWOSAmbiguousResourceComponent $value) { return $null }
  if (($value -replace '^[A-Za-z]:','').Contains(':')) { return $null }
  try { return [IO.Path]::GetFullPath($value).TrimEnd('\') } catch { return $null }
}
function Test-HWOSResourceHost {
  param([string]$Path)
  if ($Path -match '^\\\\([^\\]+)(?:\\|$)') {
    $hostName = $Matches[1].TrimEnd('.')
    return $hostName -in @($policy.blockedResourceHosts)
  }
  return $false
}
function Test-HWOSResourceBoundary {
  param([string]$Path,[string]$Root)
  return $Path.Equals($Root,[StringComparison]::OrdinalIgnoreCase) -or $Path.StartsWith($Root.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)
}
function Get-HWOSSystemRoots {
  @([Environment]::GetFolderPath('Windows'), [Environment]::GetFolderPath('ProgramFiles'), [Environment]::GetFolderPath('ProgramFilesX86')) | Where-Object { $_ }
  $machine = Get-ItemProperty -LiteralPath 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion' -ErrorAction SilentlyContinue
  foreach ($key in @('ProgramFilesDir','ProgramFilesDir (x86)','ProgramW6432Dir')) {
    if ($null -ne $machine -and $null -ne $machine.PSObject.Properties[$key]) { [string]$machine.$key }
  }
  Join-Path ([Environment]::GetFolderPath('CommonApplicationData')) 'HenryWilliam\LeanGuard'
  $PSScriptRoot
}
function Get-HWOSShellResources {
  param([string]$Text)
    # Only quoted literal heredocs are data; unquoted substitutions remain unproven.
  $Text=[regex]::Replace($Text, "(?ms)<<'(?<tag>[A-Za-z_][A-Za-z0-9_]*)'[^\r\n]*\r?\n.*?^\k<tag>\s*$", '')
  $tokens=$null; $errors=$null
  $ast=[Management.Automation.Language.Parser]::ParseInput($Text,[ref]$tokens,[ref]$errors)
  $known=@('get-content','gc','type','get-item','get-childitem','ls','dir','cat','head','tail','set-content','add-content','out-file','new-item','copy-item','move-item','rename-item','remove-item','del','erase','rmdir','rd','rm','mkdir','touch','robocopy','xcopy','cp','mv','icacls','takeown','set-acl')
  $writes=@('set-content','add-content','out-file','new-item','copy-item','move-item','rename-item','remove-item','del','erase','rmdir','rd','rm','mkdir','touch','robocopy','xcopy','cp','mv','icacls','takeown','set-acl')
  foreach($node in @($ast.FindAll({param($n) $n -is [Management.Automation.Language.CommandAst]},$true))) {
    foreach($redirect in @($node.Redirections)) {
      if($redirect -is [Management.Automation.Language.FileRedirectionAst]) {
        $v=if($redirect.Location -is [Management.Automation.Language.StringConstantExpressionAst]){$redirect.Location.Value}else{$null}
        [pscustomobject]@{Path=$v;Mutation=$true}
      }
    }
    $name=$node.GetCommandName()
    if (-not $name) { continue }
    $name=($name -split '[\\/]')[-1].ToLowerInvariant()
    $elements=@($node.CommandElements)
    $argumentStart=1
    if($name -match '^[A-Za-z_][A-Za-z0-9_]*=') {
      $assignedCommand=$null
      for($j=1;$j -lt $elements.Count;$j++) {
        if($elements[$j] -isnot [Management.Automation.Language.StringConstantExpressionAst]) { continue }
        $candidate=[string]$elements[$j].Value
        if($candidate -match '^[A-Za-z_][A-Za-z0-9_]*=') { continue }
        $assignedCommand=(($candidate -split '[\\/]')[-1]).ToLowerInvariant()
        $argumentStart=$j+1
        break
      }
      if(-not $assignedCommand) { continue }
      $name=$assignedCommand
    }
    if($name -in @('command','env','exec','builtin','nohup','nice','time','sudo')) {
      $wrapped=$null
      for($j=$argumentStart;$j -lt $elements.Count;$j++) {
        if($elements[$j] -isnot [Management.Automation.Language.StringConstantExpressionAst]) { continue }
        $candidate=[string]$elements[$j].Value
        if($candidate.StartsWith('-') -or ($name -eq 'env' -and $candidate -match '^[A-Za-z_][A-Za-z0-9_]*=')) { continue }
        $candidate=(($candidate -split '[\\/]')[-1]).ToLowerInvariant()
        if($candidate -in $known) { $wrapped=$candidate; $argumentStart=$j+1; break }
      }
      if(-not $wrapped) { continue }
      $name=$wrapped
    }
    if($name -notin $known) { continue }
    $mutate=$name -in $writes
    $count=0
    for($i=$argumentStart;$i -lt $elements.Count;$i++) {
      $element=$elements[$i]
      if($element -is [Management.Automation.Language.CommandParameterAst]) {
        if($element.ParameterName -in @('Path','LiteralPath','Destination','FilePath')) {
          if($null -ne $element.Argument) { $element=$element.Argument }
          elseif(($i+1) -lt $elements.Count) { $i++; $element=$elements[$i] }
          else { [pscustomobject]@{Path=$null;Mutation=$mutate}; continue }
        } elseif($element.ParameterName -in @('Value','Encoding','Filter','Include','Exclude')) { $i++; continue }
        else { continue }
      }
      if($element -is [Management.Automation.Language.StringConstantExpressionAst]) {
        $v=[string]$element.Value
        if($v -match '^/(?:MIR|PURGE|E|S|COPY:[A-Z]+|DCOPY:[A-Z]+|R:\d+|W:\d+)$') { continue }
        $count++; [pscustomobject]@{Path=$v;Mutation=$mutate}
      } else { $count++; [pscustomobject]@{Path=$null;Mutation=$true} }
    }
    if($mutate -and ($count -eq 0 -or @($errors).Count -gt 0)) { [pscustomobject]@{Path=$null;Mutation=$true} }
    foreach($redirect in @($node.Redirections)) {
      if($redirect -is [Management.Automation.Language.FileRedirectionAst]) {
        $v=if($redirect.Location -is [Management.Automation.Language.StringConstantExpressionAst]){$redirect.Location.Value}else{$null}
        [pscustomobject]@{Path=$v;Mutation=$true}
      }
    }
  }
}
function Invoke-HWOSResourceProtection {
  $resources=New-Object System.Collections.Generic.List[object]
  $mutate=(Test-HWOSExactMember -Value $toolName -Members (@($policy.nativeWriteTools)+@($policy.deleteTools)))
  $targetFields=@($fields | Where-Object { $_.Name -ine 'cwd' })
  foreach($path in @(Get-HWOSPathFields -Fields $targetFields)){$resources.Add([pscustomobject]@{Path=$path;Mutation=$mutate})}
  if (($mutate -or $toolName -ceq 'Read') -and $resources.Count -eq 0) {
    Write-HWOSDecision 'deny' 'unresolved-resource-target' $toolName 'The supported native resource operation has no recognized target field.'
  }
  if($isShell){foreach($r in @(Get-HWOSShellResources $command)){$resources.Add($r)}}
  $roots=@(Get-HWOSSystemRoots)
  if ((Test-HWOSExactMember -Value $toolName -Members $policy.deleteTools) -or ($isShell -and $command -match '(?i)\b(remove-item|rm|del|erase|rmdir|rd|cp|mv|icacls|takeown|set-acl|robocopy)\b')) { $roots += @($policy.protectedRoots) }
  foreach($r in $resources) {
    $p=if($r.Path){Get-HWOSResourcePath ([string]$r.Path)}else{$null}
    if(-not $p) {
      Write-HWOSDecision 'deny' 'unresolved-resource-target' $toolName 'A submitted resource target cannot be resolved by the supported literal-path parser.'
      continue
    }
    if(Test-HWOSResourceHost $p){Write-HWOSDecision 'deny' 'protected-server-deny' $toolName 'All submitted operations on this protected server are denied.'}
    # UNC identity classification above never opens the protected server.
    if($p.StartsWith('\\')){continue}
    $cursor=$p
    while($cursor) {
      $item=Get-Item -LiteralPath $cursor -Force -ErrorAction SilentlyContinue
      if($null -ne $item -and ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
        $tagOutput = & "$([Environment]::GetFolderPath('System'))\fsutil.exe" reparsepoint query $cursor 2>$null
        $tagMatch=[regex]::Match(($tagOutput -join ' '),'0x[0-9a-fA-F]{8}')
        if($LASTEXITCODE -ne 0 -or -not $tagMatch.Success -or (([Convert]::ToUInt32($tagMatch.Value.Substring(2),16) -band 0x20000000) -ne 0)) {
          Write-HWOSDecision 'deny' 'unresolved-resource-target' $toolName 'Name-surrogate or unidentified reparse traversal requires verified target identity.'
        }
      }
      if ($cursor -match '^[A-Za-z]:$') { break }
      $parent=Split-Path -Parent $cursor
      if($parent -eq $cursor){break}; $cursor=$parent
    }
    if($r.Mutation) {
      foreach($root in $roots) {
        $canonical=Get-HWOSResourcePath ([string]$root)
        if($canonical -and ((Test-HWOSResourceBoundary $p $canonical) -or (Test-HWOSResourceBoundary $canonical $p))) {
          Write-HWOSDecision 'deny' 'protected-path-write-deny' $toolName 'System or protected-root mutation is denied before ordinary delete confirmation.'
        }
      }
    }
  }
}
