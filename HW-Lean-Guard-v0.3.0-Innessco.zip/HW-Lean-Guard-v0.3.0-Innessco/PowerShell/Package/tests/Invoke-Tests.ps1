[CmdletBinding()]
param([ValidateSet('All','Contract','ManagedSettings','Guard','ResourceProtection','Deployment','WorkbenchPolicy','Intune','Manifest')][string]$Suite = 'All')
$ErrorActionPreference = 'Stop'
$map = [ordered]@{
  Contract = 'Test-Contract.ps1'
  ManagedSettings = 'Test-ManagedSettings.ps1'
  Guard = 'Test-Guard.ps1'
  ResourceProtection = 'Test-ResourceProtection.ps1'
  Deployment = 'Test-Deployment.ps1'
  WorkbenchPolicy = 'Test-WorkbenchPolicy.ps1'
  Intune = 'Test-Intune.ps1'
  Manifest = 'Test-Manifest.ps1'
}
$selected = if ($Suite -ceq 'All') { @($map.Keys) } else { @($Suite) }
foreach ($name in $selected) {
  & (Join-Path $PSScriptRoot $map[$name])
}
Write-Output "PASS: HW OS Lean Guard test suite $Suite"
