param([switch]$NamespaceOnly,[switch]$TrailingAliasOnly,[switch]$PathEdgesOnly)
$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$guard=Join-Path $root 'runtime/Invoke-HWOSLeanGuard.ps1'
$temp=Join-Path ([IO.Path]::GetTempPath()) ('resource-r13-'+[guid]::NewGuid().ToString('N'))
try {
New-Item -ItemType Directory $temp | Out-Null
$count=0
function Check($name,$tool,$inputValue,$expected,$expectedRule=$null) {
 $json=@{tool_name=$tool;tool_input=$inputValue;cwd=$temp}|ConvertTo-Json -Compress -Depth 8
 $result=$json | & powershell.exe -NoProfile -File $guard -AuditDirectory $temp
 if($LASTEXITCODE -ne 0){throw "$name runtime failure: $result"}
 $actual=($result|ConvertFrom-Json).hookSpecificOutput.permissionDecision
 if($actual -ne $expected){throw "$name expected $expected got $actual"}
 if ($expectedRule -and ($result|ConvertFrom-Json).hookSpecificOutput.permissionDecisionReason -notlike ('*:'+ $expectedRule+']*')) { throw "$name wrong rule: $result" }
 $script:count++
}
Check 'Windows ADS native write' 'Write' @{file_path='C:\Windows:stream';content='x'} 'deny' 'unresolved-resource-target'
Check 'Guard ADS delete' 'Delete' @{path='C:\Program Files\ClaudeCode\HWOSLeanGuard:stream'} 'deny' 'unresolved-resource-target'
Check 'extended ADS native write' 'Write' @{file_path='\\?\C:\Windows:stream';content='x'} 'deny' 'unresolved-resource-target'
Check 'ADS shell mutation' 'PowerShell' @{command='Set-Content -LiteralPath "C:\Windows:stream" -Value x'} 'deny' 'unresolved-resource-target'
Check 'UNC ADS mutation' 'Write' @{file_path='\\ordinary-host\share\x:stream';content='x'} 'deny' 'unresolved-resource-target'
Check 'root-relative mutation' 'Write' @{file_path='\Windows\x';content='x'} 'deny' 'unresolved-resource-target'
Check 'cwd-only native write' 'Write' @{cwd=$temp;content='x'} 'deny' 'unresolved-resource-target'
Check 'cwd-only native delete' 'Delete' @{cwd=$temp} 'deny' 'unresolved-resource-target'
Check 'ordinary relative mutation' 'Write' @{file_path='ordinary.txt';content='x'} 'allow'
if ($PathEdgesOnly) { Write-Output '9 path-edge checks passed; no submitted operation was executed.'; exit 0 }
Check 'Windows trailing-space native write' 'Write' @{file_path='C:\Windows \x';content='x'} 'deny'
Check 'Program Files trailing-space delete' 'Delete' @{path='C:\Program Files \x'} 'deny'
Check 'trailing-space shell mutation' 'PowerShell' @{command='Set-Content -LiteralPath "C:\Windows \x" -Value x'} 'deny'
Check 'extended trailing-space write' 'Write' @{file_path='\\?\C:\Windows \x';content='x'} 'deny'
Check 'UNC share trailing-dot mutation' 'Write' @{file_path='\\ordinary-host\share.\x';content='x'} 'deny'
Check 'UNC path trailing-space delete' 'Delete' @{path='\\ordinary-host\share\folder \x'} 'deny'
Check 'ordinary dot normalization' 'Write' @{file_path=(Join-Path $temp '.\folder\..\ordinary.txt');content='x'} 'allow'
if ($TrailingAliasOnly) { Write-Output '7 trailing-alias checks passed; no submitted operation was executed.'; exit 0 }
Check 'unsupported GLOBALROOT write' 'Write' @{file_path='\\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\x';content='x'} 'deny'
Check 'unsupported volume delete' 'Delete' @{path='\\?\Volume{11111111-1111-1111-1111-111111111111}\Windows\x'} 'deny'
Check 'unsupported namespace shell write' 'PowerShell' @{command='Set-Content -LiteralPath "\\?\GLOBALROOT\Device\HarddiskVolumeShadowCopy1\Windows\x" -Value x'} 'deny'
if ($NamespaceOnly) { Write-Output '3 namespace checks passed; no submitted operation was executed.'; exit 0 }
Check 'missing native delete target' 'Delete' @{} 'deny'
Check 'opaque native delete target' 'Delete' @{opaque='\\Affinity-p01\share\x'} 'deny'
Check 'missing native read target' 'Read' @{} 'deny'
Check 'server delete before ask' 'Delete' @{path='\\Affinity-p01\share\x'} 'deny'
Check 'server read' 'Read' @{file_path='\\hwlfilesv2.file.core.windows.net\share\x'} 'deny'
Check 'extended UNC' 'Read' @{file_path='\\?\UNC\Affinity-p01\share\x'} 'deny'
Check 'file URI' 'Read' @{file_path='file://Affinity-p01/share/x'} 'deny'
Check 'host boundary' 'Write' @{file_path='\\Affinity-p01-other\share\x';content='x'} 'allow'
Check 'windows delete' 'Delete' @{path=([Environment]::GetFolderPath('Windows')+'\synthetic-never-created')} 'deny'
Check 'windows ancestor' 'Delete' @{path=([IO.Path]::GetPathRoot([Environment]::GetFolderPath('Windows')))} 'deny'
Check 'dynamic delete' 'PowerShell' @{command='Remove-Item -LiteralPath $unknown'} 'deny'
Check 'literal server shell' 'PowerShell' @{command='Get-Content -LiteralPath "\\Affinity-p01\share\x"'} 'deny'
Check 'ordinary delete' 'Delete' @{path=(Join-Path $temp 'ordinary.txt')} 'ask'
Check 'ordinary L drive no identity assumption' 'Write' @{file_path='L:\ordinary.txt';content='x'} 'allow'
Check 'forward UNC shell' 'Bash' @{command='cat //Affinity-p01/share/x'} 'deny'
Check 'Bash cp protected Affinity source' 'Bash' @{command='cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash mv protected Azure Files source' 'Bash' @{command='mv //hwlfilesv2.file.core.windows.net/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash cp protected Azure Files destination' 'Bash' @{command='cp ordinary.txt //hwlfilesv2.file.core.windows.net/share/x'} 'deny' 'protected-server-deny'
Check 'Bash cp Windows destination' 'Bash' @{command=('cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'Bash mv Program Files destination' 'Bash' @{command=('mv ordinary.txt "'+([Environment]::GetFolderPath('ProgramFiles').Replace('\\','/'))+'/synthetic-never-created"')} 'deny' 'protected-path-write-deny'
Check 'ordinary Bash cp' 'Bash' @{command='cp ordinary.txt ordinary-copy.txt'} 'allow'
Check 'Bash command cp protected Affinity source' 'Bash' @{command='command cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash absolute cp protected Affinity source' 'Bash' @{command='/usr/bin/cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash env cp protected Azure Files source' 'Bash' @{command='env COPY_MODE=safe cp //hwlfilesv2.file.core.windows.net/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash command mv protected Affinity destination' 'Bash' @{command='command mv ordinary.txt //Affinity-p01/share/x'} 'deny' 'protected-server-deny'
Check 'Bash exec cp Windows destination' 'Bash' @{command=('exec cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'ordinary Bash command cp' 'Bash' @{command='command cp ordinary.txt ordinary-command-copy.txt'} 'allow'
Check 'Bash assignment cp protected Affinity source' 'Bash' @{command='COPY_MODE=safe cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash multiple assignment command cp protected Azure Files destination' 'Bash' @{command='A=1 B=2 command cp ordinary.txt //hwlfilesv2.file.core.windows.net/share/x'} 'deny' 'protected-server-deny'
Check 'Bash quoted assignment mv protected Affinity source' 'Bash' @{command='MOVE_MODE="safe value" mv //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash assignment exec cp Windows destination' 'Bash' @{command=('COPY_MODE=safe exec cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'ordinary Bash assignment cp' 'Bash' @{command='COPY_MODE=safe cp ordinary.txt ordinary-assignment-copy.txt'} 'allow'
Check 'Bash nohup cp protected Affinity source' 'Bash' @{command='nohup cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash builtin cp protected Affinity source' 'Bash' @{command='builtin cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash nice cp protected Azure Files source' 'Bash' @{command='nice -n 5 cp //hwlfilesv2.file.core.windows.net/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash time mv protected Affinity destination' 'Bash' @{command='time mv ordinary.txt //Affinity-p01/share/x'} 'deny' 'protected-server-deny'
Check 'Bash assignment sudo cp Windows destination' 'Bash' @{command=('COPY_MODE=safe sudo -u nobody cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'Bash nested time sudo cp Windows destination' 'Bash' @{command=('time sudo cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'Bash nested nohup command cp protected Affinity source' 'Bash' @{command='nohup command cp //Affinity-p01/share/x ordinary.txt'} 'deny' 'protected-server-deny'
Check 'Bash assignment nested time sudo cp Windows destination' 'Bash' @{command=('A=1 time sudo -u nobody cp ordinary.txt '+([Environment]::GetFolderPath('Windows').Replace('\\','/'))+'/synthetic-never-created')} 'deny' 'protected-path-write-deny'
Check 'Bash nested nice env command mv protected Affinity destination' 'Bash' @{command='nice -n 5 env A=1 command mv ordinary.txt //Affinity-p01/share/x'} 'deny' 'protected-server-deny'
Check 'ordinary Bash nested wrapper cp' 'Bash' @{command='time sudo cp ordinary.txt ordinary-nested-copy.txt'} 'allow'
Check 'runtime installation delete' 'Delete' @{path='C:\Program Files\ClaudeCode\HWOSLeanGuard'} 'deny'
Check 'unresolved native read' 'Read' @{path='$unknown'} 'deny'
Check 'quoted heredoc next command' 'Bash' @{command="cat > ordinary.txt <<'EOF'`nExternal:`nEOF`ncat //Affinity-p01/share/x"} 'deny'
Check 'unknown command redirection' 'PowerShell' @{command=('echo text > '+[Environment]::GetFolderPath('Windows')+'\synthetic-x')} 'deny'
$junction=Join-Path $temp 'junction'
$backing=Join-Path $temp 'backing'
New-Item -ItemType Directory $backing | Out-Null
New-Item -ItemType Junction -Path $junction -Target $backing | Out-Null
Check 'reparse fail closed' 'Delete' @{path=(Join-Path $junction 'x')} 'deny'
Check 'short name unresolved' 'Delete' @{path='C:\PROGRA~1\x'} 'deny'
. (Join-Path $root 'runtime/ResourceProtection.ps1')
function Get-HWOSDriveConnection { param($Letter) if($Letter -eq 'Q'){return '\\Affinity-p01\synthetic'} }
$resolved=Get-HWOSResourcePath 'Q:\folder\x'
if($resolved -ne '\\Affinity-p01\synthetic\folder\x'){throw 'synthetic mapping resolution failed'}
$count++
Write-Output "$count resource checks passed; no submitted operation was executed."
} finally {
  $resolvedTemp = [IO.Path]::GetFullPath($temp)
  $tempPrefix = [IO.Path]::GetFullPath([IO.Path]::GetTempPath()).TrimEnd('\') + '\'
  if (-not $resolvedTemp.StartsWith($tempPrefix, [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $resolvedTemp) -notmatch '^resource-r13-[0-9a-f]{32}$') { throw 'Resource fixture cleanup escaped its temporary root.' }
  $junctionPath = Join-Path $resolvedTemp 'junction'
  if (Test-Path -LiteralPath $junctionPath) {
    $junctionItem = Get-Item -LiteralPath $junctionPath -Force
    if (($junctionItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0) { throw 'Resource fixture junction identity changed.' }
    [IO.Directory]::Delete($junctionPath)
  }
  if (Test-Path -LiteralPath $resolvedTemp) { Remove-Item -LiteralPath $resolvedTemp -Recurse -Force }
}
