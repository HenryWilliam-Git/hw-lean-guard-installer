$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$root = Split-Path -Parent $PSScriptRoot
$instructions = [IO.File]::ReadAllText((Join-Path $root 'policy\org-instructions.md'), [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
if ($instructions.Length -gt 3000) { throw "Organisation instructions exceed 3000 characters: $($instructions.Length)." }
foreach ($required in @(
  'Copies into approved Claude Workbench roots are allowed; source mutation never is',
  'Confirm each deletion once; no standing approval',
  'No consequential external actions',
  'Unsent Outlook drafts are allowed, including externally addressed drafts',
  'Only the approved Outlook/Teams send capability may send synchronously',
  'Preserve source wording exactly'
)) {
  if (-not $instructions.Contains($required)) { throw "Required instruction text is missing: $required" }
}
foreach ($required in @('hwlfilesv2.file.core.windows.net', 'Affinity-p01', 'Deny mutations to Windows', 'Confirmation cannot override')) {
  if (-not $instructions.Contains($required)) { throw "Required resource protection is missing: $required" }
}
$schema = Get-Content (Join-Path $root 'contracts\audit-event.schema.json') -Raw | ConvertFrom-Json
if (@($schema.properties.decision.enum).Count -ne 3) { throw 'Audit decision schema must cover allow, ask and deny.' }
foreach ($decision in @('allow','ask','deny')) {
  if (@($schema.properties.decision.enum) -cnotcontains $decision) { throw "Audit decision is unsupported: $decision" }
}
$readme = [IO.File]::ReadAllText((Join-Path $root 'README.md'), [Text.Encoding]::UTF8)
if (-not $readme.Contains('`disableSideloadFlags` is deliberately absent')) { throw 'Cowork utility exception is not explicit.' }
foreach ($required in @(
  'Server-managed settings is the single policy authority',
  'without duplicating that connector catalogue in JSON',
  'user and project MCP registrations do not load',
  'Cowork''s internally supplied session configuration remains the explicit `--mcp-config` exception'
)) {
  if (-not $readme.Contains($required)) { throw "Managed-settings contract is not explicit: $required" }
}
$deploymentText = @(Get-ChildItem -LiteralPath (Join-Path $root 'deployment') -File -Filter '*.ps1' | ForEach-Object { [IO.File]::ReadAllText($_.FullName) }) -join "`n"
if ($deploymentText -match '(?i)icacls[^\r\n]+L:\\') { throw 'Deployment package attempts to change the L-drive ACL.' }
Write-Output 'PASS: contract and explicit exceptions'
