[CmdletBinding()]
param(
  [string]$PackageRoot,
  [string]$OutputPath
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
if ([string]::IsNullOrWhiteSpace($PackageRoot)) { $PackageRoot = Split-Path -Parent $PSScriptRoot }
$root = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$files = [ordered]@{}
foreach ($file in @(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object { $_.FullName -cne (Join-Path $root 'manifest.json') } | Sort-Object FullName)) {
  $relative = $file.FullName.Substring($root.Length).TrimStart('\').Replace('\', '/')
  $files[$relative] = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
}
$manifest = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-manifest/v1'
  packageId = 'hw-claude-lean-guard'
  packageVersion = '0.3.0'
  baseCommit = '21040a8f2d9de35791fd19c1f0f0b94c2e43c72d'
  files = $files
}
$json = $manifest | ConvertTo-Json -Depth 20
if (-not $OutputPath) { $json; return }
$output = [IO.Path]::GetFullPath($OutputPath)
if ($output.Equals((Join-Path $root 'manifest.json'), [StringComparison]::OrdinalIgnoreCase) -or $output.StartsWith($root + '\', [StringComparison]::OrdinalIgnoreCase)) {
  throw 'Manifest generation writes out-of-tree only; repository updates must remain reviewable.'
}
[IO.Directory]::CreateDirectory((Split-Path -Parent $output)) | Out-Null
[IO.File]::WriteAllText($output, $json, [Text.UTF8Encoding]::new($false))
Write-Output $output
