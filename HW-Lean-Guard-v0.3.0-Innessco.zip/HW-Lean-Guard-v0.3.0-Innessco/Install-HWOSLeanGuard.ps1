[CmdletBinding()]
param(
  [switch]$ServerManagedPolicyConfirmed,
  [switch]$ValidateOnly,
  [Parameter(DontShow = $true)]
  [switch]$ElevatedChild,
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode',
  [Parameter(DontShow = $true)]
  [string]$WorkbenchDesktopPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchPolicyRegistryPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchMachinePolicyRegistryPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchUserStateRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

if ([string]::IsNullOrWhiteSpace($PackageRoot)) {
  $sourcePackageRoot = Split-Path -Parent $PSScriptRoot
  $bundlePackageRoot = Join-Path $PSScriptRoot 'PowerShell\Package'
  if (Test-Path -LiteralPath (Join-Path $sourcePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $sourcePackageRoot
  } elseif (Test-Path -LiteralPath (Join-Path $bundlePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $bundlePackageRoot
  } else {
    throw 'Unable to locate the manifest-validated Lean Guard package beside the installer.'
  }
}

$PackageRoot = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$deploymentRoot = Join-Path $PackageRoot 'deployment'
$modulePath = Join-Path $deploymentRoot 'HWOSLeanGuard.Deployment.psm1'
$installerPath = Join-Path $deploymentRoot 'Install-HWOSLeanGuard.ps1'
foreach ($requiredPath in @($modulePath, $installerPath)) {
  if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) { throw "Required package file is missing: $requiredPath" }
}

Import-Module $modulePath -Force
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot
# Workbench compatibility parameters are retained but no longer applied by machine installation.
$userReadiness = [ordered]@{
  owner = 'Innessco'
  result = 'EXTERNAL_VALIDATION_REQUIRED'
  verified = $false
  policyChanged = $false
  compatibilityParameters = 'Deprecated and ignored; invoke the separate user configurator explicitly.'
  nextStep = 'Innessco must configure and verify HKCU Workbench, the active user profile and fresh Claude behavior separately.'
}
if ($ValidateOnly) {
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-preview/v3'
    applyRequested = $false
    uacRequested = $false
    serverManagedPolicyConfirmed = [bool]$ServerManagedPolicyConfirmed
    packageVersion = [string]$manifest.packageVersion
    packageRoot = $PackageRoot
    userReadiness = $userReadiness
  } | ConvertTo-Json -Depth 8
  return
}

if (-not $ServerManagedPolicyConfirmed) {
  throw 'One-command installation requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).'
}

if (-not (Test-HWOSLeanGuardAdministrator)) {
  if ($ElevatedChild) { throw 'Elevated installer child does not have Administrator rights.' }
  foreach ($value in @($PackageRoot, $InstallRoot, $StateRoot, $PolicyRegistryPath)) {
    if ([string]::IsNullOrWhiteSpace($value)) { continue }
    if ($value.Contains('"')) { throw 'Installer paths cannot contain double quotes.' }
  }
  $expectedManifestJson = $manifest | ConvertTo-Json -Depth 20 -Compress
  $expectedManifestSha256 = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($expectedManifestJson)))).Replace('-', '').ToLowerInvariant()
  $elevationPayload = [ordered]@{
    sourcePackageRoot = $PackageRoot
    expectedManifestSha256 = $expectedManifestSha256
    expectedPackageVersion = [string]$manifest.packageVersion
    installRoot = $InstallRoot
    stateRoot = $StateRoot
    policyRegistryPath = $PolicyRegistryPath
  }
  $payloadJson = $elevationPayload | ConvertTo-Json -Depth 8 -Compress
  $payloadBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($payloadJson))
  $elevatedLoader = @'
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
$payload = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('__PAYLOAD_BASE64__')) | ConvertFrom-Json -ErrorAction Stop
$commonApplicationData = [Environment]::GetFolderPath([Environment+SpecialFolder]::CommonApplicationData)
if ([string]::IsNullOrWhiteSpace($commonApplicationData) -or -not [IO.Path]::IsPathRooted($commonApplicationData)) { throw 'ProgramData did not resolve to a rooted path.' }
$secureStageRoot = [IO.Path]::GetFullPath((Join-Path $commonApplicationData 'HenryWilliam\LeanGuard\staging')).TrimEnd('\')
$secureStage = Join-Path $secureStageRoot ('elevated-' + [Guid]::NewGuid().ToString('N'))
try {
  [IO.Directory]::CreateDirectory($secureStage) | Out-Null
  $null = & icacls.exe $secureStage '/inheritance:r' '/grant:r' '*S-1-5-18:(OI)(CI)F' '*S-1-5-32-544:(OI)(CI)F'
  if ($LASTEXITCODE -ne 0) { throw 'Failed to secure the elevated staging directory.' }
  $sourcePackageRoot = [IO.Path]::GetFullPath([string]$payload.sourcePackageRoot).TrimEnd('\')
  $stagedPackageRoot = Join-Path $secureStage (Split-Path -Leaf $sourcePackageRoot)
  Copy-Item -LiteralPath $sourcePackageRoot -Destination $secureStage -Recurse -Force
  $stagedManifestPath = Join-Path $stagedPackageRoot 'manifest.json'
  if (-not (Test-Path -LiteralPath $stagedManifestPath -PathType Leaf)) { throw 'Elevated staged package manifest is missing.' }
  $stagedManifest = [IO.File]::ReadAllText($stagedManifestPath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
  $stagedManifestJson = $stagedManifest | ConvertTo-Json -Depth 20 -Compress
  $stagedManifestSha256 = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($stagedManifestJson)))).Replace('-', '').ToLowerInvariant()
  if ($stagedManifestSha256 -cne [string]$payload.expectedManifestSha256) { throw 'Elevated staged package manifest SHA-256 mismatch.' }
  if ([string]$stagedManifest.packageVersion -cne [string]$payload.expectedPackageVersion) { throw 'Elevated staged package version mismatch.' }
  $expectedFiles = @{}
  foreach ($property in $stagedManifest.files.PSObject.Properties) { $expectedFiles[[string]$property.Name] = [string]$property.Value }
  $actualFiles = @(
    Get-ChildItem -LiteralPath $stagedPackageRoot -Recurse -File |
      Where-Object { $_.FullName -cne $stagedManifestPath } |
      ForEach-Object { $_.FullName.Substring($stagedPackageRoot.Length).TrimStart('\').Replace('\', '/') }
  )
  if ($actualFiles.Count -ne $expectedFiles.Count) { throw 'Elevated staged package file count mismatch.' }
  foreach ($relative in $expectedFiles.Keys) {
    $candidate = Join-Path $stagedPackageRoot $relative
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { throw "Elevated staged package file is missing: $relative" }
    $actualSha256 = (Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha256 -cne [string]$expectedFiles[$relative]) { throw "Elevated staged package file hash mismatch: $relative" }
  }
  foreach ($relative in $actualFiles) {
    if (-not $expectedFiles.ContainsKey($relative)) { throw "Elevated staged package contains an unexpected file: $relative" }
  }
  $stagedEntryPoint = Join-Path $stagedPackageRoot 'deployment\Install-HWOSLeanGuardOneCommand.ps1'
  & $stagedEntryPoint -ServerManagedPolicyConfirmed -ElevatedChild -PackageRoot $stagedPackageRoot -InstallRoot ([string]$payload.installRoot) -StateRoot ([string]$payload.stateRoot) -PolicyRegistryPath ([string]$payload.policyRegistryPath) | Out-Null
} finally {
  $resolvedStage = [IO.Path]::GetFullPath($secureStage)
  $stagePrefix = $secureStageRoot + '\'
  if ((Test-Path -LiteralPath $resolvedStage) -and $resolvedStage.StartsWith($stagePrefix, [StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $resolvedStage).StartsWith('elevated-', [StringComparison]::Ordinal)) {
    Remove-Item -LiteralPath $resolvedStage -Recurse -Force
  }
}
'@
  $elevatedLoader = $elevatedLoader.Replace('__PAYLOAD_BASE64__', $payloadBase64)
  $encodedCommand = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($elevatedLoader))
  $windowsPowerShell = Join-Path $PSHOME 'powershell.exe'
  if (-not (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf)) {
    $windowsPowerShell = (Get-Command powershell.exe -ErrorAction Stop).Source
  }
  $argumentLine = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', $encodedCommand)
  try {
    $process = Start-Process -FilePath $windowsPowerShell -ArgumentList $argumentLine -Verb RunAs -Wait -PassThru
  } catch {
    throw "Administrator elevation failed or was cancelled. Lean Guard was not installed by this command. $($_.Exception.Message)"
  }
  if ($process.ExitCode -ne 0) { throw "Elevated Lean Guard installation failed with exit code $($process.ExitCode)." }
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-result/v3'
    packageVersion = [string]$manifest.packageVersion
    machineInstall = [ordered]@{ elevatedChildExitCode = $process.ExitCode; result = 'PASS' }
    userReadiness = $userReadiness
    resultScope = 'machine'
    result = 'PASS'
  } | ConvertTo-Json -Depth 16
  return
}

$installJson = (& $installerPath -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $PackageRoot -InstallRoot $InstallRoot -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath | Out-String)
$installEvidence = $installJson | ConvertFrom-Json -ErrorAction Stop
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
$passed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -eq 0
if (-not $passed) { throw 'One-command installation completed but installed-state detection failed.' }

if ($ElevatedChild) {
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-machine-result/v2'
    packageVersion = [string]$manifest.packageVersion
    installEvidence = $installEvidence
    checks = $checks
    userReadiness = $userReadiness
    resultScope = 'machine'
    result = 'PASS'
  } | ConvertTo-Json -Depth 16
  return
}

[ordered]@{
  schemaVersion = 'hw-os-lean-guard-one-command-result/v3'
  packageVersion = [string]$manifest.packageVersion
  installEvidence = $installEvidence
  checks = $checks
  userReadiness = $userReadiness
  resultScope = 'machine'
  result = 'PASS'
} | ConvertTo-Json -Depth 16
