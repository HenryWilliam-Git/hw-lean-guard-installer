# v0.3.0 candidate: Innessco user readiness

Status: local handoff draft for settled r1.3, not deployment or fleet acceptance. The machine install and user readiness are separate results. Historical v0.2.0 instructions describe an automatic HKCU phase and must not be used as this candidate's operating procedure.

Innessco owns the authorized user-policy mechanism, admission/remediation, rotating-AVD profile checks and endpoint evidence. Engineering preserves `HKLM\SOFTWARE\Policies\ClaudeCode\Settings` and exact `forceRemoteSettingsRefresh` bootstrap bytes. No HKLM Workbench migration or new storage/retention registry schema is introduced.

## Ordered user procedure

1. Verify approved runtime/bootstrap and machine detection on each host, including replaced or reimaged hosts. Machine PASS alone is not user-ready.
2. Verify the actual token SID/session and that the intended FSLogix full Profile Container is attached. Stop for unexpected temporary/local profiles, failed attachment or uncertain identity.
3. Resolve that user's Windows Desktop Known Folder after redirection/profile readiness, then append only `Claude Workbench`. Do not hardcode a staging drive, tenant, username or administrator profile.
4. Inspect `HKCU\SOFTWARE\Policies\Claude\allowedWorkspaceFolders` and relevant HKLM Desktop conflicts. Capture exact value/key existence, registry type, data and management ownership before mutation. Stop on machine conflict; do not weaken ACLs.
5. Verify path safety, protected-server/system intersections, redirection/reparse safety and effective folder access. Use the reference `package/deployment/Configure-HWOSClaudeWorkbench.ps1` only explicitly, under authorized management and the verified intended user. SYSTEM's HKCU and another administrator's HKCU are not the target user.
6. If already exactly one matching `REG_MULTI_SZ` path and the folder is valid, return `already-correct` without rewriting. For absence/drift, only the authorized Innessco mechanism may create the required child and apply the one-path value. Access denied is a failed setup.
7. Read back exact type, count and path. Start a fresh Claude session; observe intended folder admission and denial outside scope. Record client version and actual effective behavior.
8. Return separate machine-ready and user-ready results. Innessco must prove how Claude admission is held while profile/user policy is unready; the package does not supply a universal logon gate.

## Acceptance and rollback evidence

Run two different users across two rotating hosts, logoff/sign-in, concurrent sessions, redirected Desktop, locked already-correct key, drift, denied write, machine conflict and failed profile attachment. Preserve de-identified host/user correlation, package/client versions, effective policy readback, folder checks, observed fresh-client result and actionable failure. Keep sensitive paths/SIDs in owner-controlled evidence, not generic activity logs.

Restore only the matching user's captured prestate, through authorized management, after checking that newer policy is not overwritten. Machine rollback is separately owned. Do not blindly delete HKCU values or user folders. A reviewed rollback to v0.2.0 must account for its automatic HKCU side effect.

## Required owner inputs

- N01/O-01: current protected inventory is confirmed as exactly `hwlfilesv2.file.core.windows.net` and `Affinity-p01`. Additional aliases/routes require explicit inventory if introduced. Prove actual Code, Desktop/Cowork, MCP HTTP and child-process mediation with timeout/crash evidence. Preserve normal employee application access. Local hook tests are insufficient.
- O-03/O-05: per-user Lean Guard activity audit interface, destination, permissions, profile/AppData placement, capacity, availability and 28-day retention configuration/scheduler. Existing shared ProgramData audit routing remains pending this decision. No per-user route, UTC segmentation, retention cleanup or new registry binding is implemented. Activity logs exclude session histories and connector logs; machine receipts/rollback remain machine records.
- B1: current disk/VHDX backup product, schedule, coverage/exclusions, completion signals, restore integrity/metadata, RPO/RTO, custody, capacity, legal hold and outage behavior. State explicitly whether exact pre-deletion state is recoverable. A periodic backup is not proof of exact pre-deletion capture. No custom backup mechanism is selected and no backup-before-delete claim is made.

Source contracts: `.omo/reference/Innessco-HKCU-Workbench-Runbook-r1.3.html` and `.omo/reference/Lean-Guard-Build-Specification-r1.3.html`. This handoff is not proof the Innessco mechanism exists or passed.
