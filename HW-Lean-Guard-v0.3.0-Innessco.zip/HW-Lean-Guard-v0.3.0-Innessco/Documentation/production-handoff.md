# v0.3.0 r1.3 candidate release gate

Status: local candidate under implementation and validation. No publication, installation, endpoint mutation or live verification is established by this record. Version/manifest/build/CI evidence is owned by the coordinating release lane and must be recorded before release acceptance.

The settled r1.3 source separates machine installation from Innessco user readiness, replaces floating drive identity with named-server intent, and requires system mutation denial before ordinary confirmation. The exact endpoint bootstrap and native enterprise connector/version controls remain the baseline contracts. No new HKLM Workbench, audit-storage or retention schema is authorized here.

## Policy lane changes and evidence

`package/policy/org-instructions.md` names both protected hosts and system mutation denial while retaining source fidelity, internal exact-draft send confirmation, ordinary deletion confirmation and litigation requirements within 3,000 characters. `package/contracts/audit-event.schema.json` adds the already emitted `ask` decision to the existing allow/deny enum without unused correlation/transaction fields.

The local managed-settings candidate removes fixed L-drive Read/Edit bindings. No unsupported UNC rule syntax is invented. Official [Read/Edit permission documentation](https://code.claude.com/docs/en/permissions) specifies absolute and Windows POSIX patterns but does not establish the precise UNC transformation required here. Host enforcement belongs to the candidate hook for submitted tool targets and needs runtime evidence. Endpoint managed settings are unchanged. Absence of host-specific managed permission patterns is an explicit unresolved defense-layer limitation, not all-surface protection.

Policy baseline, fail-first and focused contract evidence is in `.omo/evidence/policy-r13/`. Full-suite, packaging, exact-commit CI and live evidence are independent gates. Consult the final coordinator evidence rather than inferring pass from this draft.

## Blocking release conditions

| Gate | Required evidence |
| --- | --- |
| N01/O-01 | Owner-confirmed current inventory is exactly `hwlfilesv2.file.core.windows.net` and `Affinity-p01`; prove actual Code, Desktop/Cowork, connectors, real MCP HTTP server and children/grandchildren fail-closed isolation, including timeout/crash cases; normal employee access unaffected. |
| M01-M03 | Exact bootstrap bytes, machine hashes/detection and no implicit user-hive writes across every machine/public/Intune entrypoint. |
| U01-U04 | Innessco management authority and two-user/two-host fresh-client readiness, profile/conflict/failure handling and no-op behavior. |
| S01/D01 | Safe disposable system/ancestor/reparse mutation tests, deny-before-ask, ordinary exact confirmation and outage behavior, then actual-client evidence. |
| L01/O-03/O-05 | Agreed per-user activity audit interface and 28-day operational retention, permissions, closed UTC segment expiry, active/locked/reparse safety, clock rollback and offline-profile handling. Not implemented or proven by this candidate. |
| B1 | Innessco disk/VHDX backup/restore assessment and explicit recovery-gap decision. Remains open; no mandatory verified backup-before-deletion claim. |
| R01 | Full regression, strict manifest, reproducible packaging/tamper checks and exact-commit CI, followed by separately authorized publication/pilot. |

The existing `C:\ProgramData\HenryWilliam\LeanGuard\logs` route remains pending Innessco interface agreement. No per-user log destination, retention scheduler, backup folder, broker or snapshot mechanism is selected. Machine receipts and rollback remain machine records. Historical shared logs are preserved pending separate migration/disposal authority. Session history and connector logs are outside the Lean Guard activity-log requirement.

Next action: complete local regression and independent review, obtain missing owner inputs and real-surface coverage evidence, then seek the specific release/pilot authorization. A green local suite cannot close N01/O-01. See [Innessco runbook](innessco-v0.3.0-runbook.md).
