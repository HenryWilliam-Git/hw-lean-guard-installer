# Lean Guard v0.3.0 Innessco deployment package

This is a review candidate, not production-ready or authorized for installation. Full cross-surface mediation is UNVERIFIED; audit destination/28-day scheduler and backup assessment remain OPEN with Innessco. This is the operator handoff for the locally prepared Lean Guard v0.3.0 direct PowerShell deployment.

1. Extract the complete ZIP to a local folder and read Documentation/production-handoff.md.
2. Review Documentation/cloud-only-production-architecture.jpg and implement the required FSLogix, OneDrive and host-local TEMP/cache split.
3. Verify every extracted file against HANDOFF-SHA256SUMS.
4. Confirm Claude /status shows Enterprise managed settings (remote).
5. Only after installation is separately authorized, from this extraction root run exactly:

`powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-HWOSLeanGuard.ps1 -ServerManagedPolicyConfirmed
`

The command validates the complete package manifest, requests Administrator elevation when needed, runs the official installer, and refuses success unless installed-state readback passes. A cancelled UAC prompt does not install Lean Guard.

Machine installation never configures HKCU or creates a Workbench folder. Its separate userReadiness result remains EXTERNAL_VALIDATION_REQUIRED. Innessco must verify the intended user token and profile, then explicitly configure and verify that user's Desktop Claude Workbench policy through the separate reference helper and authorized management. Read Documentation/innessco-v0.3.0-runbook.md. Machine PASS is not user readiness.

The IntuneWin artifact is not an Innessco deployment input in this bundle. Do not edit files under PowerShell/Package; the manifest rejects missing, changed or extra files. The files under Evidence and Integrity are records, not deployment instructions. Endpoints must not pull mutable source from GitHub.
