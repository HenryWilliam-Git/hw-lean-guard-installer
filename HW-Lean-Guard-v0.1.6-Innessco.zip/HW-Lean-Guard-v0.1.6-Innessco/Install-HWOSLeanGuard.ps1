[CmdletBinding()]
param(
  [switch]$ServerManagedPolicyConfirmed,
  [switch]$ValidateOnly,
  [Parameter(DontShow = $true)]
  [switch]$ElevatedChild,
  [string]$PackageRoot,
  [string]$InstallRoot = 'C:\Program Files\ClaudeCode\HWOSLeanGuard',
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode',
  [Parameter(DontShow = $true)]
  [string]$WorkbenchDesktopPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchPolicyRegistryPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchMachinePolicyRegistryPath,
  [Parameter(DontShow = $true)]
  [string]$WorkbenchUserStateRoot
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0

if ([string]::IsNullOrWhiteSpace($PackageRoot)) {
  $sourcePackageRoot = Split-Path -Parent $PSScriptRoot
  $bundlePackageRoot = Join-Path $PSScriptRoot 'PowerShell\Package'
  if (Test-Path -LiteralPath (Join-Path $sourcePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $sourcePackageRoot
  } elseif (Test-Path -LiteralPath (Join-Path $bundlePackageRoot 'manifest.json') -PathType Leaf) {
    $PackageRoot = $bundlePackageRoot
  } else {
    throw 'Unable to locate the manifest-validated Lean Guard package beside the installer.'
  }
}

$PackageRoot = [IO.Path]::GetFullPath($PackageRoot).TrimEnd('\')
$deploymentRoot = Join-Path $PackageRoot 'deployment'
$modulePath = Join-Path $deploymentRoot 'HWOSLeanGuard.Deployment.psm1'
$installerPath = Join-Path $deploymentRoot 'Install-HWOSLeanGuard.ps1'
$workbenchConfiguratorPath = Join-Path $deploymentRoot 'Configure-HWOSClaudeWorkbench.ps1'
foreach ($requiredPath in @($modulePath, $installerPath, $workbenchConfiguratorPath)) {
  if (-not (Test-Path -LiteralPath $requiredPath -PathType Leaf)) { throw "Required package file is missing: $requiredPath" }
}

Import-Module $modulePath -Force
$manifest = Assert-HWOSLeanGuardPackage -PackageRoot $PackageRoot
$workbenchParameters = @{}
if (-not [string]::IsNullOrWhiteSpace($WorkbenchDesktopPath)) { $workbenchParameters.DesktopPath = $WorkbenchDesktopPath }
if (-not [string]::IsNullOrWhiteSpace($WorkbenchPolicyRegistryPath)) { $workbenchParameters.PolicyRegistryPath = $WorkbenchPolicyRegistryPath }
if (-not [string]::IsNullOrWhiteSpace($WorkbenchMachinePolicyRegistryPath)) { $workbenchParameters.MachinePolicyRegistryPath = $WorkbenchMachinePolicyRegistryPath }
if (-not [string]::IsNullOrWhiteSpace($WorkbenchUserStateRoot)) { $workbenchParameters.UserStateRoot = $WorkbenchUserStateRoot }
$workbenchPreview = (& $workbenchConfiguratorPath @workbenchParameters | Out-String) | ConvertFrom-Json -ErrorAction Stop

if ($ValidateOnly) {
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-preview/v2'
    applyRequested = $false
    uacRequested = $false
    serverManagedPolicyConfirmed = [bool]$ServerManagedPolicyConfirmed
    packageVersion = [string]$manifest.packageVersion
    packageRoot = $PackageRoot
    workbench = $workbenchPreview
  } | ConvertTo-Json -Depth 8
  return
}

if (-not $ServerManagedPolicyConfirmed) {
  throw 'One-command installation requires -ServerManagedPolicyConfirmed after Claude /status shows Enterprise managed settings (remote).'
}

if (-not (Test-HWOSLeanGuardAdministrator)) {
  if ($ElevatedChild) { throw 'Elevated installer child does not have Administrator rights.' }
  foreach ($value in @($PSCommandPath, $PackageRoot, $InstallRoot, $StateRoot, $PolicyRegistryPath, $WorkbenchDesktopPath, $WorkbenchPolicyRegistryPath, $WorkbenchMachinePolicyRegistryPath, $WorkbenchUserStateRoot)) {
    if ([string]::IsNullOrWhiteSpace($value)) { continue }
    if ($value.Contains('"')) { throw 'Installer paths cannot contain double quotes.' }
  }
  $windowsPowerShell = Join-Path $PSHOME 'powershell.exe'
  if (-not (Test-Path -LiteralPath $windowsPowerShell -PathType Leaf)) {
    $windowsPowerShell = (Get-Command powershell.exe -ErrorAction Stop).Source
  }
  $argumentLine = @(
    '-NoProfile',
    '-ExecutionPolicy Bypass',
    "-File `"$PSCommandPath`"",
    '-ServerManagedPolicyConfirmed',
    '-ElevatedChild',
    "-PackageRoot `"$PackageRoot`"",
    "-InstallRoot `"$InstallRoot`"",
    "-StateRoot `"$StateRoot`"",
    "-PolicyRegistryPath `"$PolicyRegistryPath`""
  )
  if (-not [string]::IsNullOrWhiteSpace($WorkbenchDesktopPath)) { $argumentLine += "-WorkbenchDesktopPath `"$WorkbenchDesktopPath`"" }
  if (-not [string]::IsNullOrWhiteSpace($WorkbenchPolicyRegistryPath)) { $argumentLine += "-WorkbenchPolicyRegistryPath `"$WorkbenchPolicyRegistryPath`"" }
  if (-not [string]::IsNullOrWhiteSpace($WorkbenchMachinePolicyRegistryPath)) { $argumentLine += "-WorkbenchMachinePolicyRegistryPath `"$WorkbenchMachinePolicyRegistryPath`"" }
  if (-not [string]::IsNullOrWhiteSpace($WorkbenchUserStateRoot)) { $argumentLine += "-WorkbenchUserStateRoot `"$WorkbenchUserStateRoot`"" }
  $argumentLine = $argumentLine -join ' '
  try {
    $process = Start-Process -FilePath $windowsPowerShell -ArgumentList $argumentLine -Verb RunAs -Wait -PassThru
  } catch {
    throw "Administrator elevation failed or was cancelled. Lean Guard was not installed by this command. $($_.Exception.Message)"
  }
  if ($process.ExitCode -ne 0) { throw "Elevated Lean Guard installation failed with exit code $($process.ExitCode)." }
  $workbenchJson = (& $workbenchConfiguratorPath -Apply -Confirm:$false @workbenchParameters | Out-String)
  $workbenchResult = $workbenchJson | ConvertFrom-Json -ErrorAction Stop
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-result/v2'
    packageVersion = [string]$manifest.packageVersion
    machineInstall = [ordered]@{ elevatedChildExitCode = $process.ExitCode; result = 'PASS' }
    workbench = $workbenchResult
    result = 'PASS'
  } | ConvertTo-Json -Depth 16
  return
}

$installJson = (& $installerPath -Apply -ServerManagedPolicyConfirmed -Confirm:$false -PackageRoot $PackageRoot -InstallRoot $InstallRoot -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath | Out-String)
$installEvidence = $installJson | ConvertFrom-Json -ErrorAction Stop
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
$passed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -eq 0
if (-not $passed) { throw 'One-command installation completed but installed-state detection failed.' }

if ($ElevatedChild) {
  [ordered]@{
    schemaVersion = 'hw-os-lean-guard-one-command-machine-result/v1'
    packageVersion = [string]$manifest.packageVersion
    installEvidence = $installEvidence
    checks = $checks
    result = 'PASS'
  } | ConvertTo-Json -Depth 16
  return
}

$workbenchJson = (& $workbenchConfiguratorPath -Apply -Confirm:$false @workbenchParameters | Out-String)
$workbenchResult = $workbenchJson | ConvertFrom-Json -ErrorAction Stop

[ordered]@{
  schemaVersion = 'hw-os-lean-guard-one-command-result/v2'
  packageVersion = [string]$manifest.packageVersion
  installEvidence = $installEvidence
  checks = $checks
  workbench = $workbenchResult
  result = 'PASS'
} | ConvertTo-Json -Depth 16
