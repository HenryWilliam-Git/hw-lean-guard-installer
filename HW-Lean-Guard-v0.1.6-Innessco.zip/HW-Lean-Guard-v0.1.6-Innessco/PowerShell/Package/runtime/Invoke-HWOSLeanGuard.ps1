<#
HW OS Lean Guard v0.1.6. PreToolUse guard for deterministic endpoint-only
consequences. It intentionally does not classify document text.
#>
[CmdletBinding()]
param(
  [Parameter(ValueFromPipeline = $true)]
  [string]$InputJson,
  [string]$PolicyPath,
  [string]$AuditDirectory = "C:\ProgramData\HenryWilliam\LeanGuard\logs"
)

begin {
  $inputChunks = New-Object System.Collections.Generic.List[string]
}

process {
  if ($null -ne $InputJson) {
    $inputChunks.Add($InputJson)
  }
}

end {
  $ErrorActionPreference = "Stop"
  Set-StrictMode -Version 2.0
  if ([string]::IsNullOrWhiteSpace($PolicyPath)) { $PolicyPath = Join-Path $PSScriptRoot "..\policy\guard-policy.json" }

  function Get-HWOSPropertyValue {
    param([object]$Object, [string[]]$Names)
    if ($null -eq $Object) { return $null }
    foreach ($name in $Names) {
      $property = $Object.PSObject.Properties | Where-Object { $_.Name -ceq $name } | Select-Object -First 1
      if ($null -ne $property) { return $property.Value }
    }
    return $null
  }

  function Test-HWOSExactMember {
    param([string]$Value, [object[]]$Members)
    foreach ($member in @($Members)) {
      if ([string]::Equals($Value, [string]$member, [System.StringComparison]::Ordinal)) { return $true }
    }
    return $false
  }

  function Get-HWOSOperationalFields {
    param(
      [object]$Value,
      [string]$Name = "",
      [bool]$InDocumentData = $false,
      [int]$Depth = 0
    )
    if ($Depth -gt 20 -or $null -eq $Value) { return }
    $isDocumentField = Test-HWOSExactMember -Value $Name.ToLowerInvariant() -Members $policy.documentDataFields
    if ($InDocumentData -or $isDocumentField) { return }

    if ($Value -is [string] -or $Value -is [ValueType]) {
      [pscustomobject]@{ Name = $Name; Value = $Value }
      return
    }
    if ($Value -is [System.Collections.IDictionary]) {
      foreach ($key in $Value.Keys) {
        Get-HWOSOperationalFields -Value $Value[$key] -Name ([string]$key) -InDocumentData $false -Depth ($Depth + 1)
      }
      return
    }
    if ($Value -is [System.Collections.IEnumerable] -and -not ($Value -is [string])) {
      foreach ($item in $Value) {
        Get-HWOSOperationalFields -Value $item -Name $Name -InDocumentData $false -Depth ($Depth + 1)
      }
      return
    }
    foreach ($property in $Value.PSObject.Properties) {
      Get-HWOSOperationalFields -Value $property.Value -Name $property.Name -InDocumentData $false -Depth ($Depth + 1)
    }
  }

  function ConvertTo-HWOSCandidatePath {
    param([string]$Value)
    if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
    $candidate = $Value.Trim().Trim('"').Trim("'")
    $candidate = [Environment]::ExpandEnvironmentVariables($candidate)
    if ($candidate.StartsWith("file:///", [System.StringComparison]::OrdinalIgnoreCase)) {
      try { $candidate = ([Uri]$candidate).LocalPath } catch { return $null }
    }
    if (-not [IO.Path]::IsPathRooted($candidate)) { return $null }
    try { return [IO.Path]::GetFullPath($candidate) } catch { return $null }
  }

  function Resolve-HWOSExistingAncestorPath {
    param([string]$Path)
    $cursor = $Path
    while (-not [string]::IsNullOrWhiteSpace($cursor)) {
      if (Test-Path -LiteralPath $cursor) {
        try {
          $resolved = (Get-Item -LiteralPath $cursor -Force).FullName
          if ($cursor.Length -lt $Path.Length) {
            $suffix = $Path.Substring($cursor.Length).TrimStart('\')
            if ($suffix) { return [IO.Path]::GetFullPath((Join-Path $resolved $suffix)) }
          }
          return [IO.Path]::GetFullPath($resolved)
        } catch { return $Path }
      }
      $parent = Split-Path -Parent $cursor
      if ([string]::Equals($parent, $cursor, [System.StringComparison]::OrdinalIgnoreCase)) { break }
      $cursor = $parent
    }
    return $Path
  }

  function Test-HWOSPathWithinRoot {
    param([string]$Path, [string]$Root)
    $candidate = ConvertTo-HWOSCandidatePath -Value $Path
    $rootPath = ConvertTo-HWOSCandidatePath -Value $Root
    if (-not $candidate -or -not $rootPath) { return $false }
    $candidate = (Resolve-HWOSExistingAncestorPath -Path $candidate).TrimEnd('\')
    $rootPath = (Resolve-HWOSExistingAncestorPath -Path $rootPath).TrimEnd('\')
    return $candidate.Equals($rootPath, [System.StringComparison]::OrdinalIgnoreCase) -or
      $candidate.StartsWith($rootPath + "\", [System.StringComparison]::OrdinalIgnoreCase)
  }

  function Test-HWOSProtectedPath {
    param([string]$Path)
    foreach ($root in @($policy.protectedRoots) + @($policy.protectedUncRoots)) {
      if (Test-HWOSPathWithinRoot -Path $Path -Root ([string]$root)) { return $true }
    }
    return $false
  }

  function Test-HWOSApprovedMcpbDeletePath {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or [Management.Automation.WildcardPattern]::ContainsWildcardCharacters($Path)) { return $false }
    $candidate = ConvertTo-HWOSCandidatePath -Value $Path
    if (-not $candidate -or [IO.Path]::GetExtension($candidate) -cne '.mcpb' -or -not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }
    if (Test-HWOSProtectedPath -Path $candidate) { return $false }

    foreach ($root in @($policy.approvedMcpbDeleteRoots)) {
      $rootPath = ConvertTo-HWOSCandidatePath -Value ([string]$root)
      if (-not $rootPath) { continue }
      $resolvedRoot = (Resolve-HWOSExistingAncestorPath -Path $rootPath).TrimEnd('\')
      $resolvedCandidate = (Resolve-HWOSExistingAncestorPath -Path $candidate).TrimEnd('\')
      if (-not [string]::Equals((Split-Path -Parent $resolvedCandidate), $resolvedRoot, [StringComparison]::OrdinalIgnoreCase)) { continue }

      $rootItem = Get-Item -LiteralPath $resolvedRoot -Force -ErrorAction SilentlyContinue
      $candidateItem = Get-Item -LiteralPath $resolvedCandidate -Force -ErrorAction SilentlyContinue
      if ($null -eq $rootItem -or $null -eq $candidateItem) { continue }
      if (($rootItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 -or
          ($candidateItem.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { continue }
      return $true
    }
    return $false
  }

  function Get-HWOSApprovedShellMcpbDeleteTarget {
    param([string]$CommandText)
    if ([string]::IsNullOrWhiteSpace($CommandText) -or $CommandText -match '[;&|\r\n]') { return $null }
    $pattern = '(?is)^\s*Remove-Item\s+-LiteralPath\s+(?:"(?<double>[A-Z]:[\\/][^"]+)"|''(?<single>[A-Z]:[\\/][^'']+)'')(?<options>(?:\s+-Force|\s+-Confirm:\$false)*)\s*$'
    $match = [regex]::Match($CommandText, $pattern)
    if (-not $match.Success) { return $null }
    if ($match.Groups['double'].Success) { return $match.Groups['double'].Value }
    return $match.Groups['single'].Value
  }

  function Get-HWOSClaudeWorkbenchRoot {
    $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not [IO.Path]::IsPathRooted($desktop)) { return $null }
    try { return [IO.Path]::GetFullPath((Join-Path $desktop 'Claude Workbench')) } catch { return $null }
  }

  function Test-HWOSApprovedClaudeWorkbenchPath {
    param([string]$Path)
    $candidate = ConvertTo-HWOSCandidatePath -Value $Path
    $rootPath = Get-HWOSClaudeWorkbenchRoot
    if (-not $candidate -or -not $rootPath) { return $false }
    $candidate = (Resolve-HWOSExistingAncestorPath -Path $candidate).TrimEnd('\')
    $rootPath = (Resolve-HWOSExistingAncestorPath -Path $rootPath).TrimEnd('\')
    return $candidate.Equals($rootPath, [System.StringComparison]::OrdinalIgnoreCase) -or
      $candidate.StartsWith($rootPath + '\', [System.StringComparison]::OrdinalIgnoreCase)
  }

  function Get-HWOSExplicitCopyOperation {
    param([string]$CommandText)
    if ([string]::IsNullOrWhiteSpace($CommandText)) { return $null }

    try {
      $tokens = $null
      $parseErrors = $null
      $ast = [System.Management.Automation.Language.Parser]::ParseInput($CommandText, [ref]$tokens, [ref]$parseErrors)
      if (@($parseErrors).Count -gt 0) { return $null }
      $commands = @($ast.FindAll({
        param($node)
        $node -is [System.Management.Automation.Language.CommandAst]
      }, $true))
      if ($commands.Count -ne 1 -or -not [string]::Equals($commands[0].GetCommandName(), 'Copy-Item', [System.StringComparison]::OrdinalIgnoreCase)) { return $null }
      if (@($commands[0].Redirections).Count -gt 0) { return $null }

      $source = $null
      $destination = $null
      $elements = @($commands[0].CommandElements)
      for ($i = 1; $i -lt $elements.Count; $i++) {
        $element = $elements[$i]
        if (-not ($element -is [System.Management.Automation.Language.CommandParameterAst])) { continue }
        if ($element.ParameterName -notin @('Path','LiteralPath','Destination')) { continue }
        if (($i + 1) -ge $elements.Count -or -not ($elements[$i + 1] -is [System.Management.Automation.Language.StringConstantExpressionAst])) { return $null }
        $value = [string]$elements[$i + 1].Value
        if ($element.ParameterName -eq 'Destination') {
          if ($null -ne $destination) { return $null }
          $destination = $value
        } else {
          if ($null -ne $source) { return $null }
          $source = $value
        }
        $i += 1
      }
      if ([string]::IsNullOrWhiteSpace($source) -or [string]::IsNullOrWhiteSpace($destination)) { return $null }
      return [pscustomobject]@{ Source = $source; Destination = $destination }
    } catch {
      return $null
    }
  }

  function Test-HWOSPromotionPath {
    param([string]$Path)
    $candidate = ConvertTo-HWOSCandidatePath -Value $Path
    if (-not $candidate) { return $false }
    foreach ($part in @($candidate -split '[\\/]')) {
      $stem = [IO.Path]::GetFileNameWithoutExtension($part).ToLowerInvariant()
      if (Test-HWOSExactMember -Value $stem -Members $policy.promotionPathComponents) { return $true }
    }
    return $false
  }

  function Get-HWOSPathFields {
    param([object[]]$Fields)
    $names = @('path','file','file_path','filepath','destination','destination_path','target','target_path','output','output_path','source','source_path','cwd')
    foreach ($field in @($Fields)) {
      if ($field.Value -is [string] -and (Test-HWOSExactMember -Value ([string]$field.Name).ToLowerInvariant() -Members $names)) {
        $field.Value
      }
    }
  }

  function Get-HWOSShellReadPaths {
    param([string]$CommandText)
    if ([string]::IsNullOrWhiteSpace($CommandText)) { return }

    foreach ($segment in @($CommandText -split '(?:;|\r?\n|&&|\|\|)')) {
      $candidate = $segment.Trim()
      if ($candidate -notmatch '^(?i)(?:/usr/bin/)?(?:cat|head|tail)\b|^(?i)(?:get-content|gc|type)\b') { continue }
      if ($candidate -match '^(?i)(?:/usr/bin/)?cat\s+(?:--\s+)?>>?') { continue }
      foreach ($match in [regex]::Matches($candidate, '(?i)(?:"(?<double>[A-Z]:[\\/][^"]+)"|''(?<single>[A-Z]:[\\/][^'']+)''|(?<bare>[A-Z]:[\\/][^\s|;&<>]+))')) {
        foreach ($groupName in @('double','single','bare')) {
          if ($match.Groups[$groupName].Success) {
            $match.Groups[$groupName].Value
            break
          }
        }
      }
    }
  }

  function Test-HWOSCredentialBearingFile {
    param([string]$Path)
    $candidate = ConvertTo-HWOSCandidatePath -Value $Path
    if (-not $candidate) { return $false }
    $candidate = Resolve-HWOSExistingAncestorPath -Path $candidate
    if (-not (Test-Path -LiteralPath $candidate -PathType Leaf)) { return $false }

    try {
      $item = Get-Item -LiteralPath $candidate -Force
      # Availability-first boundary: oversized, unreadable, or binary files are not content-classified here.
      if ($item.Length -gt [int64]$policy.maxInputBytes) { return $false }
      $text = [IO.File]::ReadAllText($item.FullName, [Text.Encoding]::UTF8)
    } catch {
      return $false
    }
    if ($text.IndexOf([char]0) -ge 0) { return $false }

    $secretKinds = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($line in @($text -split '\r?\n')) {
      if ($line -notmatch '^\s*(?:[-*]\s*)?(?:\*{1,2})?(?<label>username|user[ _-]*name|login[ _-]*name|password|passphrase|api[ _-]*token|access[ _-]*token)(?:\*{1,2})?\s*[:=]\s*(?<value>\S.*?)\s*$') { continue }
      $label = $Matches['label'].ToLowerInvariant() -replace '[ _-]', ''
      $value = $Matches['value'].Trim().Trim('`').Trim('"').Trim("'")
      $plainValue = $value.Trim('*').Trim()
      if ([string]::IsNullOrWhiteSpace($plainValue) -or $plainValue -match '^(?i)(?:\[redacted(?:[^\]]*)?\]|<redacted>|\(redacted\)|n/?a|none)$') { continue }
      if ($plainValue.Length -lt 4 -or $plainValue -match '\s') { continue }
      if ($label -notin @('username','loginname')) { [void]$secretKinds.Add($label) }
    }
    return $secretKinds.Count -gt 0
  }

  function Get-HWOSRecipients {
    param([object]$ToolInput)
    $values = New-Object System.Collections.Generic.List[string]
    foreach ($name in @($policy.recipientFields)) {
      $property = $ToolInput.PSObject.Properties | Where-Object { $_.Name.ToLowerInvariant() -ceq ([string]$name).ToLowerInvariant() } | Select-Object -First 1
      if ($null -eq $property) { continue }
      foreach ($item in @($property.Value)) {
        if ($item -is [string]) { $values.Add($item) }
        elseif ($null -ne $item) {
          $address = Get-HWOSPropertyValue -Object $item -Names @('address','email')
          if ($address -is [string]) { $values.Add($address) }
        }
      }
    }
    return @($values)
  }

  function Test-HWOSInternalAddress {
    param([string]$Address)
    if ([string]::IsNullOrWhiteSpace($Address)) { return $false }
    $candidate = $Address.Trim()
    if ($candidate -match '<([^<>]+)>$') { $candidate = $Matches[1] }
    $parts = $candidate.Split('@')
    if ($parts.Count -ne 2 -or $parts[0].Length -eq 0) { return $false }
    foreach ($domain in @($policy.internalEmailDomains)) {
      if ([string]::Equals($parts[1], [string]$domain, [System.StringComparison]::OrdinalIgnoreCase)) { return $true }
    }
    return $false
  }

  function Test-HWOSDelayedRequest {
    param([object[]]$Fields)
    foreach ($field in @($Fields)) {
      if (-not (Test-HWOSExactMember -Value ([string]$field.Name).ToLowerInvariant() -Members $policy.delayedFields)) { continue }
      if ($field.Value -is [bool] -and $field.Value) { return $true }
      if ($field.Value -is [ValueType] -and [double]$field.Value -ne 0) { return $true }
      if ($field.Value -is [string] -and -not [string]::IsNullOrWhiteSpace($field.Value) -and $field.Value -notmatch '^(false|off|none|0)$') { return $true }
    }
    return $false
  }

  function Test-HWOSBackgroundRequest {
    param([object[]]$Fields)
    foreach ($field in @($Fields)) {
      if (-not (Test-HWOSExactMember -Value ([string]$field.Name).ToLowerInvariant() -Members $policy.backgroundFields)) { continue }
      if ($field.Value -is [bool] -and $field.Value) { return $true }
      if ($field.Value -is [ValueType] -and [double]$field.Value -ne 0) { return $true }
      if ($field.Value -is [string] -and -not [string]::IsNullOrWhiteSpace($field.Value) -and $field.Value -notmatch '^(false|off|none|0)$') { return $true }
    }
    return $false
  }

  function Write-HWOSDecision {
    param([string]$Decision, [string]$Rule, [string]$ToolName, [string]$Reason)
    $event = [ordered]@{
      schemaVersion = "hw-os-lean-guard-audit-event/v1"
      timestampUtc = (Get-Date).ToUniversalTime().ToString('o')
      packageVersion = [string]$policy.packageVersion
      decision = $Decision
      rule = $Rule
      toolName = $ToolName
      policySha256 = $policySha256
    }
    try {
      [IO.Directory]::CreateDirectory([IO.Path]::GetFullPath($AuditDirectory)) | Out-Null
      $line = ($event | ConvertTo-Json -Compress -Depth 8) + [Environment]::NewLine
      [IO.File]::AppendAllText((Join-Path $AuditDirectory ([string]$policy.auditFileName)), $line, [Text.UTF8Encoding]::new($false))
    } catch {
      [Console]::Error.WriteLine('[HW OS Lean Guard:audit-failure] Audit write failed; tool call blocked.')
      exit 2
    }
    $output = [ordered]@{
      hookSpecificOutput = [ordered]@{
        hookEventName = 'PreToolUse'
        permissionDecision = $Decision
        permissionDecisionReason = "[HW OS Lean Guard:$Rule] $Reason"
      }
    }
    [Console]::Out.WriteLine(($output | ConvertTo-Json -Compress -Depth 8))
    exit 0
  }

  if (-not (Test-Path -LiteralPath $PolicyPath -PathType Leaf)) {
    [Console]::Error.WriteLine('[HW OS Lean Guard:policy-missing] Policy unavailable; tool call blocked.')
    exit 2
  }
  try {
    $policyText = [IO.File]::ReadAllText([IO.Path]::GetFullPath($PolicyPath), [Text.Encoding]::UTF8)
    $policy = $policyText | ConvertFrom-Json -ErrorAction Stop
    $policySha256 = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($policyText)))).Replace('-', '').ToLowerInvariant()
    if ($policy.schemaVersion -cne 'hw-os-lean-guard-policy/v1' -or [int64]$policy.maxInputBytes -le 0) { throw 'Invalid policy contract.' }
  } catch {
    [Console]::Error.WriteLine('[HW OS Lean Guard:policy-invalid] Policy invalid; tool call blocked.')
    exit 2
  }

  $rawInput = ($inputChunks -join [Environment]::NewLine)
  if ([string]::IsNullOrWhiteSpace($rawInput)) { $rawInput = [Console]::In.ReadToEnd() }
  $byteCount = [Text.Encoding]::UTF8.GetByteCount($rawInput)
  if ($byteCount -eq 0) { Write-HWOSDecision -Decision 'deny' -Rule 'invalid-hook-json' -ToolName '' -Reason 'Hook input is empty.' }
  if ($byteCount -gt [int64]$policy.maxInputBytes) { Write-HWOSDecision -Decision 'deny' -Rule 'hook-input-too-large' -ToolName '' -Reason 'Hook input exceeds the managed size limit.' }

  try { $payload = $rawInput | ConvertFrom-Json -ErrorAction Stop }
  catch { Write-HWOSDecision -Decision 'deny' -Rule 'invalid-hook-json' -ToolName '' -Reason 'Hook input is not valid JSON.' }

  $toolName = [string](Get-HWOSPropertyValue -Object $payload -Names @('tool_name','toolName'))
  $toolInput = Get-HWOSPropertyValue -Object $payload -Names @('tool_input','toolInput','input','arguments')
  if ([string]::IsNullOrWhiteSpace($toolName) -or $null -eq $toolInput) {
    Write-HWOSDecision -Decision 'deny' -Rule 'invalid-hook-contract' -ToolName $toolName -Reason 'Tool identity or input is missing.'
  }

  $fields = @(Get-HWOSOperationalFields -Value $toolInput)
  $paths = @(Get-HWOSPathFields -Fields $fields)
  $isShell = Test-HWOSExactMember -Value $toolName -Members $policy.shellTools
  $command = [string](Get-HWOSPropertyValue -Object $toolInput -Names @('command'))

  $readPaths = New-Object System.Collections.Generic.List[string]
  if ([string]::Equals($toolName, 'Read', [System.StringComparison]::Ordinal)) {
    foreach ($path in $paths) { if ($path -is [string]) { $readPaths.Add($path) } }
  }
  if ($isShell) {
    foreach ($path in @(Get-HWOSShellReadPaths -CommandText $command)) { $readPaths.Add([string]$path) }
  }
  foreach ($path in @($readPaths | Select-Object -Unique)) {
    if (Test-HWOSCredentialBearingFile -Path $path) {
      Write-HWOSDecision -Decision 'deny' -Rule 'credential-bearing-file-read-deny' -ToolName $toolName -Reason 'Credential-bearing source content must be sanitized before it enters model context.'
    }
  }

  if (Test-HWOSExactMember -Value $toolName -Members $policy.restrictedExternalCapabilities) {
    Write-HWOSDecision -Decision 'deny' -Rule 'restricted-external-capability' -ToolName $toolName -Reason 'This exact consequential capability is not available to Claude.'
  }

  if (Test-HWOSExactMember -Value $toolName -Members $policy.outlookInternalSendCapabilities) {
    $recipients = @(Get-HWOSRecipients -ToolInput $toolInput)
    $confirmed = Get-HWOSPropertyValue -Object $toolInput -Names @('confirm')
    if ($recipients.Count -eq 0 -or @($recipients | Where-Object { -not (Test-HWOSInternalAddress -Address $_) }).Count -gt 0) {
      Write-HWOSDecision -Decision 'deny' -Rule 'outlook-internal-send-domain' -ToolName $toolName -Reason 'All recipients must use the exact managed internal domain.'
    }
    if (-not ($confirmed -is [bool]) -or $confirmed -ne $true) {
      Write-HWOSDecision -Decision 'deny' -Rule 'outlook-internal-send-confirmation' -ToolName $toolName -Reason 'A one-time Boolean confirmation is required.'
    }
    if ((Test-HWOSDelayedRequest -Fields $fields) -or (Test-HWOSBackgroundRequest -Fields $fields)) {
      Write-HWOSDecision -Decision 'deny' -Rule 'delayed-or-background-action' -ToolName $toolName -Reason 'Delayed or background communication is not permitted.'
    }
    Write-HWOSDecision -Decision 'allow' -Rule 'outlook-internal-send-confirmed' -ToolName $toolName -Reason 'Confirmed synchronous internal send admitted.'
  }

  $deleteTool = Test-HWOSExactMember -Value $toolName -Members $policy.deleteTools
  $deleteCommand = $isShell -and $command -match '(?i)(^|[;&|]\s*)(remove-item\b|del\s+|erase\s+|rmdir\b|rd\s+|rm\s+)'
  if ($deleteTool -or $deleteCommand) {
    Write-HWOSDecision -Decision 'ask' -Rule 'delete-confirmation-required' -ToolName $toolName -Reason 'Deletion requires one-time user confirmation for this exact tool call.'
  }

  $nativeMutation = Test-HWOSExactMember -Value $toolName -Members $policy.nativeWriteTools
  $shellMutation = $isShell -and $command -match '(?i)\b(set-content|add-content|out-file|new-item|copy-item|move-item|rename-item|robocopy|xcopy|mkdir|md\s+|copy\s+|move\s+|ren\s+|touch\s+|tee\s+)\b|(^|\s)(>|>>)\s*[^&]'
  $shellCopy = $isShell -and $command -match '(?i)\b(copy-item|move-item|robocopy|xcopy|copy\s+|move\s+)\b'

  $copyOperation = if ($shellCopy) { Get-HWOSExplicitCopyOperation -CommandText $command } else { $null }
  if ($null -ne $copyOperation) {
    $protectedSource = Test-HWOSProtectedPath -Path $copyOperation.Source
    $protectedDestination = Test-HWOSProtectedPath -Path $copyOperation.Destination
    if ($protectedDestination) {
      Write-HWOSDecision -Decision 'deny' -Rule 'protected-path-write-deny' -ToolName $toolName -Reason 'Claude cannot write to a protected source or runtime root.'
    }
    if ($protectedSource) {
      if (Test-HWOSApprovedClaudeWorkbenchPath -Path $copyOperation.Destination) {
        Write-HWOSDecision -Decision 'allow' -Rule 'protected-source-copy-to-claude-workbench' -ToolName $toolName -Reason 'A protected source is admitted as read-only input to an approved Claude Workbench destination.'
      }
      Write-HWOSDecision -Decision 'deny' -Rule 'protected-source-copy-destination-deny' -ToolName $toolName -Reason 'A protected source may be copied only to an approved Claude Workbench destination.'
    }
  }

  if ($shellMutation) {
    foreach ($root in @($policy.protectedRoots) + @($policy.protectedUncRoots)) {
      if ($command.IndexOf(([string]$root).TrimEnd('\'), [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
        Write-HWOSDecision -Decision 'deny' -Rule 'protected-path-write-deny' -ToolName $toolName -Reason 'Claude cannot mutate a protected source or runtime root.'
      }
    }
  }

  if ($nativeMutation) {
    foreach ($path in $paths) {
      if (Test-HWOSProtectedPath -Path ([string]$path)) {
        Write-HWOSDecision -Decision 'deny' -Rule 'protected-path-write-deny' -ToolName $toolName -Reason 'Claude cannot mutate a protected source or runtime root.'
      }
      if (Test-HWOSPromotionPath -Path ([string]$path)) {
        Write-HWOSDecision -Decision 'deny' -Rule 'promotion-path-deny' -ToolName $toolName -Reason 'Promotion is a human lawyer act.'
      }
    }
  }

  if (Test-HWOSDelayedRequest -Fields $fields) {
    Write-HWOSDecision -Decision 'deny' -Rule 'delayed-or-background-action' -ToolName $toolName -Reason 'Delayed or background consequential action is not permitted.'
  }

  Write-HWOSDecision -Decision 'allow' -Rule 'lean-default-allow' -ToolName $toolName -Reason 'No endpoint consequence rule matched.'
}
