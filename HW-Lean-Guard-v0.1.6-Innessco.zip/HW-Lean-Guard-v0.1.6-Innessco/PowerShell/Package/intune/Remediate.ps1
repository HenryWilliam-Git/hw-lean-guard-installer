[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$statePath = 'C:\ProgramData\HenryWilliam\LeanGuard\state\install-state.json'
$settingsPath = 'C:\Program Files\ClaudeCode\HWOSLeanGuard\policy\endpoint-bootstrap-settings.json'
$registryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
try {
  if (-not (Test-Path -LiteralPath $statePath -PathType Leaf) -or -not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) { exit 1 }
  $state = [IO.File]::ReadAllText($statePath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
  foreach ($property in $state.files.PSObject.Properties) {
    $path = Join-Path ([string]$state.installRoot) $property.Name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { exit 1 }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$property.Value) { exit 1 }
  }
  $settings = [IO.File]::ReadAllText($settingsPath, [Text.Encoding]::UTF8).TrimEnd("`r", "`n")
  $hash = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes($settings)))).Replace('-', '').ToLowerInvariant()
  if ($hash -cne [string]$state.settingsSha256) { exit 1 }
  New-Item -Path $registryPath -Force | Out-Null
  New-ItemProperty -LiteralPath $registryPath -Name 'Settings' -Value $settings -PropertyType String -Force | Out-Null
  & (Join-Path $PSScriptRoot 'Detect.ps1') | Out-Null
  exit $LASTEXITCODE
} catch { exit 1 }
