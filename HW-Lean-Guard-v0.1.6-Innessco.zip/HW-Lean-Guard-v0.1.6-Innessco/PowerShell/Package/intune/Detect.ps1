[CmdletBinding()]
param()
$ErrorActionPreference = 'SilentlyContinue'
$statePath = 'C:\ProgramData\HenryWilliam\LeanGuard\state\install-state.json'
$registryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { exit 1 }
try {
  $state = [IO.File]::ReadAllText($statePath, [Text.Encoding]::UTF8) | ConvertFrom-Json -ErrorAction Stop
  $settings = (Get-Item -LiteralPath $registryPath).GetValue('Settings', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
  if ($null -eq $settings) { exit 1 }
  $hash = ([BitConverter]::ToString(([Security.Cryptography.SHA256]::Create()).ComputeHash([Text.Encoding]::UTF8.GetBytes([string]$settings)))).Replace('-', '').ToLowerInvariant()
  if ($hash -cne [string]$state.settingsSha256) { exit 1 }
  foreach ($property in $state.files.PSObject.Properties) {
    $path = Join-Path ([string]$state.installRoot) $property.Name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { exit 1 }
    if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne [string]$property.Value) { exit 1 }
  }
  Write-Output 'HW OS Lean Guard 0.1.6 detected'
  exit 0
} catch { exit 1 }
