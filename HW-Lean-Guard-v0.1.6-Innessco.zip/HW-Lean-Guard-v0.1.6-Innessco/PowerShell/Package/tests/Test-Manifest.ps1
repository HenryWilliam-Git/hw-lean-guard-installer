$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
& (Join-Path $root 'deployment\Test-HWOSLeanGuardPackage.ps1') -PackageRoot $root
Import-Module (Join-Path $root 'deployment\HWOSLeanGuard.Deployment.psm1') -Force
$sandbox = Join-Path ([IO.Path]::GetTempPath()) ("HWOSLeanGuardManifestTests-" + [Guid]::NewGuid().ToString('N'))
try {
  [IO.Directory]::CreateDirectory($sandbox) | Out-Null
  Copy-Item -Path (Join-Path $root '*') -Destination $sandbox -Recurse -Force
  $extraPath = Join-Path $sandbox 'unexpected.txt'
  [IO.File]::WriteAllText($extraPath, 'unexpected', [Text.UTF8Encoding]::new($false))
  $blocked = $false
  try { Assert-HWOSLeanGuardPackage -PackageRoot $sandbox | Out-Null } catch { $blocked = $true }
  if (-not $blocked) { throw 'Manifest admitted an extra file.' }
  Remove-Item -LiteralPath $extraPath -Force

  $versionPath = Join-Path $sandbox 'VERSION'
  [IO.File]::AppendAllText($versionPath, 'changed', [Text.UTF8Encoding]::new($false))
  $blocked = $false
  try { Assert-HWOSLeanGuardPackage -PackageRoot $sandbox | Out-Null } catch { $blocked = $true }
  if (-not $blocked) { throw 'Manifest admitted changed content.' }
  Copy-Item -LiteralPath (Join-Path $root 'VERSION') -Destination $versionPath -Force

  Remove-Item -LiteralPath (Join-Path $sandbox 'README.md') -Force
  $blocked = $false
  try { Assert-HWOSLeanGuardPackage -PackageRoot $sandbox | Out-Null } catch { $blocked = $true }
  if (-not $blocked) { throw 'Manifest admitted a missing file.' }
  Write-Output 'PASS: manifest rejects missing, extra, and changed package content'
} finally {
  if (Test-Path -LiteralPath $sandbox) { Remove-Item -LiteralPath $sandbox -Recurse -Force }
}
