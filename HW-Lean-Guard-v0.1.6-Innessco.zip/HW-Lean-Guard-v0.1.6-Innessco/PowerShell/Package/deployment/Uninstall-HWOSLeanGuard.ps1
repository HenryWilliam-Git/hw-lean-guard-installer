[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [switch]$Apply,
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2.0
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
$statePath = Join-Path $StateRoot 'state\install-state.json'
if (-not (Test-Path -LiteralPath $statePath -PathType Leaf)) { throw 'Installed state receipt is missing; refusing an unbounded uninstall.' }
$state = Read-HWOSLeanGuardJson -Path $statePath
$preview = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-uninstall-preview/v1'
  applyRequested = [bool]$Apply
  installRoot = [string]$state.installRoot
  restoreSnapshot = [string]$state.preStatePath
  stateAndEvidenceRetained = $true
}
if (-not $Apply) { $preview | ConvertTo-Json -Depth 10; return }
if (-not (Test-HWOSLeanGuardAdministrator)) { throw 'Apply requires an elevated Administrator PowerShell.' }
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
if (@($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -gt 0) { throw 'Installed state has drifted; refusing compare-and-swap rollback.' }
$preState = Read-HWOSLeanGuardJson -Path ([string]$state.preStatePath)
$installRoot = [IO.Path]::GetFullPath([string]$state.installRoot)
$expectedRoot = [IO.Path]::GetFullPath('C:\Program Files\ClaudeCode\HWOSLeanGuard')
if (-not $installRoot.Equals($expectedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw 'Install root is outside the authorised uninstall target.' }
if (-not $PSCmdlet.ShouldProcess($installRoot, 'Restore prior HKLM policy and remove exact installed runtime')) { return }

Restore-HWOSLeanGuardRegistryState -Path $PolicyRegistryPath -State $preState.registry
Remove-Item -LiteralPath $installRoot -Recurse -Force
$stamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss-fff')
$evidence = [ordered]@{
  schemaVersion = 'hw-os-lean-guard-evidence/v1'
  capturedAtUtc = (Get-Date).ToUniversalTime().ToString('o')
  packageVersion = [string]$state.packageVersion
  checks = [ordered]@{
    installRootRemoved = -not (Test-Path -LiteralPath $installRoot)
    priorRegistryStateRestored = $true
  }
  result = 'PASS'
}
Write-HWOSLeanGuardJson -Path (Join-Path $StateRoot "evidence\uninstall-$stamp.json") -Value $evidence
Remove-Item -LiteralPath $statePath -Force
$evidence | ConvertTo-Json -Depth 10
