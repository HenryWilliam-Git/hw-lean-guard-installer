[CmdletBinding()]
param(
  [switch]$Quiet,
  [string]$StateRoot = 'C:\ProgramData\HenryWilliam\LeanGuard',
  [string]$PolicyRegistryPath = 'HKLM:\SOFTWARE\Policies\ClaudeCode'
)

$ErrorActionPreference = 'Stop'
Import-Module (Join-Path $PSScriptRoot 'HWOSLeanGuard.Deployment.psm1') -Force
$checks = Get-HWOSLeanGuardInstalledChecks -StateRoot $StateRoot -PolicyRegistryPath $PolicyRegistryPath
$passed = @($checks.GetEnumerator() | Where-Object { $_.Value -ne $true }).Count -eq 0
if ($Quiet) { if ($passed) { exit 0 } else { exit 1 } }
[ordered]@{ packageVersion = '0.1.6'; checks = $checks; result = if ($passed) { 'PASS' } else { 'FAIL' } } | ConvertTo-Json -Depth 10
if ($passed) { exit 0 } else { exit 1 }
